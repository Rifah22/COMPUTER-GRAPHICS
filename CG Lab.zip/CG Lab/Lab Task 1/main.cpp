#include <windows.h>
#include <GL/glut.h>
void Axis()
{
    glLineWidth(3.5);
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2d(-10.0,0.0);
    glVertex2d(10.0,0.0);

    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2d(0.0,5.0);
    glVertex2d(0.0,-5.0);

    glEnd();
}
void Rectangle()
{
    glBegin(GL_QUADS);
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-3.0,1.0);
    glVertex2f(-3.0,4.0);
    glVertex2f(-7.0,4.0);
    glVertex2f(-7.0,1.0);

    glEnd();
}
void TriangelB()
{
    glBegin(GL_TRIANGLES);
    glColor3ub(127, 0, 255);

    glVertex2f(-3.0,-4.5);
    glVertex2f(-3.0,-0.5);
    glVertex2f(-7.0,-2.50);

    glEnd();
}
void TriangelY()
{
    glBegin(GL_TRIANGLES);
    glColor3f(1.0f, 1.0f, 0.0f);

    glVertex2f(8.0,-4.0);
    glVertex2f(5.50,-0.5);
    glVertex2f(3.0,-4.0);

    glEnd();
}
void Arrow()
{
   glBegin(GL_POLYGON);
   glColor3f(0.0f, 1.0f, 0.0f);

   glVertex2d(9.0,2.5);
   glVertex2d(6.5,4.0);
   glVertex2d(6.5,3.3);
   glVertex2d(3.0,3.3);
   glVertex2d(3.0,1.7);
   glVertex2d(6.5,1.7);
   glVertex2d(6.5,1.0);

   glEnd();
}
void display()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    Axis();
    Rectangle();
    TriangelB();
    TriangelY();
    Arrow();
    glFlush();

}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutCreateWindow("Different Shape");
    glutInitWindowSize(320, 320);
    glutDisplayFunc(display);
    gluOrtho2D(-20,20,-20,20);
    glutMainLoop();

    return 0;
}
