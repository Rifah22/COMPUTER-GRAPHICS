#include <windows.h>
#include <GL/glut.h>
#include <math.h>

void Scenery()
{
    glBegin(GL_POLYGON);
	glColor3ub(244, 232, 214);

	glVertex2f(-60,-40);
	glVertex2f(-60,80);
    glVertex2f(200,80);
	glVertex2f(200,-40);

	glEnd();


	glBegin(GL_POLYGON);
	glColor3ub(63, 229, 255 );

	glVertex2f(-60,40);
	glVertex2f(-60,80);
    glVertex2f(200,80);
	glVertex2f(200,40);

	glEnd();

	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(247, 237, 27 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=70.8-64.1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+182,y+64.1);
    }
    glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(93, 101, 93 );

	glVertex2f(-60,-40);
	glVertex2f(-60,-15);
    glVertex2f(200,-15);
	glVertex2f(200,-40);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(75, 219, 77 );

	glVertex2f(-60,-15);
	glVertex2f(-60,40);
    glVertex2f(200,40);
	glVertex2f(200,-15);

	glEnd();

//
    glBegin(GL_POLYGON);
	glColor3ub(194, 117, 0);

	glVertex2f(76,12);
	glVertex2f(78,20);
    glVertex2f(120,20);
	glVertex2f(118,12);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(194, 117, 0);

	glVertex2f(74,3);
	glVertex2f(76,11);
    glVertex2f(118,11);
	glVertex2f(116,3);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(69,-5);
	glVertex2f(72,1);
    glVertex2f(117,1);
	glVertex2f(114,-5);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(81,1);
	glVertex2f(82,3);
    glVertex2f(84,3);
	glVertex2f(83,1);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(105,1);
	glVertex2f(106,3);
    glVertex2f(108,3);
	glVertex2f(107,1);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(73,-20);
	glVertex2f(74,-5);
    glVertex2f(76,-5);
	glVertex2f(75,-20);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(79,-15);
	glVertex2f(80,-5);
    glVertex2f(82,-5);
	glVertex2f(81,-15);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(101,-20);
	glVertex2f(102,-5);
    glVertex2f(104,-5);
	glVertex2f(103,-20);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 120, 13);

	glVertex2f(107,-15);
	glVertex2f(108,-5);
    glVertex2f(110,-5);
	glVertex2f(109,-15);

	glEnd();

//


    //3
    glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(164,45.9);
	glVertex2f(164,43.9);
    glVertex2f(177.8,43.9);
	glVertex2f(177.8,45.9);

	glEnd();

    glBegin(GL_POLYGON);
	glColor3f(1,1,1);

	glVertex2f(166,32);
	glVertex2f(164,43.9);
    glVertex2f(177.8,43.9);
	glVertex2f(176,32);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(166,30);
	glVertex2f(166,32);
	glVertex2f(176,32);
	glVertex2f(176,30);

	glEnd();


	//1
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(121.9,45.9);
	glVertex2f(121.9,43.9);
    glVertex2f(136.4,43.9);
	glVertex2f(136.4,45.9);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1,1,1);

	glVertex2f(124,32);
	glVertex2f(121.9,43.9);
    glVertex2f(136.4,43.9);
	glVertex2f(134,32);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(124,30);
	glVertex2f(124,32);
	glVertex2f(134,32);
	glVertex2f(134,30);

	glEnd();


	//2
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(142.2,54.2);
	glVertex2f(142.2,56.2);
    glVertex2f(157.8,56.2);
	glVertex2f(157.8,54.2);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1,1,1);

	glVertex2f(144.3,42.3);
	glVertex2f(142.2,54.2);
    glVertex2f(157.8,54.4);
	glVertex2f(155.9,42.2);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(144.3,40.2);
	glVertex2f(144.3,42.3);
    glVertex2f(155.9,42.3);
	glVertex2f(155.9,40.2);

	glEnd();

	//m
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(148.4,-11.8);
	glVertex2f(148.5,40.2);
	glVertex2f(151.4,40.2);
	glVertex2f(151.3,-11.8);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(145,-15);
	glVertex2f(144.9,-11.9);
	glVertex2f(154.9,-11.9);
	glVertex2f(155,-15);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(142.8,-18.8);
	glVertex2f(142.8,-15);
	glVertex2f(157.1,-15);
	glVertex2f(157.1,-18.8);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(170,26);
	glVertex2f(170,30);
	glVertex2f(172,30);
	glVertex2f(172,23.01);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,23.01);
	glVertex2f(130,26);
	glVertex2f(170,26);
	glVertex2f(172,23.01);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(124,30);
	glVertex2f(134,32);
	glVertex2f(134,32);
	glVertex2f(124,30);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,23.01);
	glVertex2f(128,30);
	glVertex2f(130,30);
	glVertex2f(130,26);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(170,45);
	glVertex2f(170,48);
	glVertex2f(172,48);
	glVertex2f(172,45);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,45);
	glVertex2f(128,48);
	glVertex2f(130,48);
	glVertex2f(130,45);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(149,56);
	glVertex2f(149,59);
	glVertex2f(151,59);
	glVertex2f(151,56);

	glEnd();

//


    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(40, 161, 32 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=51-41.1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+25.37,y+41.1);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 146, 21 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=45-37.57;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+17.4,y+37.57);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(32, 176, 23);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=45.21-39.55;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+32,y+39.5);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(34, 147, 27 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=36.39-27.67;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+12.61,y+27.67);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(24, 137, 17 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=34.3-28.42;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+18.45,y+28.42);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(21, 146, 13 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=27.5-23.13;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5.16,y+23.13);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(22, 164, 12 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=29.57-22.92;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+9.53,y+22.92);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 156, 21 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=29.94-23.7;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+16.15,y+23.7);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(21, 126, 14 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=27.44-19.84;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+16.48,y+19.84);
    }
    glEnd();//

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(18,138,10);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=34.31-29.72;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+26.44,y+29.72);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(18,138,10);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=28.73-25.33;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+25.1,y+25.33);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(36, 153, 28);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=28.7-24.17;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+29.72,y+24.17);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(21, 152, 13 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=22.02-17.13;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+33.84,y+17.13);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(36, 153, 28);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=22.36-18.14;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+40.72,y+18.14);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(21, 152, 13 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=30.58-24.21;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+42.65,y+24.21);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(33, 158, 24 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=31.9-24.32;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+36.27,y+24.32);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(30, 160, 22 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=38.3-30;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+35,y+30);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(92, 69, 14);

    glVertex2f(20,-15);
    glVertex2f(22,14);
    glVertex2f(28,14);
    glVertex2f(28,-15);

    glEnd();

   glColor3ub(101, 76, 14);
    glBegin(GL_POLYGON);

    glVertex2f(22,12);
    glVertex2f(15.9,15.65);
    glVertex2f(21.19,15.45);
    glVertex2f(23.5,13.84);

    glEnd();

    glColor3ub(109, 83, 18);
    glBegin(GL_POLYGON);

    glVertex2f(23.52,13.84);
    glVertex2f(25.58,21.19);
    glVertex2f(27.91,20.69);
    glVertex2f(26,14);

    glEnd();

    glColor3ub(101, 76, 14);
    glBegin(GL_POLYGON);

    glVertex2f(26,14);
    glVertex2f(29.89,16.7);
    glVertex2f(30.7,13.9);
    glVertex2f(28,12);

    glEnd();



//

    //border

    glBegin(GL_POLYGON);
    glColor3ub(251, 254, 80);

	glVertex2f(-26,-13);
	glVertex2f(-26,46);
	glVertex2f(-10,46);
	glVertex2f(-10,-13);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(207, 25, 114);

    glVertex2f(-28,46);
	glVertex2f(-28,50);
	glVertex2f(-8,50);
	glVertex2f(-8,46);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(131, 131, 131);

	glVertex2f(-26,44);
	glVertex2f(-26,46);
	glVertex2f(-10,46);
	glVertex2f(-10,44);

	glEnd();

	//5
	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-24,38);
	glVertex2f(-24,42);
	glVertex2f(-20,42);
	glVertex2f(-20,38);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-24.5,37);
	glVertex2f(-24.5,38);
	glVertex2f(-19.5,38);
	glVertex2f(-19.5,37);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-16,38);
	glVertex2f(-16,42);
	glVertex2f(-12,42);
	glVertex2f(-12,38);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-16.5,37);
	glVertex2f(-16.5,38);
	glVertex2f(-11.5,38);
	glVertex2f(-11.5,37);

	glEnd();

	//4
	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-24,30);
	glVertex2f(-24,34);
	glVertex2f(-20,34);
	glVertex2f(-20,30);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-24.5,29);
	glVertex2f(-24.5,30);
	glVertex2f(-19.5,30);
	glVertex2f(-19.5,29);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-16,30);
	glVertex2f(-16,34);
	glVertex2f(-12,34);
	glVertex2f(-12,30);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-16.5,29);
	glVertex2f(-16.5,30);
	glVertex2f(-11.5,30);
	glVertex2f(-11.5,29);
	glEnd();

	//3
	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-24,22);
	glVertex2f(-24,26);
	glVertex2f(-20,26);
	glVertex2f(-20,22);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-24.5,21);
	glVertex2f(-24.5,22);
	glVertex2f(-19.5,22);
	glVertex2f(-19.5,21);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-16,22);
	glVertex2f(-16,26);
	glVertex2f(-12,26);
	glVertex2f(-12,22);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-16.5,21);
	glVertex2f(-16.5,22);
	glVertex2f(-11.5,22);
	glVertex2f(-11.5,21);

	glEnd();

	//2
	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-24,14);
	glVertex2f(-24,18);
	glVertex2f(-20,18);
	glVertex2f(-20,14);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-24.5,13);
	glVertex2f(-24.5,14);
	glVertex2f(-19.5,14);
	glVertex2f(-19.5,13);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-16,14);
	glVertex2f(-16,18);
	glVertex2f(-12,18);
	glVertex2f(-12,14);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-16.5,13);
	glVertex2f(-16.5,14);
	glVertex2f(-11.5,14);
	glVertex2f(-11.5,13);

	glEnd();

	//1
	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-24,6);
	glVertex2f(-24,10);
	glVertex2f(-20,10);
	glVertex2f(-20,6);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-24.5,5);
	glVertex2f(-24.5,6);
	glVertex2f(-19.5,6);
	glVertex2f(-19.5,5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(75, 202, 242);

	glVertex2f(-16,6);
	glVertex2f(-16,10);
	glVertex2f(-12,10);
	glVertex2f(-12,6);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(14, 119, 151);

    glVertex2f(-16.5,5);
	glVertex2f(-16.5,6);
	glVertex2f(-11.5,6);
	glVertex2f(-11.5,5);

	glEnd();

	//door
	glBegin(GL_POLYGON);
    glColor3ub(207, 25, 114);

    glVertex2f(-22,-2);
	glVertex2f(-20,2);
	glVertex2f(-16,2);
	glVertex2f(-14,-2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(131, 131, 131);

	glVertex2f(-22,-3);
	glVertex2f(-22,-2);
	glVertex2f(-14,-2);
	glVertex2f(-14,-3);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(169,78,15);

    glVertex2f(-21,-10);
	glVertex2f(-21,-3);
	glVertex2f(-20,-3);
	glVertex2f(-20,-10);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(169,78,15);

	glVertex2f(-16,-10);
	glVertex2f(-16,-3);
	glVertex2f(-15,-3);
	glVertex2f(-15,-10);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(221, 138, 16);

	glVertex2f(-20,-10);
	glVertex2f(-20,-3);
	glVertex2f(-16,-3);
	glVertex2f(-16,-10);

	glEnd();

	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(32, 29, 24);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r= -0.7;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-19.2,y-6.7);
    }
    glEnd();

	glBegin(GL_POLYGON);
    glColor3ub( 66, 40, 5 );

    glVertex2f(-26,-13);
    glVertex2f(-26,-10);
	glVertex2f(-10,-10);
	glVertex2f(-10,-13);

	glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(197, 194, 189);

	glVertex2f(-21.5,-12);
	glVertex2f(-21,-10);
	glVertex2f(-15,-10);
	glVertex2f(-14.5,-12);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(153, 148, 140);

	glVertex2f(-21.5,-13);
	glVertex2f(-21.5,-12);
	glVertex2f(-14.5,-12);
	glVertex2f(-14.5,-13);

	glEnd();

}



void display()
{
	glClearColor(0,0,0,1);
	glClear(GL_COLOR_BUFFER_BIT);
	//House();
	//Tree();
	//StreetLamp();
    //Bench();
	Scenery();
    glFlush();
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Scnery");
	glutInitWindowSize(320,320);
	glutDisplayFunc(display);
	gluOrtho2D(-70,210,-50,90);
	glutMainLoop();
	return 0;
}

