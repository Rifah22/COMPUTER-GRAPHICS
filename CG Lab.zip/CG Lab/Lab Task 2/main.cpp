#include <windows.h>
#include <GL/glut.h>
#include <math.h>

void Batman_Logo()
{
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-5,5);
    glVertex2f(-1.53,5.01);
    glVertex2f(1.53,5.01);
    glVertex2f(5,5);
    glVertex2f(3.01,2.97);
    glVertex2f(-0.002,1.952);
    glVertex2f(-3.01,2.98);

    glEnd();
}

void Curve()
{
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(255,255,255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5-3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5,y+3);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(255,255,255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1.2-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+2,y+1 );
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(255,255,255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1.2-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-2,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(255,255,255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5-3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-5,y+3 );
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(255,255,255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=6.7-4.01;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x,y+6.7);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(0,0,0);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x,y+4.01);
    }
    glEnd();
}

void Ear()
{
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-1.03,5.61);
    glVertex2f(0,3.5);
    glVertex2f(-1.2,4.01);

    glEnd();

    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(1.03,5.61);
    glVertex2f(0,3.5);
    glVertex2f(1.2,4.02);

    glEnd();

}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    Batman_Logo();
    Curve();
    Ear();
    glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("Batman_Logo");
	glutInitWindowSize(320,320);
	glutInitWindowPosition(50,50);
	glutDisplayFunc(display);
	gluOrtho2D(-10,10,-10,10);
	glutMainLoop();
	return 0;
}

/*void ChessBoard()
{
	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(1,1);
	glVertex2f(1,0);
	glVertex2f(0,0);
	glVertex2f(0,1);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(2,2);
	glVertex2f(2,1);
	glVertex2f(1,1);
	glVertex2f(1,2);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(0,2);
	glVertex2f(0,1);
	glVertex2f(-1,1);
	glVertex2f(-1,2);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(-1,1);
	glVertex2f(-1,0);
	glVertex2f(-2,0);
	glVertex2f(-2,1);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(0,0);
	glVertex2f(0,-1);
	glVertex2f(-1,-1);
	glVertex2f(-1,0);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(-1,-1);
	glVertex2f(-1,-2);
	glVertex2f(-2,-2);
	glVertex2f(-2,-1);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(2,0);
	glVertex2f(2,-1);
	glVertex2f(1,-1);
	glVertex2f(1,0);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0,0,0);
	glVertex2f(1,-1);
	glVertex2f(1,-2);
	glVertex2f(0,-2);
	glVertex2f(0,-1);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex2f(-2,2);
	glVertex2f(2,2);

	glEnd();

	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex2f(2,-2);
	glVertex2f(2,2);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex2f(-2,-2);
	glVertex2f(2,-2);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex2f(-2,2);
	glVertex2f(2,2);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex2f(-2,-2);
	glVertex2f(-2,2);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0,0,0);
	glVertex2f(2,2);
	glVertex2f(2,-2);
	glEnd();
}
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    ChessBoard();
    glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("ChessBoard");
	glutInitWindowSize(320, 320);
	glutInitWindowPosition(50, 50);
	glutDisplayFunc(display);
	gluOrtho2D(-3,3,-3,3);
	glutMainLoop();
	return 0;
}*/

/*void Rainbow()
{
    glBegin(GL_POLYGON);
    glColor3f(0.61,0.47,0.82);

    glVertex2f(-3,3);
    glVertex2f(3,3);
    glVertex2f(3,2.42);
    glVertex2f(-3,2.4);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.27,0.57,0.79 );

    glVertex2f(-3,2.4);
    glVertex2f(3,2.42);
    glVertex2f(3,1.8);
    glVertex2f(-3,1.8);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.38,0.81,0.85);

    glVertex2f(-3,1.8);
    glVertex2f(3,1.8);
    glVertex2f(3,1.22);
    glVertex2f(-3,1.2);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.15,0.79,0.27);

    glVertex2f(-3,1.2);
    glVertex2f(3,1.22);
    glVertex2f(3,0.56);
    glVertex2f(-3,0.56);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.98,0.64,0.39);

    glVertex2f(-3,0.56);
    glVertex2f(3,0.56);
    glVertex2f(3,-0.16);
    glVertex2f(-3,-0.16);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(1,1,0);

    glVertex2f(-3,-0.16);
    glVertex2f(3,-0.16);
    glVertex2f(3,-0.8);
    glVertex2f(-3,-0.8);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(1,0,0);

    glVertex2f(-3,-0.8);
    glVertex2f(3,-0.8);
    glVertex2f(3,-1.5);
    glVertex2f(-3,-1.5);

    glEnd();
}

void Line()
{
    glLineWidth(2);
    glBegin(GL_LINES);
    glColor3f(0,0,0);

    glVertex2f(-3,3);
    glVertex2f(3,3);
    glVertex2f(3,2.42);
    glVertex2f(-3,2.4);

    glVertex2f(-3,2.4);
    glVertex2f(3,2.42);
    glVertex2f(3,1.8);
    glVertex2f(-3,1.8);

    glVertex2f(-3,1.8);
    glVertex2f(3,1.8);
    glVertex2f(3,1.22);
    glVertex2f(-3,1.2);

    glVertex2f(-3,1.2);
    glVertex2f(3,1.22);
    glVertex2f(3,0.56);
    glVertex2f(-3,0.56);

    glVertex2f(-3,0.56);
    glVertex2f(3,0.56);
    glVertex2f(3,-0.16);
    glVertex2f(-3,-0.16);

    glVertex2f(-3,-0.16);
    glVertex2f(3,-0.16);
    glVertex2f(3,-0.8);
    glVertex2f(-3,-0.8);

    glVertex2f(-3,-0.8);
    glVertex2f(3,-0.8);
    glVertex2f(3,-1.5);
    glVertex2f(-3,-1.5);

    glVertex2f(3,3);
    glVertex2f(3,-1.5);
    glVertex2f(-3,3);
    glVertex2f(-3,-1.5);

    glEnd();
}
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    Rainbow();
    Line();
    glFlush();

}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
    glutInitWindowSize(500,500);
    glutCreateWindow("OpenGL Rainbow");
    glutDisplayFunc(display);
    gluOrtho2D(-10,10,-10,10);
    glutMainLoop();
    return 0;
}*/

