#include <iostream>
#include<GL/gl.h>
#include <GL/glut.h>
using namespace std;

float _move = 0.0f;
float _move1 = 0.0f;
void drawScene()
{
glClear(GL_COLOR_BUFFER_BIT);
glColor3d(1,0,0);
glLoadIdentity(); //Reset the drawing perspective
glMatrixMode(GL_MODELVIEW);

glPushMatrix();
glTranslatef(_move, 0.0f, 0.0f);
glBegin(GL_QUADS);
glVertex2f(2,2);
glVertex2f(2,3);
glVertex2f(5,3);
glVertex2f(5,2);
glEnd();
glPopMatrix();
glutSwapBuffers();
}
void drawScene1()
{
glClear(GL_COLOR_BUFFER_BIT);
glColor3d(1,0,0);
glLoadIdentity(); //Reset the drawing perspective
glMatrixMode(GL_MODELVIEW);

glPushMatrix();
glTranslatef(_move, 0.0f, 0.0f);
glBegin(GL_QUADS);
glVertex2f(2,4);
glVertex2f(2,5);
glVertex2f(5,5);
glVertex2f(5,4);
glEnd();
glPopMatrix();
glutSwapBuffers();
}
void update(int value) {
    // Update the position of the first box
    _move -= 0.05;
    if (_move < 6) {
        _move = 6.0;
    }

    // Update the position of the second box
    _move1 += 0.05;
    if (_move1 > 6) {
        _move1 = -6.0;
    }

    glutPostRedisplay();
    glutTimerFunc(10, update, 0);

}



int main(int argc, char** argv) {
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
glutInitWindowSize(800, 800);
glutCreateWindow("Transformation");
glClearColor(0,0,0,1);
glutDisplayFunc(drawScene);
glutDisplayFunc(drawScene1);
gluOrtho2D(0,7,0,7);
glutTimerFunc(10, update, 0); //Add a timer
glutMainLoop();
return 0;
}
