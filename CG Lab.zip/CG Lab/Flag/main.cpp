#include <windows.h>
#include <GL/glut.h>
#include <math.h>

/////flag2

void flag_3()
{
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(2,5);
    glVertex2f(10,5);
    glVertex2f(10,1);
    glVertex2f(2,1);

    glEnd();
    //white1

    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2,5);
    glVertex2f(3,5);
    glVertex2f(3,1);
    glVertex2f(2,1);

    glEnd();



    //blue
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(3,5);
    glVertex2f(5,5);
    glVertex2f(4.97,3.22);
    glVertex2f(3,3.26);

    glEnd();

    //white star
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.87,4.85);
    glVertex2f(4.06,4.39);
    glVertex2f(4.53,4.38);
    glVertex2f(4.17,4.13);
    glVertex2f(4.41,3.53);
    glVertex2f(3.88,3.92);
    glVertex2f(3.36,3.56);
    glVertex2f(3.59,4.14);
    glVertex2f(3.21,4.41);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(9,5);
    glVertex2f(10,5);
    glVertex2f(10,1);
    glVertex2f(9,1);

    glEnd();

    //allLine
    //red1
    glColor3ub(1,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(5,5);
    glVertex2f(9,5);
    glVertex2f(9,4.62);
    glVertex2f(5,4.62);

    glEnd();

    //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(5,4.62);
    glVertex2f(9,4.62);
    glVertex2f(9,4.28);
    glVertex2f(5,4.28);

    glEnd();

    //red2
    glColor3ub(1,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(5,4.28);
    glVertex2f(9,4.28);
    glVertex2f(9,3.89);
    glVertex2f(5,3.89);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(5,3.89);
    glVertex2f(9,3.89);
    glVertex2f(9,3.53);
    glVertex2f(5,3.53);

    glEnd();

    //red3
    glColor3ub(1,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(5,3.53);
    glVertex2f(9,3.53);
    glVertex2f(9,3.21);
    glVertex2f(5,3.21);

    glEnd();

    //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3,3.21);
    glVertex2f(9,3.21);
    glVertex2f(9,2.86);
    glVertex2f(3,2.9);

    glEnd();

    //red4
    glColor3ub(1,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(3,2.9);
    glVertex2f(9,2.86);
    glVertex2f(9,2.5);
    glVertex2f(3,2.5);

    glEnd();//

    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-9,-3.65);
    glVertex2f(-1,-3.65);
    glVertex2f(-1,-4.1);
    glVertex2f(-9,-4.1);

    glEnd();

    glColor3ub(1,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-9,-4.5);
    glVertex2f(-1,-4.5);
    glVertex2f(-1,-5);
    glVertex2f(-9,-5);

    glEnd();
}
void display()
{
    glClearColor(0,0,1,0);
    glClear(GL_COLOR_BUFFER_BIT);
    flag_3();
    glFlush();
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutCreateWindow("Flag_3");
    glutInitWindowSize(320,320);
    glutDisplayFunc(display);
    gluOrtho2D(-20,20,-20,20);
    glutMainLoop();

    return 0;
}

/*
/////flag2

void flag_1()

{

    glColor3ub(90, 198, 249);

    glBegin(GL_POLYGON);

    glVertex2f(-9,6);

    glVertex2f(-3,6);

    glVertex2f(-3,2);

    glVertex2f(-9,2);

    glEnd();

    glColor3ub(255,255,255);

    glBegin(GL_POLYGON);

    glVertex2f(-6.06,4.8);

    glVertex2f(-6,4.9);

    glVertex2f(-5.94,4.8);

    glVertex2f(-5.8,4.8);

    glVertex2f(-5.9,4.7);

    glVertex2f(-5.85,4.55);

    glVertex2f(-6,4.65);

    glVertex2f(-6.15,4.55);

    glVertex2f(-6.1,4.7);

    glVertex2f(-6.2,4.8);

    glEnd();

    glBegin(GL_POLYGON);

    glVertex2f(-7.26,3.98);

    glVertex2f(-7.2,4.1);

    glVertex2f(-7.14,3.98);

    glVertex2f(-7,3.98);

    glVertex2f(-7.12,3.88);

    glVertex2f(-7.04,3.74);

    glVertex2f(-7.2,3.8);

    glVertex2f(-7.36,3.74);

    glVertex2f(-7.28,3.88);

    glVertex2f(-7.4,3.98);

    glEnd();

    glBegin(GL_POLYGON);

    glVertex2f(-6.08,3.38);

    glVertex2f(-6,3.5);

    glVertex2f(-5.94,3.38);

    glVertex2f(-5.82,3.38);

    glVertex2f(-5.94,3.28);

    glVertex2f(-5.84,3.14);

    glVertex2f(-6,3.22);

    glVertex2f(-6.16,3.14);

    glVertex2f(-6.08,3.28);

    glVertex2f(-6.2,3.38);

    glEnd();

    glBegin(GL_POLYGON);

    glVertex2f(-4.86,4.02);

    glVertex2f(-4.81,4.14);

    glVertex2f(-4.76,4.02);

    glVertex2f(-4.64,4.02);

    glVertex2f(-4.72,3.92);

    glVertex2f(-4.68,3.78);

    glVertex2f(-4.81,3.84);

    glVertex2f(-4.94,3.78);

    glVertex2f(-4.88,3.92);

    glVertex2f(-4.98,4.02);

    glEnd();

}

//2

void flag_2()

{

     glColor3ub(199, 0, 57);

    glBegin(GL_POLYGON);

    glVertex2f(3.5,6);

    glVertex2f(10.5,6);

    glVertex2f(10.5,2);

    glVertex2f(3.5,2);

    glEnd();

    glColor3ub(9, 110, 8);

    glLineWidth(8);

    glBegin(GL_LINES);

    glVertex2f(7,5.2);

    glVertex2f(8,2.8);

    glVertex2f(8,2.8);

    glVertex2f(5.6,4.2);

    glVertex2f(5.6,4.2);

    glVertex2f(8.4,4.2);

    glVertex2f(8.4,4.2);

    glVertex2f(6,2.8);

    glVertex2f(6,2.8);

    glVertex2f(7,5.2);

    glEnd();

}

void flag_3()

{

    glColor3ub(14, 15, 221);

    glBegin(GL_POLYGON);

    glVertex2f(3,-1.8);

    glVertex2f(10,-1.8);

    glVertex2f(10,-3.2);

    glVertex2f(3,-3.2);

    glEnd();

    glColor3ub(255,255,255);

    glBegin(GL_POLYGON);

    glVertex2f(10,-3.2);

    glVertex2f(3,-3.2);

    glVertex2f(3,-4.6);

    glVertex2f(10,-4.6);

    glEnd();

    glColor3ub(255,0,0);

    glBegin(GL_POLYGON);

    glVertex2f(3,-4.6);

    glVertex2f(10,-4.6);

    glVertex2f(10,-6);

    glVertex2f(3,-6);

    glEnd();

    glColor3ub(255,0,0);

    glBegin(GL_POLYGON);

    glVertex2f(6.2,-3.4);

    glVertex2f(6.5,-2.7);

    glVertex2f(6.8,-3.4);

    glVertex2f(7.8,-3.4);

    glVertex2f(7.1,-3.9);

    glVertex2f(7.6,-4.8);

    glVertex2f(6.5,-4.2);

    glVertex2f(5.4,-4.8);

    glVertex2f(6,-3.9);

    glVertex2f(5.3,-3.4);

    glEnd();

    glColor3ub(255,255,0);

    glLineWidth(4);

    glBegin(GL_LINES);

    glVertex2f(6.2,-3.4);

    glVertex2f(6.5,-2.7);

    glVertex2f(6.5,-2.7);

    glVertex2f(6.8,-3.4);

    glVertex2f(6.8,-3.4);

    glVertex2f(7.8,-3.4);

    glVertex2f(7.8,-3.4);

    glVertex2f(7.1,-3.9);

    glVertex2f(7.1,-3.9);

    glVertex2f(7.6,-4.8);

    glVertex2f(7.6,-4.8);

    glVertex2f(6.5,-4.2);

    glVertex2f(6.5,-4.2);

    glVertex2f(5.4,-4.8);

    glVertex2f(5.4,-4.8);

    glVertex2f(5.96,-3.9);

    glVertex2f(5.96,-3.9);

    glVertex2f(5.3,-3.4);

    glVertex2f(5.3,-3.4);

    glVertex2f(6.2,-3.4);

    glEnd();

}

flag_4()

{

     glColor3ub(14, 15, 221);

    glBegin(GL_POLYGON);

    glVertex2f(-10,-1.8);

    glVertex2f(-2,-1.8);

    glVertex2f(-2,-2.8);

    glVertex2f(-10,-2.8);

    glEnd();

    glColor3ub(255,255,255);

    glBegin(GL_POLYGON);

    glVertex2f(-2,-2.8);

    glVertex2f(-10,-2.8);

    glVertex2f(-10,-5.2);

    glVertex2f(-2,-5.2);

    glEnd();

    glColor3ub(14, 15, 221);

    glBegin(GL_POLYGON);

    glVertex2f(-10,-5.2);

    glVertex2f(-2,-5.2);

    glVertex2f(-2,-6.2);

    glVertex2f(-10,-6.2);

    glEnd();

    glColor3ub(14, 15, 221);

    glLineWidth(8);

    glBegin(GL_LINES);

    glVertex2f(-7.4,-3.5);

    glVertex2f(-4.6,-3.5);

    glVertex2f(-4.6,-3.5);

    glVertex2f(-6,-5);

    glVertex2f(-6,-5);

    glVertex2f(-7.4,-3.5);

    glVertex2f(-6,-3);

    glVertex2f(-4.6,-4.5);

    glVertex2f(-4.6,-4.5);

    glVertex2f(-7.4,-4.5);

    glVertex2f(-7.4,-4.5);

    glVertex2f(-6,-3);

    glEnd();

}

void display()

{

	glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color to black and opaque

	glClear(GL_COLOR_BUFFER_BIT);

	flag_1();

	flag_2();

	flag_3();

	flag_4();

    glFlush();  // Render now

}

int main(int argc, char** argv)
{

	glutInit(&argc, argv);

	glutCreateWindow("Flag_2");

	glutInitWindowSize(320, 320);

	glutDisplayFunc(display);

	gluOrtho2D(-12,12,-9,9);

	glutMainLoop();

	return 0;

}*/

   ///////////////


/*void flag_4()
{
    //1st

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(1,7);
    glVertex2f(10,7);
    glVertex2f(10,1);
    glVertex2f(1,1);

    glEnd();

    //blue
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(1,3.8);
    glVertex2f(1,7);
    glVertex2f(3.8,7);
    glVertex2f(3.8,3.8);

    glEnd();

    //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.3,6.9);
    glVertex2f(1.4,6.8);
    glVertex2f(1.6,6.8);
    glVertex2f(1.5,6.6);
    glVertex2f(1.5,6.4);
    glVertex2f(1.3,6.5);
    glVertex2f(1.2,6.4);
    glVertex2f(1.2,6.6);
    glVertex2f(1.1,6.8);
    glVertex2f(1.2,6.8);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.2,6.9);
    glVertex2f(2.2,6.7);
    glVertex2f(2.5,6.7);
    glVertex2f(2.3,6.6);
    glVertex2f(2.4,6.4);
    glVertex2f(2.2,6.5);
    glVertex2f(2,6.4);
    glVertex2f(2,6.6);
    glVertex2f(1.9,6.7);
    glVertex2f(2.1,6.7);

    glEnd();

    //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.9,6.9);
    glVertex2f(3.1,6.7);
    glVertex2f(3.3,6.8);
    glVertex2f(3.1,6.6);
    glVertex2f(3.2,6.4);
    glVertex2f(2.9,6.5);
    glVertex2f(2.8,6.4);
    glVertex2f(2.9,6.6);
    glVertex2f(2.7,6.7);
    glVertex2f(2.9,6.8);

    glEnd();

    //white4
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.7,6.3);
    glVertex2f(1.8,6.1);
    glVertex2f(2,6.1);
    glVertex2f(1.8,6);
    glVertex2f(1.9,5.8);
    glVertex2f(1.7,5.9);
    glVertex2f(1.6,5.8);
    glVertex2f(1.6,6);
    glVertex2f(1.5,6.1);
    glVertex2f(1.7,6.1);

    glEnd();

    //white5
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.5,6.4);
    glVertex2f(2.6,6.1);
    glVertex2f(2.8,6.1);
    glVertex2f(2.6,6);
    glVertex2f(2.7,5.8);
    glVertex2f(2.5,5.9);
    glVertex2f(2.4,5.8);
    glVertex2f(2.4,6);
    glVertex2f(2.1,6.1);
    glVertex2f(2.5,6.1);

    glEnd();

    //white6
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.3,6.5);
    glVertex2f(3.4,6.1);
    glVertex2f(3.6,6.1);
    glVertex2f(3.4,6);
    glVertex2f(3.5,5.8);
    glVertex2f(3.3,5.9);
    glVertex2f(3.2,5.8);
    glVertex2f(3.2,6);
    glVertex2f(3.1,6.1);
    glVertex2f(3.3,6.1);

    glEnd();

    //white7
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.3,5.7);
    glVertex2f(1.4,5.5);
    glVertex2f(1.6,5.6);
    glVertex2f(1.4,5.4);
    glVertex2f(1.5,5.2);
    glVertex2f(1.3,5.3);
    glVertex2f(1.2,5.2);
    glVertex2f(1.2,5.4);
    glVertex2f(1.1,5.5);
    glVertex2f(1.3,5.5);

    glEnd();

    //white8
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.1,5.7);
    glVertex2f(2.2,5.5);
    glVertex2f(2.4,5.5);
    glVertex2f(2.3,5.4);
    glVertex2f(2.3,5.2);
    glVertex2f(2.1,5.3);
    glVertex2f(2,5.2);
    glVertex2f(2.1,5.4);
    glVertex2f(1.9,5.5);
    glVertex2f(2.1,5.5);

    glEnd();

    //white9
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.9,5.7);
    glVertex2f(3,5.5);
    glVertex2f(3.2,5.5);
    glVertex2f(3.1,5.4);
    glVertex2f(3.1,5.2);
    glVertex2f(2.9,5.3);
    glVertex2f(2.8,5.2);
    glVertex2f(2.9,5.4);
    glVertex2f(2.7,5.5);
    glVertex2f(2.9,5.5);

    glEnd();

    //white10
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.7,5.1);
    glVertex2f(1.8,4.9);
    glVertex2f(1.9,4.9);
    glVertex2f(1.8,4.8);
    glVertex2f(1.9,4.6);
    glVertex2f(1.7,4.7);
    glVertex2f(1.6,4.6);
    glVertex2f(1.6,4.8);
    glVertex2f(1.4,4.9);
    glVertex2f(1.6,4.9);

    glEnd();

    //white11
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.5,5.2);
    glVertex2f(2.6,4.9);
    glVertex2f(2.7,4.9);
    glVertex2f(2.6,4.8);
    glVertex2f(2.7,4.6);
    glVertex2f(2.5,4.7);
    glVertex2f(2.4,4.6);
    glVertex2f(2.4,4.8);
    glVertex2f(2.2,4.9);
    glVertex2f(2.4,4.9);

    glEnd();

    //white12
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.3,5.3);
    glVertex2f(3.4,4.9);
    glVertex2f(3.5,4.9);
    glVertex2f(3.4,4.8);
    glVertex2f(3.5,4.6);
    glVertex2f(3.3,4.7);
    glVertex2f(3.2,4.6);
    glVertex2f(3.2,4.8);
    glVertex2f(3,4.9);
    glVertex2f(3.2,4.9);

    glEnd();

    //white13
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.4,4.5);
    glVertex2f(1.4,4.3);
    glVertex2f(1.6,4.3);
    glVertex2f(1.5,4.1);
    glVertex2f(1.5,4);
    glVertex2f(1.4,4.1);
    glVertex2f(1.2,4);
    glVertex2f(1.3,4.1);
    glVertex2f(1.1,4.3);
    glVertex2f(1.3,4.3);

    glEnd();

    //white14
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.2,4.6);
    glVertex2f(2.2,4.3);
    glVertex2f(2.4,4.3);
    glVertex2f(2.4,4.2);
    glVertex2f(2.3,4);
    glVertex2f(2.2,4.1);
    glVertex2f(2,4);
    glVertex2f(2.1,4.1);
    glVertex2f(1.9,4.3);
    glVertex2f(2.1,4.3);

    glEnd();

    //white15
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3,4.6);
    glVertex2f(3,4.3);
    glVertex2f(3.2,4.3);
    glVertex2f(3.2,4.2);
    glVertex2f(3.3,4);
    glVertex2f(2.8,4.1);
    glVertex2f(2.8,4);
    glVertex2f(2.9,4.1);
    glVertex2f(2.7,4.3);
    glVertex2f(2.9,4.3);

    glEnd();




    //all line
    //red1
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,6.6);
    glVertex2f(3.8,7);
    glVertex2f(10,7);
    glVertex2f(10,6.6);

    glEnd();

    //red2
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,5.8);
    glVertex2f(3.8,6.2);
    glVertex2f(10,6.2);
    glVertex2f(10,5.8);

    glEnd();

    //red3
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,4.6);
    glVertex2f(3.8,5.4);
    glVertex2f(10,5.4);
    glVertex2f(10,5);

    glEnd();

    //red4
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,4.2);
    glVertex2f(3.8,4.6);
    glVertex2f(10,4.6);
    glVertex2f(10,4.2);

    glEnd();

    //red5
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,3.4);
    glVertex2f(1,3.8);
    glVertex2f(10,3.8);
    glVertex2f(10,3.4);

    glEnd();

     //red6
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,2.6);
    glVertex2f(1,3);
    glVertex2f(10,3);
    glVertex2f(10,2.6);

    glEnd();

     //red7
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,1.8);
    glVertex2f(1,2.2);
    glVertex2f(10,2.2);
    glVertex2f(10,1.8);

    glEnd();

     //red8
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,1);
    glVertex2f(1,1.4);
    glVertex2f(10,1.4);
    glVertex2f(10,1);

    glEnd();


    //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,6.2);
    glVertex2f(3.8,6.6);
    glVertex2f(10,6.6);
    glVertex2f(10,6.2);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,5.4);
    glVertex2f(3.8,5.8);
    glVertex2f(10,5.8);
    glVertex2f(10,5.4);

    glEnd();

    //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,4.6);
    glVertex2f(3.8,5);
    glVertex2f(10,5);
    glVertex2f(10,4.6);

    glEnd();

    //white4
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.8,3.8);
    glVertex2f(3.8,4.2);
    glVertex2f(10,4.2);
    glVertex2f(10,3.8);

    glEnd();

    //white5
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1,3);
    glVertex2f(1,3.4);
    glVertex2f(10,3.4);
    glVertex2f(10,3);

    glEnd();

    //white6
    glColor3ub(255,255,255 );
    glBegin(GL_POLYGON);

    glVertex2f(1,2.2);
    glVertex2f(1,2.6);
    glVertex2f(10,2.6);
    glVertex2f(10,2.2);

    glEnd();

    //white7
    glColor3ub(255,255,255 );
    glBegin(GL_POLYGON);

    glVertex2f(1,1.4);
    glVertex2f(1,1.8);
    glVertex2f(10,1.8);
    glVertex2f(10,1.4);

    glEnd();


    //2nd

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-10,7);
    glVertex2f(-1,7);
    glVertex2f(-1,1);
    glVertex2f(-10,1);

    glEnd();

    //blue
    glColor3ub(29,59,141);
    glBegin(GL_POLYGON);

    glVertex2f(-10,7);
    glVertex2f(-1,7);
    glVertex2f(-1,1);
    glVertex2f(-10,1);

    glEnd();

    //yellow1
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-5.5,6.4);
    glVertex2f(-5.4,6.1);
    glVertex2f(-5.1,6.1);
    glVertex2f(-5.4,5.9);
    glVertex2f(-5.3,5.7);
    glVertex2f(-5.5,5.9);
    glVertex2f(-5.7,5.7);
    glVertex2f(-5.6,5.9);
    glVertex2f(-5.9,6.1);
    glVertex2f(-5.6,6.1);

    glEnd();

     //yellow2
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-4.5,6);
    glVertex2f(-4.4,5.8);
    glVertex2f(-4.2,5.8);
    glVertex2f(-4.4,5.6);
    glVertex2f(-4.3,5.4);
    glVertex2f(-4.5,5.6);
    glVertex2f(-4.7,5.4);
    glVertex2f(-4.6,5.7);
    glVertex2f(-4.8,5.8);
    glVertex2f(-4.6,5.8);

    glEnd();

      //yellow3
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-3.9,5.4);
    glVertex2f(-3.8,5.2);
    glVertex2f(-3.5,5.2);
    glVertex2f(-3.7,5);
    glVertex2f(-3.6,4.8);
    glVertex2f(-3.9,4.9);
    glVertex2f(-4,4.8);
    glVertex2f(-3.9,5);
    glVertex2f(-4.1,5.1);
    glVertex2f(-3.9,5.1);

    glEnd();

     //yellow4
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-3.5,4.4);
    glVertex2f(-3.4,4.2);
    glVertex2f(-3.2,4.2);
    glVertex2f(-3.4,4.1);
    glVertex2f(-3.3,3.8);
    glVertex2f(-3.5,3.9);
    glVertex2f(-3.7,3.8);
    glVertex2f(-3.6,4.1);
    glVertex2f(-3.8,4.2);
    glVertex2f(-3.6,4.2);

    glEnd();

     //yellow5
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-3.6,3.4);
    glVertex2f(-3.6,3.2);
    glVertex2f(-3.3,3.2);
    glVertex2f(-3.5,3.1);
    glVertex2f(-3.5,2.9);
    glVertex2f(-3.6,3);
    glVertex2f(-3.8,2.9);
    glVertex2f(-3.7,3.1);
    glVertex2f(-3.9,3.2);
    glVertex2f(-3.7,3.2);

    glEnd();

     //yellow6
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-4.3,2.6);
    glVertex2f(-4.2,2.4);
    glVertex2f(-4,2.4);
    glVertex2f(-4.2,2.3);
    glVertex2f(-4.1,2.1);
    glVertex2f(-4.3,2.2);
    glVertex2f(-4.5,2.1);
    glVertex2f(-4.4,2.3);
    glVertex2f(-4.6,2.4);
    glVertex2f(-4.4,2.4);

    glEnd();

     //yellow7
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-5.4,2.3);
    glVertex2f(-5.4,2.1);
    glVertex2f(-5.1,2.1);
    glVertex2f(-5.3,1.9);
    glVertex2f(-5.2,1.7);
    glVertex2f(-5.4,1.9);
    glVertex2f(-5.6,1.7);
    glVertex2f(-5.5,1.9);
    glVertex2f(-5.7,2.1);
    glVertex2f(-5.5,2.1);

    glEnd();

     //yellow8
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-6.5,2.5);
    glVertex2f(-6.5,2.3);
    glVertex2f(-6.3,2.3);
    glVertex2f(-6.4,2.1);
    glVertex2f(-6.3,1.9);
    glVertex2f(-6.5,2.1);
    glVertex2f(-6.7,1.9);
    glVertex2f(-6.6,2.1);
    glVertex2f(-6.8,2.2);
    glVertex2f(-6.6,2.3);

    glEnd();

     //yellow9
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-7.3,3.3);
    glVertex2f(-7.2,3.1);
    glVertex2f(-7,3.1);
    glVertex2f(-7.2,2.9);
    glVertex2f(-7.1,2.7);
    glVertex2f(-7.3,2.9);
    glVertex2f(-7.5,2.7);
    glVertex2f(-7.4,2.9);
    glVertex2f(-7.6,3);
    glVertex2f(-7.4,3.1);

    glEnd();

     //yellow10
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-7.5,4.3);
    glVertex2f(-7.4,4);
    glVertex2f(-7.2,4);
    glVertex2f(-7.4,3.9);
    glVertex2f(-7.3,3.7);
    glVertex2f(-7.5,3.8);
    glVertex2f(-7.7,3.7);
    glVertex2f(-7.6,3.9);
    glVertex2f(-7.8,4);
    glVertex2f(-7.6,4);

    glEnd();

     //yellow11
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-7.3,5.3);
    glVertex2f(-7.1,5.1);
    glVertex2f(-6.9,5.1);
    glVertex2f(-7.1,4.9);
    glVertex2f(-7.1,4.7);
    glVertex2f(-7.2,4.8);
    glVertex2f(-7.4,4.7);
    glVertex2f(-7.4,4.9);
    glVertex2f(-7.5,5.1);
    glVertex2f(-7.3,5.1);

    glEnd();

     //yellow12
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-6.5,5.9);
    glVertex2f(-6.4,5.7);
    glVertex2f(-6.2,5.7);
    glVertex2f(-6.4,5.6);
    glVertex2f(-6.3,5.4);
    glVertex2f(-6.5,5.5);
    glVertex2f(-6.7,5.4);
    glVertex2f(-6.6,5.6);
    glVertex2f(-6.8,5.7);
    glVertex2f(-6.6,5.7);

    glEnd();



    //3rd

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-1);
    glVertex2f(-1,-1);
    glVertex2f(-1,-6.22);
    glVertex2f(-10,-6.2);

    glEnd();

    //redmidddle
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(-10,-2.6);
    glVertex2f(-10,-2.2);
    glVertex2f(-8.7,-2.2);
    glVertex2f(-8.7,-1);
    glVertex2f(-8.3,-1);
    glVertex2f(-8.3,-2.2);
    glVertex2f(-7,-2.2);
    glVertex2f(-7,-2.6);
    glVertex2f(-8.3,-2.6);
    glVertex2f(-8.3,-3.8);
    glVertex2f(-8.7,-3.8);
    glVertex2f(-8.7,-2.6);

    glEnd();

    //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-2.2);
    glVertex2f(-10,-2);
    glVertex2f(-9.2,-2);
    glVertex2f(-10,-1.3);
    glVertex2f(-10,-1);
    glVertex2f(-9.7,-1);
    glVertex2f(-8.9,-1.7);
    glVertex2f(-8.9,-1);
    glVertex2f(-8.7,-1);
    glVertex2f(-8.7,-2.2);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-8.3,-2.2);
    glVertex2f(-8.3,-1);
    glVertex2f(-8.1,-1);
    glVertex2f(-8.1,-1.7);
    glVertex2f(-7.2,-1);
    glVertex2f(-7,-1);
    glVertex2f(-7,-1.2);
    glVertex2f(-7.9,-1.9);
    glVertex2f(-7,-1.9);
    glVertex2f(-7,-2.2);

    glEnd();

    //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-8.3,-3.8);
    glVertex2f(-8.3,-2.6);
    glVertex2f(-7,-2.6);
    glVertex2f(-7,-2.8);
    glVertex2f(-7.9,-2.8);
    glVertex2f(-7,-3.5);
    glVertex2f(-7,-3.8);
    glVertex2f(-7.1,-3.8);
    glVertex2f(-8.1,-3.1);
    glVertex2f(-8.1,-3.8);

    glEnd();

     //white4
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-3.8);
    glVertex2f(-10,-3.5);
    glVertex2f(-9.2,-2.8);
    glVertex2f(-10,-2.8);
    glVertex2f(-10,-2.6);
    glVertex2f(-8.7,-2.6);
    glVertex2f(-8.7,-3.8);
    glVertex2f(-8.9,-3.8);
    glVertex2f(-8.9,-3.1);
    glVertex2f(-9.7,-3.8);

    glEnd();

    //blue1
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-2);
    glVertex2f(-10,-1.3);
    glVertex2f(-9.2,-2);

    glEnd();

    //blue2
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-9.7,-1);
    glVertex2f(-8.9,-1);
    glVertex2f(-8.9,-1.7);

    glEnd();

    //blue3
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-8.1,-1.7);
    glVertex2f(-8.1,-1);
    glVertex2f(-7.2,-1);

    glEnd();

    //blue4
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-7.9,-1.9);
    glVertex2f(-7,-1.2);
    glVertex2f(-7,-1.4);
    glVertex2f(-7,-1.8);
    glVertex2f(-7,-1.9);



    glEnd();

    //blue5
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-7.9,-2.8);
    glVertex2f(-7,-2.8);
    glVertex2f(-7,-3);
    glVertex2f(-7,-3.4);
    glVertex2f(-7,-3.5);


    glEnd();

    //blue6
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-8.1,-3.8);
    glVertex2f(-8.1,-3.1);
    glVertex2f(-7.1,-3.8);

    glEnd();

    //blue7
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-9.7,-3.8);
    glVertex2f(-8.9,-3.1);
    glVertex2f(-8.9,-3.8);

    glEnd();

    //blue8
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-3.5);
    glVertex2f(-10,-2.8);
    glVertex2f(-9.2,-2.8);

    glEnd();

    //all line
    //red1
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-1.4);
    glVertex2f(-7,-1.2);
    glVertex2f(-7,-1);
    glVertex2f(-1,-1);
    glVertex2f(-1,-1.4);

    glEnd();

    //red2
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-2.2);
    glVertex2f(-7,-1.9);
    glVertex2f(-7,-1.8);
    glVertex2f(-1,-1.8);
    glVertex2f(-1,-2.2);

    glEnd();

    //red3
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-3);
    glVertex2f(-7,-2.8);
    glVertex2f(-7,-2.6);
    glVertex2f(-1,-2.6);
    glVertex2f(-1,-3);

    glEnd();

    //red4
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-3.8);
    glVertex2f(-7,-3.5);
    glVertex2f(-7,-3.4);
    glVertex2f(-1,-3.4);
    glVertex2f(-1,-3.8);

    glEnd();

    //red5
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(-10,-4.6);
    glVertex2f(-10,-4.2);
    glVertex2f(-1,-4.2);
    glVertex2f(-1,-4.6);

    glEnd();

     //red6
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(-10,-5.4);
    glVertex2f(-10,-5);
    glVertex2f(-1,-5);
    glVertex2f(-1,-5.4);

    glEnd();

     //red7
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(-10,-6.2);
    glVertex2f(-10,-5.8);
    glVertex2f(-1,-5.8);
    glVertex2f(-1,-6.22);

    glEnd();


    //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-1.8);
    glVertex2f(-7,-1.4);
    glVertex2f(-1,-1.4);
    glVertex2f(-1,-1.8);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-2.6);
    glVertex2f(-7,-2.2);
    glVertex2f(-1,-2.2);
    glVertex2f(-1,-2.6);

    glEnd();

    //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-7,-3.4);
    glVertex2f(-7,-3);
    glVertex2f(-1,-3);
    glVertex2f(-1,-3.4);

    glEnd();

    //white4
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-4.2);
    glVertex2f(-10,-3.8);
    glVertex2f(-1,-3.8);
    glVertex2f(-1,-4.2);

    glEnd();

    //white5
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-10,-5);
    glVertex2f(-10,-4.6);
    glVertex2f(-1,-4.6);
    glVertex2f(-1,-5);

    glEnd();

    //white6
    glColor3ub(255,255,255 );
    glBegin(GL_POLYGON);

    glVertex2f(-10,-5.8);
    glVertex2f(-10,-5.4);
    glVertex2f(-1,-5.4);
    glVertex2f(-1,-5.8);

    glEnd();


    //4th

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(1,-1);
    glVertex2f(10,-1);
    glVertex2f(10,-6.18);
    glVertex2f(1,-6.18);

    glEnd();

    //blue
    glColor3ub(17,20,116);
    glBegin(GL_POLYGON);

    glVertex2f(1,-3.8);
    glVertex2f(1,-1);
    glVertex2f(4.2,-1);
    glVertex2f(4.2,-3.8);

    glEnd();

      //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.6,-1.1);
    glVertex2f(2.6,-1.2);
    glVertex2f(2.7,-1.2);
    glVertex2f(2.6,-1.3);
    glVertex2f(2.7,-1.4);
    glVertex2f(2.6,-1.3);
    glVertex2f(2.5,-1.4);
    glVertex2f(2.5,-1.3);
    glVertex2f(2.4,-1.2);
    glVertex2f(2.5,-1.2);

    glEnd();

     //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.1,-1.2);
    glVertex2f(3.1,-1.4);
    glVertex2f(3.2,-1.4);
    glVertex2f(3.1,-1.4);
    glVertex2f(3.2,-1.6);
    glVertex2f(3.1,-1.5);
    glVertex2f(3,-1.6);
    glVertex2f(3,-1.4);
    glVertex2f(2.9,-1.4);
    glVertex2f(3,-1.4);

    glEnd();

      //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.4,-1.6);
    glVertex2f(3.5,-1.8);
    glVertex2f(3.6,-1.8);
    glVertex2f(3.5,-1.8);
    glVertex2f(3.6,-2);
    glVertex2f(3.4,-1.9);
    glVertex2f(3.3,-2);
    glVertex2f(3.4,-1.8);
    glVertex2f(3.2,-1.8);
    glVertex2f(3.4,-1.8);
    glEnd();

     //white4
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.7,-2.2);
    glVertex2f(3.7,-2.3);
    glVertex2f(3.8,-2.3);
    glVertex2f(3.7,-2.3);
    glVertex2f(3.8,-2.5);
    glVertex2f(3.7,-2.4);
    glVertex2f(3.6,-2.5);
    glVertex2f(3.6,-2.3);
    glVertex2f(3.5,-2.3);
    glVertex2f(3.6,-2.3);

    glEnd();

    //white5
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.6,-2.6);
    glVertex2f(3.6,-2.8);
    glVertex2f(3.8,-2.8);
    glVertex2f(3.6,-2.8);
    glVertex2f(3.7,-3);
    glVertex2f(3.6,-2.9);
    glVertex2f(3.5,-3);
    glVertex2f(3.5,-2.8);
    glVertex2f(3.4,-2.8);
    glVertex2f(3.5,-2.8);

    glEnd();

    //white6
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(3.2,-3.1);
    glVertex2f(3.3,-3.2);
    glVertex2f(3.4,-3.2);
    glVertex2f(3.3,-3.3);
    glVertex2f(3.3,-3.4);
    glVertex2f(3.2,-3.3);
    glVertex2f(3.1,-3.4);
    glVertex2f(3.2,-3.3);
    glVertex2f(3.1,-3.2);
    glVertex2f(3.2,-3.2);

    glEnd();

     //white7
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.7,-3.3);
    glVertex2f(2.7,-3.4);
    glVertex2f(2.9,-3.4);
    glVertex2f(2.8,-3.5);
    glVertex2f(2.8,-3.6);
    glVertex2f(2.7,-3.5);
    glVertex2f(2.6,-3.6);
    glVertex2f(2.6,-3.5);
    glVertex2f(2.5,-3.5);
    glVertex2f(2.7,-3.4);

    glEnd();

     //white8
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2.1,-3.3);
    glVertex2f(2.2,-3.4);
    glVertex2f(2.3,-3.4);
    glVertex2f(2.2,-3.5);
    glVertex2f(2.2,-3.6);
    glVertex2f(2.1,-3.5);
    glVertex2f(2,-3.6);
    glVertex2f(2.1,-3.5);
    glVertex2f(2,-3.4);
    glVertex2f(2.1,-3.4);

    glEnd();

     //white9
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.7,-3.1);
    glVertex2f(1.7,-3.2);
    glVertex2f(1.8,-3.2);
    glVertex2f(1.7,-3.2);
    glVertex2f(1.8,-3.3);
    glVertex2f(1.7,-3.3);
    glVertex2f(1.6,-3.3);
    glVertex2f(1.6,-3.2);
    glVertex2f(1.5,-3.2);
    glVertex2f(1.7,-3.2);

    glEnd();

    //white10
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.5,-2.5);
    glVertex2f(1.5,-2.7);
    glVertex2f(1.6,-2.7);
    glVertex2f(1.5,-2.7);
    glVertex2f(1.6,-2.9);
    glVertex2f(1.5,-2.8);
    glVertex2f(1.4,-2.9);
    glVertex2f(1.4,-2.7);
    glVertex2f(1.3,-2.7);
    glVertex2f(1.4,-2.7);

    glEnd();

    //white11
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.4,-2);
    glVertex2f(1.5,-2.1);
    glVertex2f(1.6,-2.1);
    glVertex2f(1.5,-2.2);
    glVertex2f(1.5,-2.3);
    glVertex2f(1.4,-2.2);
    glVertex2f(1.3,-2.3);
    glVertex2f(1.4,-2.2);
    glVertex2f(1.3,-2.1);
    glVertex2f(1.4,-2.1);

    glEnd();

     //white12
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1.6,-1.6);
    glVertex2f(1.6,-1.7);
    glVertex2f(1.8,-1.7);
    glVertex2f(1.7,-1.8);
    glVertex2f(1.7,-1.9);
    glVertex2f(1.6,-1.8);
    glVertex2f(1.5,-1.9);
    glVertex2f(1.6,-1.8);
    glVertex2f(1.5,-1.7);
    glVertex2f(1.6,-1.7);

    glEnd();

    //white13
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(2,-1.2);
    glVertex2f(2.1,-1.3);
    glVertex2f(2.2,-1.3);
    glVertex2f(2.1,-1.4);
    glVertex2f(2.1,-1.5);
    glVertex2f(2,-1.4);
    glVertex2f(1.9,-1.5);
    glVertex2f(2,-1.3);
    glVertex2f(1.9,-1.3);
    glVertex2f(2,-1.3);

    glEnd();

    //all line
    //red1
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-1.4);
    glVertex2f(4.2,-1);
    glVertex2f(10,-1);
    glVertex2f(10,-1.4);

    glEnd();

    //red2
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-2.2);
    glVertex2f(4.2,-1.8);
    glVertex2f(10,-1.8);
    glVertex2f(10,-2.2);

    glEnd();

    //red3
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-3);
    glVertex2f(4.2,-2.6);
    glVertex2f(10,-2.6);
    glVertex2f(10,-3);

    glEnd();

    //red4
    glColor3ub(245,49,26);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-3.8);
    glVertex2f(4.2,-3.4);
    glVertex2f(10,-3.4);
    glVertex2f(10,-3.8);

    glEnd();

    //red5
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,-4.6);
    glVertex2f(1,-4.2);
    glVertex2f(10,-4.2);
    glVertex2f(10,-4.6);

    glEnd();

     //red6
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,-5.5);
    glVertex2f(1,-5);
    glVertex2f(10,-5);
    glVertex2f(10,-5.5);

    glEnd();

     //red7
    glColor3ub(245,49,26 );
    glBegin(GL_POLYGON);

    glVertex2f(1,-6.18);
    glVertex2f(1,-5.8);
    glVertex2f(10,-5.8);
    glVertex2f(10,-6.18);

    glEnd();


    //white1
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-1.8);
    glVertex2f(4.2,-1.4);
    glVertex2f(10,-1.4);
    glVertex2f(10,-1.8);

    glEnd();

    //white2
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-2.6);
    glVertex2f(4.2,-2.2);
    glVertex2f(10,-2.2);
    glVertex2f(10,-2.6);

    glEnd();

    //white3
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(4.2,-3.4);
    glVertex2f(4.2,-3);
    glVertex2f(10,-3);
    glVertex2f(10,-3.4);

    glEnd();

    //white4
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1,-4.2);
    glVertex2f(1,-3.8);
    glVertex2f(10,-3.8);
    glVertex2f(10,-4.2);

    glEnd();

    //white5
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(1,-5);
    glVertex2f(1,-4.6);
    glVertex2f(10,-4.6);
    glVertex2f(10,-5);

    glEnd();

    //white6
    glColor3ub(255,255,255 );
    glBegin(GL_POLYGON);

    glVertex2f(1,-5.8);
    glVertex2f(1,-5.5);
    glVertex2f(10,-5.5);
    glVertex2f(10,-5.8);

    glEnd();



}
void display()
{
    glClearColor(0,0,0,0);
    glClear(GL_COLOR_BUFFER_BIT);
    flag_4();
    glFlush();
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutCreateWindow("Flag_4");
    glutInitWindowSize(320,320);
    glutDisplayFunc(display);
    gluOrtho2D(-20,20,-10,10);
    glutMainLoop();

    return 0;
}*/

///////////////////


/*#include <windows.h>
#include <GL/glut.h>
#include <math.h>

void flag_1()
{
    //1st

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(2,5);
    glVertex2f(10,5);
    glVertex2f(10,1);
    glVertex2f(2,1);

    glEnd();

    //redfull
    glColor3ub(244,16,8);
    glBegin(GL_POLYGON);

    glVertex2f(2,3.5);
    glVertex2f(5.13,3.5);
    glVertex2f(5.13,5);
    glVertex2f(10,5);
    glVertex2f(10,1);
    glVertex2f(2,1);

    glEnd();

    //graymiddle
    glColor3ub(228,226,225);
    glBegin(GL_POLYGON);

    glVertex2f(2,3.5);
    glVertex2f(2,3.63);
    glVertex2f(3,3.63);
    glVertex2f(4,3.63);
    glVertex2f(5,3.63);
    glVertex2f(5,5);
    glVertex2f(5.13,5);
    glVertex2f(5.13,3.5);

    glEnd();

    //blue
    glColor3ub(29,59,141);
    glBegin(GL_POLYGON);

    glVertex2f(2,3.63);
    glVertex2f(2,5);
    glVertex2f(3,5);
    glVertex2f(3,3.63);

    glEnd();

    //grayup
    glColor3ub(228,226,225);
    glBegin(GL_POLYGON);

    glVertex2f(3,3.63);
    glVertex2f(3,5);
    glVertex2f(4,5);
    glVertex2f(4,3.63);

    glEnd();

    //red
    glColor3ub(244,16,8);
    glBegin(GL_POLYGON);

    glVertex2f(4,3.63);
    glVertex2f(4,5);
    glVertex2f(5,5);
    glVertex2f(5,3.63);

    glEnd();


    //gray1up
    glColor3ub(228,226,225);
    glBegin(GL_POLYGON);

    glVertex2f(7.5,3.5);
    glVertex2f(8.5,3.5);
    glVertex2f(8,2.95);

    glEnd();

    //gray2right
    glColor3ub(228,226,225);
    glBegin(GL_POLYGON);

    glVertex2f(8.5,3.3);
    glVertex2f(8.5,2.5);
    glVertex2f(8.13,2.86);

    glEnd();

    //gray3down
    glColor3ub(228,226,225);
    glBegin(GL_POLYGON);

    glVertex2f(8,2.75);
    glVertex2f(8.5,2.38);
    glVertex2f(7.5,2.38);

    glEnd();

    //gray4left
    glColor3ub(228,226,225);
    glBegin(GL_POLYGON);

    glVertex2f(7.5,3.3);
    glVertex2f(7.89,2.85);
    glVertex2f(7.5,2.5);

    glEnd();



    //2nd

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-9,5);
    glVertex2f(-1,5);
    glVertex2f(-1,1);
    glVertex2f(-9,1);

    glEnd();

    //black
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-9,2);
    glVertex2f(-9,4);
    glVertex2f(-7,3);

    glEnd();

    //yellow
    glColor3ub(255,195,0);
    glBegin(GL_POLYGON);

    glVertex2f(-7,3);
    glVertex2f(-9,4);
    glVertex2f(-9,4.5);
    glVertex2f(-6,3);
    glVertex2f(-9,1.5);
    glVertex2f(-9,2);

    glEnd();

    //green
    glColor3ub(56,119,34);
    glBegin(GL_POLYGON);

    glVertex2f(-6,3);
    glVertex2f(-9,4.5);
    glVertex2f(-9,5);
    glVertex2f(-8,5);
    glVertex2f(-5,3.56);
    glVertex2f(-1,3.56);
    glVertex2f(-1,2.56);
    glVertex2f(-5,2.56);
    glVertex2f(-8,1);
    glVertex2f(-9,1);
    glVertex2f(-9,1.5);

    glEnd();

    //whiteup
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-8,5);
    glVertex2f(-7.374,5);
    glVertex2f(-5,3.87);
    glVertex2f(-1,3.87);
    glVertex2f(-1,3.56);
    glVertex2f(-5,3.56);

    glEnd();

    //whitedown
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-8,1);
    glVertex2f(-5,2.56);
    glVertex2f(-1,2.56);
    glVertex2f(-1,2.22);
    glVertex2f(-5,2.22);
    glVertex2f(-7.44,1);

    glEnd();

    //red
    glColor3ub(244,16,8);
    glBegin(GL_POLYGON);

    glVertex2f(-7.374,5);
    glVertex2f(-1,5);
    glVertex2f(-1,3.87);
    glVertex2f(-5,3.87);

    glEnd();

    //blue
    glColor3ub(29,59,141);
    glBegin(GL_POLYGON);

    glVertex2f(-7.44,1);
    glVertex2f(-5,2.22);
    glVertex2f(-1,2.22);
    glVertex2f(-1,1);

    glEnd();


    //3rd

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(-9,-1);
    glVertex2f(-1,-1);
    glVertex2f(-1,-5);
    glVertex2f(-9,-5);

    glEnd();

    //whitemidddle
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-9,-2.3);
    glVertex2f(-9,-1.9);
    glVertex2f(-8,-1.9);
    glVertex2f(-8,-1);
    glVertex2f(-7.5,-1);
    glVertex2f(-7.5,-1.9);
    glVertex2f(-6.6,-1.9);
    glVertex2f(-6.6,-2.3);
    glVertex2f(-7.5,-2.3);
    glVertex2f(-7.5,-3.19);
    glVertex2f(-8,-3.19);
    glVertex2f(-8,-2.3);

    glEnd();


    //blue1
    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-9,-1.9);
    glVertex2f(-9,-1);
    glVertex2f(-8,-1);
    glVertex2f(-8,-1.9);

    glEnd();

    //blue2
    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-7.5,-1.9);
    glVertex2f(-7.5,-1);
    glVertex2f(-6.6,-1);
    glVertex2f(-6.6,-1.5);
    glVertex2f(-6.6,-1.9);

    glEnd();

    //blue3
    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-7.5,-3.19);
    glVertex2f(-7.5,-2.3);
    glVertex2f(-6.6,-2.3);
    glVertex2f(-6.6,-2.8);
    glVertex2f(-6.6,-3.2);

    glEnd();

    //blue4
    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-9,-3.19);
    glVertex2f(-9,-2.3);
    glVertex2f(-8,-2.3);
    glVertex2f(-8,-3.19);

    glEnd();


    //allLine
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-6.6,-1.5);
    glVertex2f(-1,-1.5);
    glVertex2f(-1,-1.9);
    glVertex2f(-6.6,-1.9);

    glEnd();

    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-6.6,-2.3);
    glVertex2f(-1,-2.3);
    glVertex2f(-1,-2.8);
    glVertex2f(-6.6,-2.8);

    glEnd();

    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-9,-3.2);
    glVertex2f(-1,-3.2);
    glVertex2f(-1,-3.65);
    glVertex2f(-9,-3.65);

    glEnd();

    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);

    glVertex2f(-9,-4.1);
    glVertex2f(-1,-1.5);
    glVertex2f(-1,-4.5);
    glVertex2f(-9,-4.5);

    glEnd();

    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-6.6,-1);
    glVertex2f(-1,-1);
    glVertex2f(-1,-1.5);
    glVertex2f(-6.6,-1.5);

    glEnd();

    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-6.6,-1.9);
    glVertex2f(-1,-1.9);
    glVertex2f(-1,-2.3);
    glVertex2f(-6.6,-2.3);

    glEnd();

    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-6.6,-2.8);
    glVertex2f(-1,-2.8);
    glVertex2f(-1,-3.2);
    glVertex2f(-6.6,-3.2);

    glEnd();

    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-9,-3.65);
    glVertex2f(-1,-3.65);
    glVertex2f(-1,-4.1);
    glVertex2f(-9,-4.1);

    glEnd();

    glColor3ub(88,114,184 );
    glBegin(GL_POLYGON);

    glVertex2f(-9,-4.5);
    glVertex2f(-1,-4.5);
    glVertex2f(-1,-5);
    glVertex2f(-9,-5);

    glEnd();


    //4th

    //border
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2f(2,-1);
    glVertex2f(10,-1);
    glVertex2f(10,-5);
    glVertex2f(2,-5);

    glEnd();

    //red
    glColor3ub(199,0,57);
    glBegin(GL_POLYGON);

    glVertex2f(4.6,-5);
    glVertex2f(4.8,-4.84);
    glVertex2f(4.6,-4.7);
    glVertex2f(4.8,-4.5);
    glVertex2f(4.6,-4.4);
    glVertex2f(4.8,-4.2);
    glVertex2f(4.6,-4);
    glVertex2f(4.8,-3.8);
    glVertex2f(4.6,-3.6);
    glVertex2f(4.8,-3.3);
    glVertex2f(4.6,-3.1);
    glVertex2f(4.8,-2.8);
    glVertex2f(4.6,-2.6);
    glVertex2f(4.8,-2.3);
    glVertex2f(4.6,-2.1);
    glVertex2f(4.8,-1.8);
    glVertex2f(4.6,-1.5);
    glVertex2f(4.8,-1.3);
    glVertex2f(4.6,-1);
    glVertex2f(10,-1);
    glVertex2f(10,-5);

    glEnd();

    //grey
    glColor3ub(251,240,250);
    glBegin(GL_POLYGON);

    glVertex2f(2,-1);
    glVertex2f(4.6,-1);
    glVertex2f(4.8,-1.3);
    glVertex2f(4.6,-1.5);
    glVertex2f(4.8,-1.8);
    glVertex2f(4.6,-2.1);
    glVertex2f(4.8,-2.3);
    glVertex2f(4.6,-2.6);
    glVertex2f(4.8,-2.8);
    glVertex2f(4.6,-3.1);
    glVertex2f(4.8,-3.3);
    glVertex2f(4.6,-3.6);
    glVertex2f(4.8,-3.8);
    glVertex2f(4.6,-4);
    glVertex2f(4.8,-4.2);
    glVertex2f(4.6,-4.4);
    glVertex2f(4.8,-4.5);
    glVertex2f(4.6,-4.7);
    glVertex2f(4.8,-4.84);
    glVertex2f(4.6,-5);
    glVertex2f(2,-5);

    glEnd();
}
void display()
{
    glClearColor(0,0,1,0);
    glClear(GL_COLOR_BUFFER_BIT);
    flag_1();
    glFlush();
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutCreateWindow("Flag_1");
    glutInitWindowSize(320,320);
    glutDisplayFunc(display);
    gluOrtho2D(-20,20,-10,10);
    glutMainLoop();

    return 0;
}*/


