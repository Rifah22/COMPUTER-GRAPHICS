#include <windows.h>
#include <GL/glut.h>
#include <math.h>

void farvillage()
{
    //sky
    glBegin(GL_POLYGON);
    glColor3ub(101, 110, 135);

	glVertex2f(-10,1);
	glVertex2f(-10,5);
	glVertex2f(10,5);
	glVertex2f(10,1);

	glEnd();

    //farvillage
	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-9,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2.4-1.4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-8.1,y+1.4);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-6.7,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2.7-1.7;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-5,y+1.7);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.8-2.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-3,y+2.2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.9-3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1,y+3);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1,y+2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.4-2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+2.6,y+2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(251, 248, 238);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.7-2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+6.5,y+2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+4.9,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.1-1.6;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+8.9,y+1.6);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2-1.1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+6.9,y+1.1);
    }
    glEnd();

     glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub( 19, 107, 13);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.1-1.7;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-0.5,y+2);
    }
    glEnd();

    //fronthome
	glBegin(GL_POLYGON);
    glColor3ub(173, 150, 6 );

	glVertex2f(-10,-3);
	glVertex2f(-10,1);
	glVertex2f(10,1);
	glVertex2f(10,-2);

	glEnd();

	//tree
	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.4,1);
	glVertex2f(-0.4,2);
	glVertex2f(0,2);
	glVertex2f(0,0.5);

	glEnd();

	//home2

    glBegin(GL_POLYGON);
    glColor3ub(191, 134, 67);

	glVertex2f(1.2,0);
	glVertex2f(1.2,1);
	glVertex2f(3.2,1);
	glVertex2f(3.2,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(151, 130, 57);

	glVertex2f(1,1);
	glVertex2f(1.4,2);
	glVertex2f(3,2);
	glVertex2f(3.4,1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(128, 79, 19);

	glVertex2f(1.8,0);
	glVertex2f(1.8,0.8);
	glVertex2f(2.6,0.8);
	glVertex2f(2.6,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(104, 59, 5);

	glVertex2f(1.3,-0.2);
	glVertex2f(1.3,0);
	glVertex2f(3.2,0);
	glVertex2f(3.2,-0.2);

	glEnd();

	//paddy
	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(212, 184, 9);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1-0;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0.4,y+0);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(212, 184, 9);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1-0.4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0.9,y-0.4);
    }
    glEnd();

     glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(34, 118, 12);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.2-3.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-0.3,y+3.3);
    }
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.2,-1);
	glVertex2f(-0.2,-0.8);
	glVertex2f(1.5,-0.8);
	glVertex2f(1.5,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(0.3,1);
	glVertex2f(0.4,1.4);
	glVertex2f(0.5,1);

	glEnd();

    //home1
    glBegin(GL_POLYGON);
    glColor3ub(148, 131, 101);

	glVertex2f(-5,0.9);
	glVertex2f(-4,2);
	glVertex2f(-3.7,1.7);
	glVertex2f(-4.5,0.9);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(218, 138, 15);

	glVertex2f(-4.5,-0.2);
	glVertex2f(-4.5,0.9);
	glVertex2f(-3.7,1.7);
	glVertex2f(-3,0.7);
	glVertex2f(-3,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(228, 150, 30);

	glVertex2f(-3,-1);
	glVertex2f(-3,0.7);
	glVertex2f(-0.2,0.7);
	glVertex2f(-0.2,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(145, 130, 104 );

	glVertex2f(-2.9,0.5);
	glVertex2f(-4,2);
	glVertex2f(-1,2);
	glVertex2f(0,0.5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(236, 200, 17);

	glVertex2f(-4,0.2);
	glVertex2f(-4,0.7);
	glVertex2f(-3.5,0.5);
	glVertex2f(-3.5,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(180, 130, 8);

	glVertex2f(-2,-1);
	glVertex2f(-2,0);
	glVertex2f(-1.2,0);
	glVertex2f(-1.2,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(188, 120, 16);

	glVertex2f(-4.7,-0.3);
	glVertex2f(-4.5,-0.2);
	glVertex2f(-3,-1);
	glVertex2f(-3,-1.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(188, 120, 16);

	glVertex2f(-3,-1.2);
	glVertex2f(-3,-1);
	glVertex2f(-0.2,-1);
	glVertex2f(-0,-1.2);

	glEnd();

	//tree

	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.4,2);
	glVertex2f(-0.7,2.5);
	glVertex2f(-0.5,2.5);
	glVertex2f(-0.2,2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.2,2);
	glVertex2f(0.2,2.9);
	glVertex2f(0.5,2.9);
	glVertex2f(0,2);

	glEnd();

	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(25, 146, 8);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.3-3.5;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-2.3,y+3.5);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(25, 146, 8);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5.3-4.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0,y+4.3);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(28, 156, 10);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5-4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1.4,y+4);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(28, 156, 10);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5-4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1.5,y+4);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 143, 14);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.5-3.5;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1,y+3.5);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 143, 14);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.8-3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1,y+3);
    }
    glEnd();

}
void river()
{
	//river
	glBegin(GL_POLYGON);
    glColor3ub(5, 42, 140);

	glVertex2f(-10,-5);
	glVertex2f(-10,-2.9);
	glVertex2f(10,-2.1);
	glVertex2f(10,-5);

	glEnd();

	//riverside1
	glBegin(GL_POLYGON);
    glColor3ub(120, 94, 5);

	glVertex2f(-10,-2.5);
	glVertex2f(-0.9,-2.5);
	glVertex2f(0,-2.9);
	glVertex2f(-10,-2.9);

	glEnd();

	//riverside2
	glBegin(GL_POLYGON);
    glColor3ub(120, 94, 5);

	glVertex2f(-0.9,-2.5);
	glVertex2f(-1.3,-2);
	glVertex2f(10,-2);
	glVertex2f(10,-2.5);

	glEnd();

	//riverside2
	glBegin(GL_POLYGON);
    glColor3ub(120, 94, 5);

	glVertex2f(-0.9,-2.5);
	glVertex2f(-1.3,-2);
	glVertex2f(-0.4,-2.5);
	glVertex2f(0,-2.9);

	glEnd();

	//boatout
	glBegin(GL_POLYGON);
    glColor3ub(79, 63, 9);

	glVertex2f(-8,-4.2);
	glVertex2f(-8.8,-3.2);
	glVertex2f(-7.5,-3.8);
	glVertex2f(-5.2,-3.8);
	glVertex2f(-4,-3.2);
	glVertex2f(-4.8,-4.2);

	glEnd();

	//boatin1
	glBegin(GL_POLYGON);
    glColor3ub(113, 94, 28 );

	glVertex2f(-7.5,-3.8);
	glVertex2f(-8.8,-3.2);
	glVertex2f(-7.5,-3.4);
	glVertex2f(-6.8,-3.8);

	glEnd();

	//boatin2
	glBegin(GL_POLYGON);
    glColor3ub(113, 94, 28 );

	glVertex2f(-6.8,-3.8);
	glVertex2f(-7.5,-3.4);
	glVertex2f(-6,-3.4);
	glVertex2f(-5.2,-3.8);

	glEnd();

	//boatin3
	glBegin(GL_POLYGON);
    glColor3ub(113, 94, 28 );

	glVertex2f(-5.2,-3.8);
	glVertex2f(-6,-3.4);
	glVertex2f(-5.3,-3.4);
	glVertex2f(-4,-3.2);

	glEnd();

	glLineWidth(10);
	glBegin(GL_LINES);
    glColor3ub(136, 114, 40 );

	glVertex2f(-5.2,-3.8);
	glVertex2f(-6,-3.4);

	glEnd();

	glLineWidth(10);
	glBegin(GL_LINES);
    glColor3ub(136, 114, 40 );

	glVertex2f(-6.8,-3.8);
	glVertex2f(-7.6,-3.4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub( 161, 127, 12 );

	glVertex2f(-8.3,-3.4);
	glVertex2f(-8.3,-2);
	glVertex2f(-8,-2);
	glVertex2f(-8,-3.6);

	glEnd();

}


void display()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	farvillage();
	river();
    glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Scenery");
	glutInitWindowSize(320,320);
	glutDisplayFunc(display);
	gluOrtho2D(-10,10,-5,5);
	glutMainLoop();
	return 0;
}












/*
void backcar()
{
    glBegin(GL_POLYGON);
    glColor3ub(67, 64, 61 );

	glVertex2f(-2,2);
	glVertex2f(-2,6);
	glVertex2f(2,6);
	glVertex2f(2,2);

	glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-0.2,2);
	glVertex2f(-0.2,3.2);
	glVertex2f(0.2,3.2);
	glVertex2f(0.2,2);

	glEnd();

	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(0,0,0);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1.1,y+3.2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(0,0,0);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1.1,y+3.2);
    }
    glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(144, 12, 63);

	glVertex2f(-1.4,3.4);
	glVertex2f(-1.4,4);
	glVertex2f(1.4,4);
	glVertex2f(1.4,3.4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(220, 207, 163);

	glVertex2f(-1.4,3.2);
	glVertex2f(-1.4,3.4);
	glVertex2f(1.4,3.4);
	glVertex2f(1.4,3.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(144, 12, 63);

	glVertex2f(-1,4);
	glVertex2f(-0.9,5);
	glVertex2f(0.9,5);
	glVertex2f(1,4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(238, 228, 197);

	glVertex2f(-0.8,4.2);
	glVertex2f(-0.7,4.8);
	glVertex2f(0.7,4.8);
	glVertex2f(0.8,4.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(232, 131, 17);

	glVertex2f(-1.4,3.8);
	glVertex2f(-1.4,4);
	glVertex2f(-1.2,4);
	glVertex2f(-1.2,3.8);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(232, 131, 17);

	glVertex2f(1.2,3.8);
	glVertex2f(1.2,4);
	glVertex2f(1.4,4);
	glVertex2f(1.4,3.8);

	glEnd();

}

void car()
{
    glBegin(GL_POLYGON);
    glColor3ub(67, 64, 61 );

	glVertex2f(2,2);
	glVertex2f(11,2);
	glVertex2f(11,-2);
	glVertex2f(2,-2);

	glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(2,-0.2);
	glVertex2f(2,0.2);
	glVertex2f(3.5,0.2);
	glVertex2f(3.5,-0.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(5.1,-0.2);
	glVertex2f(5.1,0.2);
	glVertex2f(6.8,0.2);
	glVertex2f(6.8,-0.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(8.5,-0.2);
	glVertex2f(8.5,0.2);
	glVertex2f(10,0.2);
	glVertex2f(10,-0.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(80, 124, 243);

	glVertex2f(3,-0.1);
	glVertex2f(3,1);
	glVertex2f(9,1);
	glVertex2f(9,-0.1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(80, 124, 243);

	glVertex2f(4,1);
	glVertex2f(4.96,1.8);
	glVertex2f(7.02,1.8);
	glVertex2f(8,1);

	glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(55,55,55);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.5;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5,y+0);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(55,55,55);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.5;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+7,y+0);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 194, 12);

	glVertex2f(3,0.7);
	glVertex2f(3,1);
	glVertex2f(3.3,1);
	glVertex2f(3.3,0.7);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(247, 194, 12);

	glVertex2f(9,0.7);
	glVertex2f(9,1);
	glVertex2f(8.7,1);
	glVertex2f(8.7,0.7);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(233, 228, 211);

	glVertex2f(4.8,1.1);
	glVertex2f(5.1,1.5);
	glVertex2f(5.8,1.5);
	glVertex2f(5.8,1.1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(233, 228, 211);

	glVertex2f(6.2,1.1);
	glVertex2f(6.2,1.5);
	glVertex2f(6.9,1.5);
	glVertex2f(7.2,1.1);

	glEnd();
}

void bench()
{
    glBegin(GL_POLYGON);
    glColor3ub(194, 184, 140);

	glVertex2f(2,-5);
	glVertex2f(2,-2);
	glVertex2f(11,-2);
	glVertex2f(11,-5);

	glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(177, 130, 61);

	glVertex2f(4.4,-4);
	glVertex2f(4.8,-2.4);
	glVertex2f(6.4,-2.4);
	glVertex2f(6,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(177, 130, 61);

    glVertex2f(4.4,-4.8);
	glVertex2f(4.4,-4);
	glVertex2f(4.8,-4);
	glVertex2f(4.8,-4.8);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(177, 130, 61);

    glVertex2f(5.6,-4.8);
	glVertex2f(5.6,-4);
	glVertex2f(6,-4);
	glVertex2f(6,-4.8);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(189, 140, 70);

    glVertex2f(6.1,-3.4);
	glVertex2f(6.4,-2.4);
	glVertex2f(6.4,-3.4);


	glEnd();

}

void cross()
{
    glBegin(GL_POLYGON);
    glColor3ub(67, 64, 61 );

	glVertex2f(-2,-5);
	glVertex2f(-2,-2);
	glVertex2f(2,-2);
	glVertex2f(2,-5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-1.5,-4);
	glVertex2f(-1.5,-2.5);
	glVertex2f(-1.1,-2.5);
	glVertex2f(-1.1,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-0.8,-4);
	glVertex2f(-0.8,-2.5);
	glVertex2f(-0.4,-2.5);
	glVertex2f(-0.4,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-0.1,-4);
	glVertex2f(-0.1,-2.5);
	glVertex2f(0.3,-2.5);
	glVertex2f(0.3,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(0.6,-4);
	glVertex2f(0.6,-2.5);
	glVertex2f(1,-2.5);
	glVertex2f(1,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(1.3,-4);
	glVertex2f(1.3,-2.5);
	glVertex2f(1.7,-2.5);
	glVertex2f(1.7,-4);

	glEnd();
}

void trafficlight()
{
    glBegin(GL_POLYGON);
    glColor3ub(67, 64, 61 );

	glVertex2f(-10,-2);
	glVertex2f(-10,2);
	glVertex2f(-2,2);
	glVertex2f(-2,-2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(194, 184, 140);

	glVertex2f(-10,-5);
	glVertex2f(-10,-2);
	glVertex2f(-2,-2);
	glVertex2f(-2,-5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(194, 184, 140);

	glVertex2f(-10,2);
	glVertex2f(-10,6);
	glVertex2f(-2,6);
	glVertex2f(-2,2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-3.5,-0.2);
	glVertex2f(-3.5,0.2);
	glVertex2f(-2,0.2);
	glVertex2f(-2,-0.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-6.5,-0.2);
	glVertex2f(-6.5,0.2);
	glVertex2f(-5,0.2);
	glVertex2f(-5,-0.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(250, 249, 245);

	glVertex2f(-9.5,-0.2);
	glVertex2f(-9.5,0.2);
	glVertex2f(-8,0.2);
	glVertex2f(-8,-0.2);

	glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-8,-4);
	glVertex2f(-8,-3);
	glVertex2f(-7,-3);
	glVertex2f(-7,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-8.42,-5);
	glVertex2f(-8.42,-4);
	glVertex2f(-6.57,-4);
	glVertex2f(-6.57,-5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-8,-3);
	glVertex2f(-8,3);
	glVertex2f(-7,3);
	glVertex2f(-7,-3);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-8,-4);
	glVertex2f(-8,-3);
	glVertex2f(-7,-3);
	glVertex2f(-7,-4);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-8.42,-5);
	glVertex2f(-8.42,-4);
	glVertex2f(-6.57,-4);
	glVertex2f(-6.57,-5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-8,2);
	glVertex2f(-8,3);
	glVertex2f(-6,3);
	glVertex2f(-6,2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(163, 156, 149);

	glVertex2f(-6,1.81);
	glVertex2f(-6,3.25);
	glVertex2f(-3.02,3.25);
	glVertex2f(-3.02,1.81);

	glEnd();

	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(207, 17, 11 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-2.57;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-5.47,y+2.57);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(207, 187, 11 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-2.57;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-4.5,y+2.57);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(32, 176, 23);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-2.57;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-3.5,y+2.57);
    }
    glEnd();
}

void road()
{
	glBegin(GL_POLYGON);
    glColor3ub(67, 64, 61 );

	glVertex2f(-2,-2);
	glVertex2f(-2,2);
	glVertex2f(2,2);
	glVertex2f(2,-2);

	glEnd();
}

void tree()
{
    glBegin(GL_POLYGON);
    glColor3ub(115, 59, 3  );

	glVertex2f(9.39,3.19);
	glVertex2f(9.39,5.01);
	glVertex2f(10.23,5.01);
	glVertex2f(10.23,3.19);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(99, 51, 3 );

    glVertex2f(9.08,2.64);
	glVertex2f(9.39,3.19);
	glVertex2f(10.23,3.19);
	glVertex2f(10.56,2.65);

	glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(40, 161, 32 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=6.89-5.96;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+9.73,y+5.96);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 146, 21 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5.91-5.01;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+10.23,y+5.01);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(32, 176, 23);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5.93-5.01;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+9.33,y+5.01);
    }
    glEnd();
}
void home()
{
    glBegin(GL_POLYGON);
    glColor3ub(113, 195, 245);

	glVertex2f(-10,6);
	glVertex2f(-10,8);
	glVertex2f(11,8);
	glVertex2f(11,6);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(194, 184, 140);

	glVertex2f(2,2);
	glVertex2f(2,6);
	glVertex2f(11,6);
	glVertex2f(11,2);

	glEnd();

    //border

    glBegin(GL_POLYGON);
    glColor3ub(154, 11, 24);

	glVertex2f(2.996,2.611);
	glVertex2f(3,8);
	glVertex2f(8,8);
	glVertex2f(8.023,2.595);

	glEnd();

	//2
	glBegin(GL_POLYGON);
    glColor3ub(11, 154, 154);

    glVertex2f(3.99,6.57);
	glVertex2f(4.01,7.37);
	glVertex2f(4.99,7.37);
	glVertex2f(5.01,6.57);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(11, 154, 154);

    glVertex2f(5.99,6.57);
	glVertex2f(6.01,7.37);
	glVertex2f(6.99,7.37);
	glVertex2f(7.01,6.57);


	glEnd();

	//1
	glBegin(GL_POLYGON);
    glColor3ub(11, 154, 154);

    glVertex2f(4,5);
	glVertex2f(4.01,5.8);
	glVertex2f(4.99,5.8);
	glVertex2f(5,5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(11, 154, 154);

    glVertex2f(6,5);
	glVertex2f(6.01,5.8);
	glVertex2f(6.99,5.8);
	glVertex2f(7,5);

	glEnd();

	//door
	glBegin(GL_POLYGON);
    glColor3ub(92, 62, 5);

    glVertex2f(4.78,2.65);
	glVertex2f(4.79,4.4);
	glVertex2f(6.18,4.4);
	glVertex2f(6.18,2.58);

	glEnd();

}
void display()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	home();
	tree();
	cross();
	car();
	trafficlight();
	backcar();
	road();
	bench();
    glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Scenery");
	glutInitWindowSize(320,320);
	glutDisplayFunc(display);
	gluOrtho2D(-10,11,-5,8);
	glutMainLoop();
	return 0;
}*/

