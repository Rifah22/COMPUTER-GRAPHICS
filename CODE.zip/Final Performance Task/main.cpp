
//3
#include <iostream>
#include<GL/gl.h>
#include <GL/glut.h>
#include <math.h>

using namespace std;

float _move = 0.0f;
float _move1 = 0.0f;

void sky()
{
    glColor3ub(67, 223, 241);
    glBegin(GL_POLYGON);

    glVertex2f(-4,0.38);
    glVertex2f(-4,2);
    glVertex2f(4,2);
    glVertex2f(4,0.38);

    glEnd();

    glColor3ub(59, 216, 234);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-1.2);
    glVertex2f(-4,0.38);
    glVertex2f(4,0.38);
    glVertex2f(4,-1.42);

    glEnd();
}

void river()
{
    glColor3ub(37, 180, 197);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-3);
    glVertex2f(-4,-1.2);
    glVertex2f(4,-1.42);
    glVertex2f(4,-3);

    glEnd();
}

void grass()
{
    glColor3ub(35, 168, 64);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-3);
    glVertex2f(-3.6,-2.5);
    glVertex2f(-2.8,-2.6);
    glVertex2f(-2,-3);

    glEnd();

    glColor3ub(28, 178, 60);
    glBegin(GL_POLYGON);

    glVertex2f(-2,-3);
    glVertex2f(-1,-2.6);
    glVertex2f(-0.3,-2.5);
    glVertex2f(-0.1,-2.8);
    glVertex2f(0.4,-2.6);
    glVertex2f(1.3,-2.6);
    glVertex2f(1.5,-3);

    glEnd();

    glColor3ub(53, 175, 78);
    glBegin(GL_POLYGON);

    glVertex2f(2,-3);
    glVertex2f(2.6,-2.7);
    glVertex2f(3.4,-2.6);
    glVertex2f(4,-3);

    glEnd();
}

void hill()
{
    //left
    glColor3ub(65, 182, 125);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-1.2);
    glVertex2f(-4,0.38);
    glVertex2f(-3.4,0);
    glVertex2f(-2.7,-0.3);
    glVertex2f(-2.1,-0.7);
    glVertex2f(-2.7,-1.3);

    glEnd();

    //right
    glColor3ub(57, 183, 122);
    glBegin(GL_POLYGON);

    glVertex2f(4,-1.42);
    glVertex2f(2.7,-1.24);
    glVertex2f(1.8,-1.1);
    glVertex2f(1,-0.4);
    glVertex2f(1.9,-0.2);
    glVertex2f(2.5,-0.6);
    glVertex2f(3,-1);

    glEnd();

    //middle end
    glColor3ub(227, 181, 67);
    glBegin(GL_POLYGON);

    glVertex2f(-3.02,-1.4);
    glVertex2f(-2.7,-1.2);
    glVertex2f(2.8,-1.2);
    glVertex2f(4,-1.42);
    glVertex2f(2.02,-1.4);
    glVertex2f(0.98,-1.34);
    glVertex2f(-0.1,-1.4);
    glVertex2f(-0.69,-1.35);
    glVertex2f(-1.33,-1.4);
    glVertex2f(-1.99,-1.36);

    glEnd();

    //middle first
    glColor3ub(227, 181, 67);
    glBegin(GL_POLYGON);

    glVertex2f(-1.2,0);
    glVertex2f(-0.6,0.5);
    glVertex2f(0.4,0.15);
    glVertex2f(0.568,0);

    glEnd();

    //middle
    glColor3ub(39, 197, 113);
    glBegin(GL_POLYGON);

    glVertex2f(-2.7,-1.2);
    glVertex2f(-1.2,0);
    glVertex2f(0.568,0);
    glVertex2f(1,-0.4);
    glVertex2f(1.8,-1.1);
    glVertex2f(2.8,-1.2);

    glEnd();
}

void volcano()
{
    //middle
    glColor3ub(222, 69, 16);
    glBegin(GL_POLYGON);

    glVertex2f(-0.9,-0.1);
    glVertex2f(-0.6,0.5);
    glVertex2f(0.32,0.2);
    glVertex2f(0.4,-0.3);

    glEnd();

    //l
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0.0f, _move1, 0.0f);
    glColor3ub(222, 69, 16);
    glBegin(GL_POLYGON);

    glVertex2f(-1.2,0.2);
    glVertex2f(-1.3,0.3);
    glVertex2f(-0.6,0.5);
    glVertex2f(-0.8,0.4);

    glEnd();

    //r
    glColor3ub(222, 69, 16);
    glBegin(GL_POLYGON);

    glVertex2f(0.5,0.06);
    glVertex2f(0.4,0.15);
    glVertex2f(0.97,0.01);
    glVertex2f(0.89,-0.1);

    glEnd();
    glPopMatrix();

}

void gas()
{
    //1
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
      glColor3ub(136, 126, 123);
      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.4;
      float x = r * cos(A);
      float y = r * sin(A);
      glVertex2f(x-0.3,y+0.6 );
    }
    glEnd();

    //2
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
      glColor3ub(132, 127, 125);
      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.4;
      float x = r * cos(A);
      float y = r * sin(A);
      glVertex2f(x+0.3,y+0.5 );
    }
    glEnd();

    //3
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
      glColor3ub(136, 126, 123);
      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.4;
      float x = r * cos(A);
      float y = r * sin(A);
      glVertex2f(x,y+1.2 );
    }
    glEnd();

    //4
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0,-_move1,0);
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
      glColor3ub(153, 150, 150);
      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.3;
      float x = r * cos(A);
      float y = r * sin(A);
      glVertex2f(x,y+1.8 );
    }
    glEnd();
    glPopMatrix();
}

void update(int value)
{
    _move +=0.2;
    if(_move > 2)
    {
        _move1 -= 0.02;
    }
    glutPostRedisplay();
   glutTimerFunc(100, update, 0);
}

void display()
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);
	sky();
	river();
	grass();
	hill();
	gas();
    volcano();
    glFlush();

}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Setup Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	gluOrtho2D(-4,4,-3,2);
    glutTimerFunc(20, update, 0);
	glutMainLoop();
	return 0;
}



/*
//4
#include <windows.h>
#include <GL/glut.h>
#include <math.h>

float _move=1;
int zoom=2;
void StreetLamp()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(_move,_move,0);
    //3
    glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(164,45.9);
	glVertex2f(164,43.9);
    glVertex2f(177.8,43.9);
	glVertex2f(177.8,45.9);

	glEnd();

    glBegin(GL_POLYGON);
	glColor3f(1,1,0);

	glVertex2f(166,32);
	glVertex2f(164,43.9);
    glVertex2f(177.8,43.9);
	glVertex2f(176,32);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(166,30);
	glVertex2f(166,32);
	glVertex2f(176,32);
	glVertex2f(176,30);

	glEnd();


	//1
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(121.9,45.9);
	glVertex2f(121.9,43.9);
    glVertex2f(136.4,43.9);
	glVertex2f(136.4,45.9);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1,1,0);

	glVertex2f(124,32);
	glVertex2f(121.9,43.9);
    glVertex2f(136.4,43.9);
	glVertex2f(134,32);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(124,30);
	glVertex2f(124,32);
	glVertex2f(134,32);
	glVertex2f(134,30);

	glEnd();


	//2
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(142.2,54.2);
	glVertex2f(142.2,56.2);
    glVertex2f(157.8,56.2);
	glVertex2f(157.8,54.2);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1,1,0);

	glVertex2f(144.3,42.3);
	glVertex2f(142.2,54.2);
    glVertex2f(157.8,54.4);
	glVertex2f(155.9,42.2);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(144.3,40.2);
	glVertex2f(144.3,42.3);
    glVertex2f(155.9,42.3);
	glVertex2f(155.9,40.2);

	glEnd();

	//m
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(148.4,-11.8);
	glVertex2f(148.5,40.2);
	glVertex2f(151.4,40.2);
	glVertex2f(151.3,-11.8);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(145,-15);
	glVertex2f(144.9,-11.9);
	glVertex2f(154.9,-11.9);
	glVertex2f(155,-15);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(142.8,-18.8);
	glVertex2f(142.8,-15);
	glVertex2f(157.1,-15);
	glVertex2f(157.1,-18.8);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(170,26);
	glVertex2f(170,30);
	glVertex2f(172,30);
	glVertex2f(172,23.01);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,23.01);
	glVertex2f(130,26);
	glVertex2f(170,26);
	glVertex2f(172,23.01);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(124,30);
	glVertex2f(134,32);
	glVertex2f(134,32);
	glVertex2f(124,30);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,23.01);
	glVertex2f(128,30);
	glVertex2f(130,30);
	glVertex2f(130,26);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(170,45);
	glVertex2f(170,48);
	glVertex2f(172,48);
	glVertex2f(172,45);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,45);
	glVertex2f(128,48);
	glVertex2f(130,48);
	glVertex2f(130,45);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(149,56);
	glVertex2f(149,59);
	glVertex2f(151,59);
	glVertex2f(151,56);

	glEnd();
    glPopMatrix();
}

void update(int value)
{
    if(zoom==1)
    {
        _move += .002;
        if(_move > 2)
        {
            _move=1.5;
        }
    }
    if(zoom==0)
    {
        _move -= .002;
        if(_move < 1)
        {
            _move=0.5;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(20, update, 0);
}

void keyboard(unsigned char key, int x, int y)
{
	 if (key == 'Z' || key == 'z'){		//zoom in
		zoom = 1;
	}
	if (key == 'O' || key == 'o'){		//zoom out
		zoom = 0;
	}

}

void display()
{
	glClearColor(0,0,0,0);
	glClear(GL_COLOR_BUFFER_BIT);
	StreetLamp();
    glFlush();
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Scenery");
	glutInitWindowSize(320,320);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	gluOrtho2D(10,400,-100,200);
	glutTimerFunc(20, update, 0);
	glutMainLoop();
	return 0;
}
*/





/*
//2
#include<iostream>
#include<windows.h>
#include<GL/glut.h>
#include<math.h>

//water
void rainy_river();
int water = 0;
float waterX = 0;
float waterY = 0;
float boatx=0;
float boaty=0;

float _move=0;
//rain
int rains=0;
int x=0;
int y=0;
float wx=0;
float wy=0;

void draw_line(float cx, float cy, float r, int num)
{

	glBegin(GL_TRIANGLE_FAN);
	for (int i = 0; i < num; i++)
	{
		float angle = 2.0f * 3.1416f * float(i) / float(num);

		float x = r * cosf(angle);
		float y = r * sinf(angle);

		glVertex2f(x + cx, y + cy);

	}
	glEnd();
	glFlush();
}

void river()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glBegin(GL_POLYGON);
    glColor3ub (33, 232, 229);

    glVertex2f(-6, 0);
    glVertex2f(-6, 3);
    glVertex2f(6, 3);
    glVertex2f(6, 0);

    glEnd();

    if(rains==1)
    {
        glTranslatef(0,_move,0);
        glBegin(GL_POLYGON);
        glColor3ub (33, 232, 229);

        glVertex2f(-6, 0);
        glVertex2f(-6, 3);
        glVertex2f(6, 3);
        glVertex2f(6, 0);

        glEnd();
    }
        glPopMatrix();
}


void land()
{
    glColor3ub (194, 148, 23);
    glBegin(GL_POLYGON);

    glVertex2f(-6, -3);
    glVertex2f(-6, 0);
    glVertex2f(6, 0);
    glVertex2f(6, -3);


    glEnd();
}

void water1()
{
    if(rains==0)
    {
    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    glBegin(GL_LINES);

    glVertex2f(-5,2);
    glVertex2f(-4,2);

    glVertex2f(-4,1);
    glVertex2f(-3,1);

    glVertex2f(-3,2);
    glVertex2f(-2,2);

    glVertex2f(-2,1);
    glVertex2f(-1,1);

    glVertex2f(-1,2);
    glVertex2f(0,2);

    glVertex2f(0,1);
    glVertex2f(1,1);

    glVertex2f(1,2);
    glVertex2f(2,2);

    glVertex2f(2,1);
    glVertex2f(3,1);

    glVertex2f(3,2);
    glVertex2f(4,2);

    glVertex2f(4,1);
    glVertex2f(5,1);

    glEnd();

    }
}

void move_water(int x)
{
    if (water ==1)
    {
        waterX += 0.01;
    }
    if (waterX>2)
    {
        waterX = -5;
    }

    glPushMatrix();
    glTranslatef(waterX, waterY, 0);
    if(x==1)
    {
        rainy_river();
        water1();
    }
    else
    {
        rainy_river();
    }
    glPopMatrix();

    glFlush();
}

void rain()
{
    glColor3d(0,1,0);
    glBegin(GL_POINTS);

    for(int i=1;i<=50000;i++)
    {
        x=rand(),y=rand();
        x%=5000; y%=50;

        glBegin(GL_LINES);
        glColor3b(1,1,1);
        glVertex2d(x,y);
        glVertex2d(x+0.3,y+0.3);
        glEnd();
    }

    for(int i=1;i<=50000;i+=1)
    {
        x=rand(),y=rand();
        x%=5000; y%=20;

        glBegin(GL_LINES);
        glColor3b(1,1,1);
        glVertex2d(x,y);
        glVertex2d(x+0.3,y+0.3);
        glEnd();

    }
}
void move_rain(int x)
{
     if(rains ==1)
     {
        wx -= 0.02;
        wy -= 0.02;
        glPushMatrix();
        glTranslatef(wx, wy, 0);
        if (x==1)
        {
            rain();
        }
        glPopMatrix();
        glFlush();
     }
}
void rainy_river()
{
    if(rains==1)
    {
        int xaxis=20;
        int yaxis=10;
        glColor3ub (160, 220, 220);
        glBegin(GL_LINES);

        for(int i=0; i<6; i++)
        {
            for(int j=0; j<15; j++)
            {
            glVertex2f( xaxis-0.5,  yaxis-0.1);
            glVertex2f( xaxis-1.5,  yaxis);
            glVertex2f( xaxis,  yaxis);
            glVertex2f(  xaxis-0.5,  yaxis-0.1);
            xaxis-=1.5;
            }
        yaxis-=0.5;
        xaxis=20;
        }
       glEnd();
    }
}

void update(int value)
{
    _move += .02;
    if(_move > 6)
    {
        _move = -5;
    }
    glutPostRedisplay();
    glutTimerFunc(20, update, 0);
}

void display(void)
{
    land();
    river();
    move_water(1);
    move_rain(1);
    glFlush();
    glutPostRedisplay();
    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
	 if (key == 'R' || key == 'r')
    {
		water = 1;//water start
	}
	if (key == 'S' || key == 's')
    {
		water = 0;//water flow
	}
	else if (key == '5' )
	{
		rains = 1;//rain start
	}
	else if (key == '3' )
	{
		rains = 0;//rain stop
	}
}

void drawscene(void)
{
    glClearColor(1.0f,1.0f,1.0f,1.0f);
    glColor3f(.0f,.0f,.0f);
    glLoadIdentity();
    gluOrtho2D(-6,6,-3,3);
}
int main(int argc, char** argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(320,320);
    glutCreateWindow("Flood Scenery");
    glutPostRedisplay();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    drawscene();
    glutTimerFunc(20, update, 0);
    glutMainLoop();

    return 0;
}
*/

