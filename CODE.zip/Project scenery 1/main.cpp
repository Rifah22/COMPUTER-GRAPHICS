#include <iostream>
#include <windows.h>
#include<GL/gl.h>
#include <GL/glut.h>
#include<math.h>
using namespace std;

float train1=0.0f;
float train2=0.1f;
float _move1=0.1f;
float misael=0.02f;
float _move2=0.1f;
float rocket=0.02f;
int misaelstatus=0;
bool day = true;
float _move=0.0f;
bool rainy = false;
float _rain = 0.0f;

void rain_s(int value)
{
    if (rainy)
    {
        _rain += 0.05f;

        float x = (rand() % 1500 + 100) / 60.0f;
        float y = (rand() % 1900 - 1000) /100.0f;

        glColor3f(1,1,1);
        glBegin(GL_LINES);
        glVertex2f(x,y);
        glVertex2f(x-0.5,y-1);
        glEnd();

        glutPostRedisplay();
        glutTimerFunc(5, rain_s, 0);
        glFlush();
    }
}

void broader_s()
{
    if (day)
         glColor3ub(239, 209, 114);
    else
        glColor3ub(175, 133, 50);
    glBegin(GL_POLYGON);
    //glColor3ub(239, 209, 114);

	glVertex2f(1,-10);
	glVertex2f(1,-1);
	glVertex2f(20,-1);
	glVertex2f(20,-10);

	glEnd();
}

void train_platform1_s()
{
    //outwhite
    if (day)
         glColor3ub( 255,255,255 );
    else
        glColor3ub(32, 30, 25 );
    glBegin(GL_POLYGON);
    //glColor3ub(255,255,255);

	glVertex2f(1.2,-8.5);
	glVertex2f(1.2,-2.5);
	glVertex2f(3.8,-2.5);
	glVertex2f(3.8,-8.5);

	glEnd();

	//inbrown
	if (day)
         glColor3ub(184, 154, 53 );
    else
        glColor3ub(74, 60, 14  );
	glBegin(GL_POLYGON);
    //glColor3ub(184, 154, 53);

	glVertex2f(1.5,-8);
	glVertex2f(1.5,-3);
	glVertex2f(3.5,-3);
	glVertex2f(3.5,-8);

	glEnd();

	//in1
	glBegin(GL_POLYGON);
    glColor3ub(150, 124, 37);

	glVertex2f(1.7,-3.7);
	glVertex2f(1.7,-3.2);
	glVertex2f(2,-3.2);
	glVertex2f(2,-3.7);

	glEnd();

	//in2
	glBegin(GL_POLYGON);
    glColor3ub(150, 124, 37);

	glVertex2f(2.2,-3.7);
	glVertex2f(2.2,-3.2);
	glVertex2f(2.5,-3.2);
	glVertex2f(2.5,-3.7);

	glEnd();

	//in3
	glBegin(GL_POLYGON);
    glColor3ub(150, 124, 37);

	glVertex2f(2.7,-7.7);
	glVertex2f(2.7,-7.2);
	glVertex2f(3,-7.2);
	glVertex2f(3,-7.7);

	glEnd();

	//in4
	glBegin(GL_POLYGON);
    glColor3ub(150, 124, 37);

	glVertex2f(2.2,-7.7);
	glVertex2f(2.2,-7.2);
	glVertex2f(2.5,-7.2);
	glVertex2f(2.5,-7.7);

	glEnd();

	//broken_up
	if (day)
         glColor3ub(239, 209, 114);
    else
        glColor3ub(175, 133, 50);
    glBegin(GL_POLYGON);
    //glColor3ub(239, 209, 114);

	glVertex2f(3.8,-4.28);
	glVertex2f(2.25,-4.14);
	glVertex2f(3.27,-3.83);
	glVertex2f(2.85,-3.83);
	glVertex2f(3.17,-3.48);
	glVertex2f(2.69,-3.35);
	glVertex2f(3,-3.14);
	glVertex2f(2.63,-2.99);
	glVertex2f(3.03,-2.78);
	glVertex2f(3,-2.4);
	glVertex2f(3.8,-2.4);

	glEnd();

	//broken_down
	if (day)
         glColor3ub(239, 209, 114);
    else
        glColor3ub(175, 133, 50);
    glBegin(GL_POLYGON);
    //glColor3ub(239, 209, 114);

    glVertex2f(1,-6.3);
	glVertex2f(1.41,-6.48);
	glVertex2f(1.5,-6);
	glVertex2f(1.62,-6.48);
	glVertex2f(1.7,-6.1);
	glVertex2f(1.81,-6.58);
	glVertex2f(1.92,-6.21);
	glVertex2f(1.99,-6.69);
	glVertex2f(2.12,-6.31);
	glVertex2f(2.2,-6.78);
	glVertex2f(2.32,-6.5);
	glVertex2f(1,-7.14);

	glEnd();

	//broken_part_down_2
	glBegin(GL_POLYGON);
    glColor3ub(179, 127, 47);

	glVertex2f(1.1,-6.5);
	glVertex2f(1.2,-6.6);
	glVertex2f(1.3,-6.5);
	glVertex2f(1.6,-6.6);
	glVertex2f(1.4,-6.7);
	glVertex2f(1.5,-6.8);
	glVertex2f(1.3,-6.9);
	glVertex2f(1.2,-6.7);
	glVertex2f(1,-6.8);
	glVertex2f(1.1,-6.7);

	glEnd();

	//broken_part_down_1
	glBegin(GL_POLYGON);
    glColor3ub(179, 127, 47);

	glVertex2f(1.03,-6.97);
	glVertex2f(1.1,-6.9);
	glVertex2f(1.1,-6.8);
	glVertex2f(1.2,-6.7);
	glVertex2f(1.26,-6.8);
	glVertex2f(1.2,-6.9);

	glEnd();

	//broken_part_down_3
	glBegin(GL_POLYGON);
    glColor3ub(179, 127, 47);

	glVertex2f(1.7,-6.8);
	glVertex2f(1.6,-6.7);
	glVertex2f(1.6,-6.6);
	glVertex2f(1.7,-6.7);
	glVertex2f(1.8,-6.66);

	glEnd();


	//broken_part_up3
	glBegin(GL_POLYGON);
    glColor3ub(179, 127, 47);

	glVertex2f(3.4,-3.2);
	glVertex2f(3.6,-3.3);
	glVertex2f(3.5,-3.5);
	glVertex2f(3.7,-3.7);
	glVertex2f(3.4,-3.6);
	glVertex2f(3.4,-3.7);
	glVertex2f(3.2,-3.6);
	glVertex2f(3.3,-3.5);

	glEnd();

		//broken_part_up1
    glBegin(GL_POLYGON);
    glColor3ub(179, 127, 47);

	glVertex2f(3.4,-2.8);
	glVertex2f(3.2,-2.6);
	glVertex2f(2.99,-2.6);
	glVertex2f(3.3,-2.4);
	glVertex2f(3.4,-2.6);

	glEnd();

	//broken_part_up2

    glBegin(GL_POLYGON);
    glColor3ub(179, 127, 47);

	glVertex2f(3.8,-2.99);
	glVertex2f(3.7,-2.8);
	glVertex2f(3.9,-2.6);
	glVertex2f(4.1,-2.8);
	glVertex2f(4,-3);

	glEnd();

}

void rail_line1_s()
{
    //broader1
    if (day)
         glColor3ub(247, 231, 141);
    else
        glColor3ub(188, 151, 75);
    glBegin(GL_POLYGON);
    //glColor3ub(247, 231, 141);

	glVertex2f(2,-2.5);
	glVertex2f(2,-1);
	glVertex2f(3,-1);
	glVertex2f(3,-2.5);

	glEnd();

	//width line1
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(2.1,-1.3);
	glVertex2f(2.1,-1.1);
	glVertex2f(2.9,-1.1);
	glVertex2f(2.9,-1.3);

	glEnd();

	//width line2
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(2.1,-1.6);
	glVertex2f(2.1,-1.4);
	glVertex2f(2.9,-1.4);
	glVertex2f(2.9,-1.6);

	glEnd();

	//width line3
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(2.1,-1.9);
	glVertex2f(2.1,-1.7);
	glVertex2f(2.9,-1.7);
	glVertex2f(2.9,-1.9);

	glEnd();

	//width line4
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(2.1,-2.2);
	glVertex2f(2.1,-2);
	glVertex2f(2.9,-2);
	glVertex2f(2.9,-2.2);

	glEnd();

	//long line1
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(2.2,-2.5);
	glVertex2f(2.2,-1);
	glVertex2f(2.3,-1);
	glVertex2f(2.3,-2.5);

	glEnd();

	//long line2
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(2.7,-2.5);
	glVertex2f(2.7,-1);
	glVertex2f(2.8,-1);
	glVertex2f(2.8,-2.5);

	glEnd();
}

void rail_line2_s()
{
    //broader1
    if (day)
         glColor3ub(247, 231, 141);
    else
        glColor3ub(188, 151, 75);
    glBegin(GL_POLYGON);
    //glColor3ub(247, 231, 141);

	glVertex2f(4.5,-10);
	glVertex2f(4.5,-1);
	glVertex2f(5.6,-1);
	glVertex2f(5.6,-10);

	glEnd();

	//width line1
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-1.3);
	glVertex2f(4.6,-1.1);
	glVertex2f(5.5,-1.1);
	glVertex2f(5.5,-1.3);

	glEnd();

	//width line2
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-1.6);
	glVertex2f(4.6,-1.4);
	glVertex2f(5.5,-1.4);
	glVertex2f(5.5,-1.6);

	glEnd();

	//width line3
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-1.9);
	glVertex2f(4.6,-1.7);
	glVertex2f(5.5,-1.7);
	glVertex2f(5.5,-1.9);

	glEnd();

	//width line4
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-2.2);
	glVertex2f(4.6,-2);
	glVertex2f(5.5,-2);
	glVertex2f(5.5,-2.2);

	glEnd();

	//width line5
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-2.5);
	glVertex2f(4.6,-2.3);
	glVertex2f(5.5,-2.3);
	glVertex2f(5.5,-2.5);

	glEnd();

	//width line6
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-2.8);
	glVertex2f(4.6,-2.6);
	glVertex2f(5.5,-2.6);
	glVertex2f(5.5,-2.8);

	glEnd();

	//width line7
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-3.1);
	glVertex2f(4.6,-2.9);
	glVertex2f(5.5,-2.9);
	glVertex2f(5.5,-3.1);

	glEnd();

	//width line8
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-3.4);
	glVertex2f(4.6,-3.2);
	glVertex2f(5.5,-3.2);
	glVertex2f(5.5,-3.4);

	glEnd();

	//width line9
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-3.7);
	glVertex2f(4.6,-3.5);
	glVertex2f(5.5,-3.5);
	glVertex2f(5.5,-3.7);

	glEnd();

	//width line10
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-4);
	glVertex2f(4.6,-3.8);
	glVertex2f(5.5,-3.8);
	glVertex2f(5.5,-4);

	glEnd();

	//width line11
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-4.3);
	glVertex2f(4.6,-4.1);
	glVertex2f(5.5,-4.1);
	glVertex2f(5.5,-4.3);

	glEnd();

	//width line12
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-4.6);
	glVertex2f(4.6,-4.4);
	glVertex2f(5.5,-4.4);
	glVertex2f(5.5,-4.6);

	glEnd();

	//width line13
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-4.9);
	glVertex2f(4.6,-4.7);
	glVertex2f(5.5,-4.7);
	glVertex2f(5.5,-4.9);

	glEnd();

	//width line14
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-5.2);
	glVertex2f(4.6,-5);
	glVertex2f(5.5,-5);
	glVertex2f(5.5,-5.2);

	glEnd();

	//width line15
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-5.5);
	glVertex2f(4.6,-5.3);
	glVertex2f(5.5,-5.3);
	glVertex2f(5.5,-5.5);

	glEnd();

	//width line16
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-5.8);
	glVertex2f(4.6,-5.6);
	glVertex2f(5.5,-5.6);
	glVertex2f(5.5,-5.8);

	glEnd();

	//width line17
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-6.1);
	glVertex2f(4.6,-5.9);
	glVertex2f(5.5,-5.9);
	glVertex2f(5.5,-6.1);

	glEnd();

	//width line18
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-6.4);
	glVertex2f(4.6,-6.2);
	glVertex2f(5.5,-6.2);
	glVertex2f(5.5,-6.4);

	glEnd();

	//width line19
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-6.7);
	glVertex2f(4.6,-6.5);
	glVertex2f(5.5,-6.5);
	glVertex2f(5.5,-6.7);

	glEnd();

	//width line20
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-7);
	glVertex2f(4.6,-6.8);
	glVertex2f(5.5,-6.8);
	glVertex2f(5.5,-7);

	glEnd();

	//width line21
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-7.3);
	glVertex2f(4.6,-7.1);
	glVertex2f(5.5,-7.1);
	glVertex2f(5.5,-7.3);

	glEnd();
	//width line22
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-7.6);
	glVertex2f(4.6,-7.4);
	glVertex2f(5.5,-7.4);
	glVertex2f(5.5,-7.6);

	glEnd();

	//width line23
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-7.9);
	glVertex2f(4.6,-7.7);
	glVertex2f(5.5,-7.7);
	glVertex2f(5.5,-7.9);

	glEnd();
	//width line24
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-8.2);
	glVertex2f(4.6,-8);
	glVertex2f(5.5,-8);
	glVertex2f(5.5,-8.2);

	glEnd();
	//width line25
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-8.5);
	glVertex2f(4.6,-8.3);
	glVertex2f(5.5,-8.3);
	glVertex2f(5.5,-8.5);

	glEnd();
	//width line26
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-8.8);
	glVertex2f(4.6,-8.6);
	glVertex2f(5.5,-8.6);
	glVertex2f(5.5,-8.8);

	glEnd();

	//width line27
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-9.1);
	glVertex2f(4.6,-8.9);
	glVertex2f(5.5,-8.9);
	glVertex2f(5.5,-9.1);

	glEnd();

	//width line28
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-9.4);
	glVertex2f(4.6,-9.2);
	glVertex2f(5.5,-9.2);
	glVertex2f(5.5,-9.4);

	glEnd();

	//width line29
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-9.7);
	glVertex2f(4.6,-9.5);
	glVertex2f(5.5,-9.5);
	glVertex2f(5.5,-9.7);

	glEnd();

	//width line30
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(4.6,-10);
	glVertex2f(4.6,-9.8);
	glVertex2f(5.5,-9.8);
	glVertex2f(5.5,-10);

	glEnd();

	//long line1
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(4.7,-10);
	glVertex2f(4.7,-1);
	glVertex2f(4.8,-1);
	glVertex2f(4.8,-10);

	glEnd();

	//long line2
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(5.3,-10);
	glVertex2f(5.3,-1);
	glVertex2f(5.4,-1);
	glVertex2f(5.4,-10);

	glEnd();


    //glClear(GL_COLOR_BUFFER_BIT);
    glColor3d(0, 0, 1);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    //glTranslatef(0.0f,train1, 0.0f);
    glTranslatef(0.0f,train1, 0.0f);

	//trainback
	glBegin(GL_POLYGON);
    glColor3ub(48, 144, 175);

	glVertex2f(4.5,-3.8);
	glVertex2f(4.5,-1.8);
	glVertex2f(5.6,-1.8);
	glVertex2f(5.6,-3.8);

	glEnd();

	//circle_broader
	glBegin(GL_POLYGON);
    glColor3ub(186, 168, 105);

	glVertex2f(4.8,-3.6);
	glVertex2f(4.8,-2.1);
	glVertex2f(5.4,-2.1);
	glVertex2f(5.4,-3.6);


	glEnd();

	//circle_up
	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
    {
        glColor3ub(121, 117, 103);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5.1,y-2.5);
    }
    glEnd();

    //circle_down
	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
    {
        glColor3ub(121, 117, 103);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5.1,y-3.2);
    }
    glEnd();

	//trainmiddle
	glBegin(GL_POLYGON);
    glColor3ub(48, 144, 175);

	glVertex2f(4.5,-6);
	glVertex2f(4.5,-4);
	glVertex2f(5.6,-4);
	glVertex2f(5.6,-6);

	glEnd();

	//circle_broader
	glBegin(GL_POLYGON);
    glColor3ub(186, 168, 105);

	glVertex2f(4.8,-5.7);
	glVertex2f(4.8,-4.3);
	glVertex2f(5.4,-4.3);
	glVertex2f(5.4,-5.7);


	glEnd();

	//circle_up
	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
    {
        glColor3ub(121, 117, 103);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5.1,y-4.7);
    }
    glEnd();

    //circle_down
	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
    {
        glColor3ub(121, 117, 103);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+5.1,y-5.3);
    }
    glEnd();



	//trainfront
	glBegin(GL_POLYGON);
    glColor3ub(48, 144, 175);

	glVertex2f(4.5,-8.2);
	glVertex2f(4.5,-6.2);
	glVertex2f(5.6,-6.2);
	glVertex2f(5.6,-8.2);

	glEnd();

	//tank1

	//wheel_left
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(4.7,-7.6);
	glVertex2f(4.7,-6.6);
	glVertex2f(4.8,-6.5);
	glVertex2f(4.8,-7.7);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(4.8,-7.6);
	glVertex2f(4.7,-7.5);

	glVertex2f(4.8,-7.5);
	glVertex2f(4.7,-7.4);

	glVertex2f(4.8,-7.4);
	glVertex2f(4.7,-7.3);

	glVertex2f(4.8,-7.3);
	glVertex2f(4.7,-7.2);

	glVertex2f(4.8,-7.2);
	glVertex2f(4.7,-7.1);

	glVertex2f(4.8,-7.1);
	glVertex2f(4.7,-7.0);

	glVertex2f(4.8,-7.0);
	glVertex2f(4.7,-6.9);

	glVertex2f(4.8,-6.9);
	glVertex2f(4.7,-6.8);

	glVertex2f(4.8,-6.8);
	glVertex2f(4.7,-6.7);

	glVertex2f(4.8,-6.7);
	glVertex2f(4.7,-6.6);
	glEnd();

	//wheel_right
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(5.4,-7.7);
	glVertex2f(5.4,-6.5);
	glVertex2f(5.5,-6.6);
	glVertex2f(5.5,-7.6);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(5.4,-7.6);
	glVertex2f(5.5,-7.5);

	glVertex2f(5.4,-7.5);
	glVertex2f(5.5,-7.4);

	glVertex2f(5.4,-7.4);
	glVertex2f(5.5,-7.3);

	glVertex2f(5.4,-7.3);
	glVertex2f(5.5,-7.2);

	glVertex2f(5.4,-7.2);
	glVertex2f(5.5,-7.1);

	glVertex2f(5.4,-7.1);
	glVertex2f(5.5,-7.0);

	glVertex2f(5.4,-7.0);
	glVertex2f(5.5,-6.9);

	glVertex2f(5.4,-6.9);
	glVertex2f(5.5,-6.8);

	glVertex2f(5.4,-6.8);
	glVertex2f(5.5,-6.7);

	glVertex2f(5.4,-6.7);
	glVertex2f(5.5,-6.6);
	glEnd();

	//border
	glBegin(GL_POLYGON);
    glColor3ub(100, 178, 100);

	glVertex2f(4.8,-7.6);
	glVertex2f(4.8,-6.6);
	glVertex2f(5.4,-6.6);
	glVertex2f(5.4,-7.6);

	glEnd();

	//front
	glBegin(GL_POLYGON);
    glColor3ub(108, 188, 108);

	glVertex2f(4.9,-6.7);
	glVertex2f(4.8,-6.6);
	glVertex2f(5.4,-6.6);
	glVertex2f(5.3,-6.7);

	glEnd();

	//back1
	glBegin(GL_POLYGON);
    glColor3ub(118, 186, 118);

	glVertex2f(4.8,-7.6);
	glVertex2f(4.8,-7.5);
	glVertex2f(5.4,-7.5);
	glVertex2f(5.4,-7.6);

	glEnd();

	//back1_box1
	glBegin(GL_POLYGON);
    glColor3ub(192, 223, 192);

	glVertex2f(4.9,-7.6);
	glVertex2f(4.9,-7.5);
	glVertex2f(5,-7.5);
	glVertex2f(5,-7.6);

	glEnd();

	//back1_box2
	glBegin(GL_POLYGON);
    glColor3ub(192, 223, 192);

	glVertex2f(5.2,-7.6);
	glVertex2f(5.2,-7.5);
	glVertex2f(5.3,-7.5);
	glVertex2f(5.3,-7.6);

	glEnd();

	//back2
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(4.8,-7.5);
	glVertex2f(4.9,-7.4);
	glVertex2f(5.3,-7.4);
	glVertex2f(5.4,-7.5);

	glEnd();

	//square1
	glBegin(GL_POLYGON);
    glColor3ub(102, 207, 102);

	glVertex2f(4.9,-7.4);
	glVertex2f(4.9,-7);
	glVertex2f(5.3,-7);
	glVertex2f(5.3,-7.4);

	glEnd();

	//square1_box1
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(4.96,-7.2);
	glVertex2f(4.96,-7.1);
	glVertex2f(5.03,-7.1);
	glVertex2f(5.03,-7.2);

	glEnd();

	//square1_box2
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(5.16,-7.2);
	glVertex2f(5.16,-7.1);
	glVertex2f(5.23,-7.1);
	glVertex2f(5.23,-7.2);

	glEnd();

	//square2
	glBegin(GL_POLYGON);
    glColor3ub(104, 221, 104);

	glVertex2f(4.9,-7);
	glVertex2f(4.9,-6.7);
	glVertex2f(5.3,-6.7);
	glVertex2f(5.3,-7);

	glEnd();

	//square2_box
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(5.06,-6.82);
	glVertex2f(5.06,-6.76);
	glVertex2f(5.14,-6.76);
	glVertex2f(5.14,-6.82);

	glEnd();

	//square2_bullet_left
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(4.98,-7);
	glVertex2f(4.98,-6.35);
	glVertex2f(5.04,-6.35);
	glVertex2f(5.04,-7);

	glEnd();

	//square2_bullet_right
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(5.17,-7);
	glVertex2f(5.17,-6.4);
	glVertex2f(5.23,-6.4);
	glVertex2f(5.23,-7);

	glEnd();
    glPopMatrix();
}

void tree_s()
{
    //rail_line2
    //tree1
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        if (day)
         glColor3ub(72, 167, 44);
        else
        glColor3ub(23, 114, 23);
        //glColor3ub( 72, 167, 44);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.45;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+6.2,y-2.5 );
    }
	glEnd();

	glBegin(GL_POLYGON);
	for(int i=0;i<200;i++)
    {
         if (day)
         glColor3ub( 72, 167, 44);
        else
        glColor3ub(23, 114, 23);
        //glColor3ub( 72, 167, 44);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.45;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+6.9,y-2.6 );
    }
	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+6.7,y-3 );
        }

	glEnd();

    //tree2
    glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+7.1,y-5.3 );
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
             if (day)
         glColor3ub( 72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+6.6,y-4.7);
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
             if (day)
         glColor3ub( 72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+6.4,y-5.5 );
        }

	glEnd();

	//tree3
    glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
             if (day)
         glColor3ub( 72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+6.7,y-7.1 );
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+6.4,y-7.6);
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.45;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+7.1,y-7.4 );
        }

	glEnd();

	//rail_line3

	glBegin(GL_POLYGON);
	glColor3ub( 77, 64, 17 );

	glVertex2f(9.2,-3.8);
	glVertex2f(9,-3);
	glVertex2f(9.3,-2.98);
	glVertex2f(9.3,-2.5);
	glVertex2f(9.5,-3.5);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub( 88, 72, 20  );

	glVertex2f(9.2,-4.5);
	glVertex2f(9.2,-3.8);
	glVertex2f(9.5,-3.5);
	glVertex2f(9.6,-4.3);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub( 99, 81, 23 );

	glVertex2f(9.1,-5.1);
	glVertex2f(9.2,-4.5);
	glVertex2f(9.6,-4.3);
	glVertex2f(9.4,-5.3);

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(64, 158, 46);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 64, 158, 46 );
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.5;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+9.3,y-4.8 );
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(64, 158, 46);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 64, 158, 46 );
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.6;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+9,y-5.6 );
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(64, 158, 46);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 64, 158, 46 );
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.5;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+9.45,y-5.5 );
        }

	glEnd();

	//rail_line4
    //tree1
    glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(56, 167, 34);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 56, 167, 34 );
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.5;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+12.5,y-1.5 );
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
            if (day)
         glColor3ub(72, 167, 44);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub( 72, 167, 44);
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.5;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+12.1,y-2.2 );
        }

	glEnd();

	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
        {
             if (day)
         glColor3ub( 56, 167, 34);
        else
        glColor3ub(23, 114, 23);
            //glColor3ub(  56, 167, 34 );
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.5;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x+13,y-2 );
        }

	glEnd();

}

void rail_line3_s()
{
    //broader1
    if (day)
         glColor3ub(247, 231, 141);
    else
        glColor3ub(188, 151, 75);
    glBegin(GL_POLYGON);
    //glColor3ub(247, 231, 141);

	glVertex2f(7.4,-10);
	glVertex2f(7.4,-1);
	glVertex2f(8.4,-1);
	glVertex2f(8.4,-10);

	glEnd();

	//width line1
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-1.3);
	glVertex2f(7.5,-1.1);
	glVertex2f(8.3,-1.1);
	glVertex2f(8.3,-1.3);

	glEnd();

	//width line2
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-1.6);
	glVertex2f(7.5,-1.4);
	glVertex2f(8.3,-1.4);
	glVertex2f(8.3,-1.6);

	glEnd();

	//width line3
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-1.9);
	glVertex2f(7.5,-1.7);
	glVertex2f(8.3,-1.7);
	glVertex2f(8.3,-1.9);

	glEnd();

	//width line4
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-2.2);
	glVertex2f(7.5,-2);
	glVertex2f(8.3,-2);
	glVertex2f(8.3,-2.2);

	glEnd();

	//width line5
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-2.5);
	glVertex2f(7.5,-2.3);
	glVertex2f(8.3,-2.3);
	glVertex2f(8.3,-2.5);

	glEnd();

	//width line6
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-2.8);
	glVertex2f(7.5,-2.6);
	glVertex2f(8.3,-2.6);
	glVertex2f(8.3,-2.8);

	glEnd();

	//width line7
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-3.1);
	glVertex2f(7.5,-2.9);
	glVertex2f(8.3,-2.9);
	glVertex2f(8.3,-3.1);

	glEnd();

	//width line8
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-3.4);
	glVertex2f(7.5,-3.2);
	glVertex2f(8.3,-3.2);
	glVertex2f(8.3,-3.4);

	glEnd();

	//width line9
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-3.7);
	glVertex2f(7.5,-3.5);
	glVertex2f(8.3,-3.5);
	glVertex2f(8.3,-3.7);

	glEnd();

	//width line10
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-4);
	glVertex2f(7.5,-3.8);
	glVertex2f(8.3,-3.8);
	glVertex2f(8.3,-4);

	glEnd();

	//width line11
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-4.3);
	glVertex2f(7.5,-4.1);
	glVertex2f(8.3,-4.1);
	glVertex2f(8.3,-4.3);

	glEnd();

	//width line12
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-4.6);
	glVertex2f(7.5,-4.4);
	glVertex2f(8.3,-4.4);
	glVertex2f(8.3,-4.6);

	glEnd();

	//width line13
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-4.9);
	glVertex2f(7.5,-4.7);
	glVertex2f(8.3,-4.7);
	glVertex2f(8.3,-4.9);

	glEnd();

	//width line14
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-5.2);
	glVertex2f(7.5,-5);
	glVertex2f(8.3,-5);
	glVertex2f(8.3,-5.2);

	glEnd();

	//width line15
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-5.5);
	glVertex2f(7.5,-5.3);
	glVertex2f(8.3,-5.3);
	glVertex2f(8.3,-5.5);

	glEnd();

	//width line16
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-5.8);
	glVertex2f(7.5,-5.6);
	glVertex2f(8.3,-5.6);
	glVertex2f(8.3,-5.8);

	glEnd();

	//width line17
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-6.1);
	glVertex2f(7.5,-5.9);
	glVertex2f(8.3,-5.9);
	glVertex2f(8.3,-6.1);

	glEnd();

	//width line18
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-6.4);
	glVertex2f(7.5,-6.2);
	glVertex2f(8.3,-6.2);
	glVertex2f(8.3,-6.4);

	glEnd();

	//width line19
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-6.7);
	glVertex2f(7.5,-6.5);
	glVertex2f(8.3,-6.5);
	glVertex2f(8.3,-6.7);

	glEnd();

	//width line20
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-7);
	glVertex2f(7.5,-6.8);
	glVertex2f(8.3,-6.8);
	glVertex2f(8.3,-7);

	glEnd();

	//width line21
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-7.3);
	glVertex2f(7.5,-7.1);
	glVertex2f(8.3,-7.1);
	glVertex2f(8.3,-7.3);

	glEnd();
	//width line22
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-7.6);
	glVertex2f(7.5,-7.4);
	glVertex2f(8.3,-7.4);
	glVertex2f(8.3,-7.6);

	glEnd();

	//width line23
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-7.9);
	glVertex2f(7.5,-7.7);
	glVertex2f(8.3,-7.7);
	glVertex2f(8.3,-7.9);

	glEnd();
	//width line24
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-8.2);
	glVertex2f(7.5,-8);
	glVertex2f(8.3,-8);
	glVertex2f(8.3,-8.2);

	glEnd();
	//width line25
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-8.5);
	glVertex2f(7.5,-8.3);
	glVertex2f(8.3,-8.3);
	glVertex2f(8.3,-8.5);

	glEnd();
	//width line26
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-8.8);
	glVertex2f(7.5,-8.6);
	glVertex2f(8.3,-8.6);
	glVertex2f(8.3,-8.8);

	glEnd();

	//width line27
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-9.1);
	glVertex2f(7.5,-8.9);
	glVertex2f(8.3,-8.9);
	glVertex2f(8.3,-9.1);

	glEnd();

	//width line28
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-9.4);
	glVertex2f(7.5,-9.2);
	glVertex2f(8.3,-9.2);
	glVertex2f(8.3,-9.4);

	glEnd();

	//width line29
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-9.7);
	glVertex2f(7.5,-9.5);
	glVertex2f(8.3,-9.5);
	glVertex2f(8.3,-9.7);

	glEnd();

	//width line30
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(7.5,-10);
	glVertex2f(7.5,-9.8);
	glVertex2f(8.3,-9.8);
	glVertex2f(8.3,-10);

	glEnd();

    //long line1
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(7.6,-10);
	glVertex2f(7.6,-1);
	glVertex2f(7.7,-1);
	glVertex2f(7.7,-10);

	glEnd();

	//long line2
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(8.1,-10);
	glVertex2f(8.1,-1);
	glVertex2f(8.2,-1);
	glVertex2f(8.2,-10);

	glEnd();

	//broken_up
	if (day)
        glColor3ub(247, 231, 141);
    else
        glColor3ub(188, 151, 75);
	glLineWidth(20);
	glBegin(GL_LINES);
    //glColor3ub(239, 209, 114);

	glVertex2f(7.4,-5.98);
	glVertex2f(7.7,-6.1);
	glVertex2f(7.7,-6.1);
	glVertex2f(7.9,-5.7);
	glVertex2f(7.9,-5.7);
	glVertex2f(8.2,-5.9);
	glVertex2f(8.2,-5.9);
	glVertex2f(8.3,-5.6);
	glVertex2f(8.3,-5.6);
	glVertex2f(8.6,-5.5);

	glEnd();

	//broken_bomb
	 if (day)
         glColor3ub( 211, 172, 111);
    else
        glColor3ub(123, 97, 10);
	glLineWidth(20);
	glBegin(GL_LINES);
    //glColor3ub(211, 172, 111 );

	glVertex2f(7.4,-7.9);
	glVertex2f(7.9,-6.9);
	glVertex2f(7.9,-6.9);
	glVertex2f(7.9,-7.5);
	glVertex2f(7.9,-7.5);
	glVertex2f(8.1,-7.9);
	glVertex2f(8.1,-7.9);
	glVertex2f(8.5,-7.4);
	glVertex2f(8.5,-7.4);
	glVertex2f(8.4,-7.9);
	glVertex2f(8.4,-7.9);
	glVertex2f(8.7,-8.1);
	glVertex2f(8.7,-8.1);
	glVertex2f(8.4,-8.2);
	glVertex2f(8.4,-8.2);
	glVertex2f(8.4,-8.5);
	glVertex2f(8.4,-8.5);
	glVertex2f(8.0,-8.3);
	glVertex2f(8.0,-8.3);
	glVertex2f(7.9,-8.5);
	glVertex2f(7.9,-8.5);
	glVertex2f(7.6,-8.4);
	glVertex2f(7.6,-8.4);
	glVertex2f(7.8,-8.1);
	glVertex2f(7.8,-8.1);
	glVertex2f(7.4,-7.9);
	glVertex2f(7.4,-7.9);
	glVertex2f(7.8,-7.8);

	glEnd();

	if (day)
         glColor3ub( 129, 98, 67  );
    else
        glColor3ub(147, 121, 31);
	glBegin(GL_POLYGON);
    //glColor3ub( 220, 183, 87   );

	glVertex2f(7.4,-7.9);
	glVertex2f(7.9,-6.9);
	glVertex2f(7.9,-7.5);
	glVertex2f(8.1,-7.9);
	glVertex2f(8.5,-7.4);
	glVertex2f(8.4,-7.9);
	glVertex2f(8.7,-8.1);
	glVertex2f(8.4,-8.2);
	glVertex2f(8.4,-8.5);
	glVertex2f(8.0,-8.3);
	glVertex2f(7.9,-8.5);
	glVertex2f(7.6,-8.4);
	glVertex2f(7.8,-8.1);
	glVertex2f(7.4,-7.9);
	glVertex2f(7.8,-7.8);

	glEnd();
}

void rail_line4_s()
{
    //broader1
    if (day)
         glColor3ub(247, 231, 141);
    else
        glColor3ub(188, 151, 75);
    glBegin(GL_POLYGON);
    //glColor3ub(247, 231, 141);

	glVertex2f(10,-10);
	glVertex2f(10,-1);
	glVertex2f(11.1,-1);
	glVertex2f(11.1,-10);

	glEnd();

	//width line1
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-1.3);
	glVertex2f(10.1,-1.1);
	glVertex2f(11,-1.1);
	glVertex2f(11,-1.3);

	glEnd();

	//width line2
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-1.6);
	glVertex2f(10.1,-1.4);
	glVertex2f(11,-1.4);
	glVertex2f(11,-1.6);

	glEnd();

	//width line3
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-1.9);
	glVertex2f(10.1,-1.7);
	glVertex2f(11,-1.7);
	glVertex2f(11,-1.9);

	glEnd();

	//width line4
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-2.2);
	glVertex2f(10.1,-2);
	glVertex2f(11,-2);
	glVertex2f(11,-2.2);

	glEnd();

	//width line5
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-2.5);
	glVertex2f(10.1,-2.3);
	glVertex2f(11,-2.3);
	glVertex2f(11,-2.5);

	glEnd();

	//width line6
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-2.8);
	glVertex2f(10.1,-2.6);
	glVertex2f(11,-2.6);
	glVertex2f(11,-2.8);

	glEnd();

	//width line7
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-3.1);
	glVertex2f(10.1,-2.9);
	glVertex2f(11,-2.9);
	glVertex2f(11,-3.1);

	glEnd();

	//width line8
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-3.4);
	glVertex2f(10.1,-3.2);
	glVertex2f(11,-3.2);
	glVertex2f(11,-3.4);

	glEnd();

	//width line9
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-3.7);
	glVertex2f(10.1,-3.5);
	glVertex2f(11,-3.5);
	glVertex2f(11,-3.7);

	glEnd();

	//width line10
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-4);
	glVertex2f(10.1,-3.8);
	glVertex2f(11,-3.8);
	glVertex2f(11,-4);

	glEnd();

	//width line11
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-4.3);
	glVertex2f(10.1,-4.1);
	glVertex2f(11,-4.1);
	glVertex2f(11,-4.3);

	glEnd();

	//width line12
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-4.6);
	glVertex2f(10.1,-4.4);
	glVertex2f(11,-4.4);
	glVertex2f(11,-4.6);

	glEnd();

	//width line13
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-4.9);
	glVertex2f(10.1,-4.7);
	glVertex2f(11,-4.7);
	glVertex2f(11,-4.9);

	glEnd();

	//width line14
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-5.2);
	glVertex2f(10.1,-5);
	glVertex2f(11,-5);
	glVertex2f(11,-5.2);

	glEnd();

	//width line15
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-5.5);
	glVertex2f(10.1,-5.3);
	glVertex2f(11,-5.3);
	glVertex2f(11,-5.5);

	glEnd();

	//width line16
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-5.8);
	glVertex2f(10.1,-5.6);
	glVertex2f(11,-5.6);
	glVertex2f(11,-5.8);

	glEnd();

	//width line17
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-6.1);
	glVertex2f(10.1,-5.9);
	glVertex2f(11,-5.9);
	glVertex2f(11,-6.1);

	glEnd();

	//width line18
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-6.4);
	glVertex2f(10.1,-6.2);
	glVertex2f(11,-6.2);
	glVertex2f(11,-6.4);

	glEnd();

	//width line19
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-6.7);
	glVertex2f(10.1,-6.5);
	glVertex2f(11,-6.5);
	glVertex2f(11,-6.7);

	glEnd();

	//width line20
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-7);
	glVertex2f(10.1,-6.8);
	glVertex2f(11,-6.8);
	glVertex2f(11,-7);

	glEnd();

	//width line21
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-7.3);
	glVertex2f(10.1,-7.1);
	glVertex2f(11,-7.1);
	glVertex2f(11,-7.3);

	glEnd();
	//width line22
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-7.6);
	glVertex2f(10.1,-7.4);
	glVertex2f(11,-7.4);
	glVertex2f(11,-7.6);

	glEnd();

	//width line23
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-7.9);
	glVertex2f(10.1,-7.7);
	glVertex2f(11,-7.7);
	glVertex2f(11,-7.9);

	glEnd();
	//width line24
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-8.2);
	glVertex2f(10.1,-8);
	glVertex2f(11,-8);
	glVertex2f(11,-8.2);

	glEnd();
	//width line25
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-8.5);
	glVertex2f(10.1,-8.3);
	glVertex2f(11,-8.3);
	glVertex2f(11,-8.5);

	glEnd();
	//width line26
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-8.8);
	glVertex2f(10.1,-8.6);
	glVertex2f(11,-8.6);
	glVertex2f(11,-8.8);

	glEnd();

	//width line27
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-9.1);
	glVertex2f(10.1,-8.9);
	glVertex2f(11,-8.9);
	glVertex2f(11,-9.1);

	glEnd();

	//width line28
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-9.4);
	glVertex2f(10.1,-9.2);
	glVertex2f(11,-9.2);
	glVertex2f(11,-9.4);

	glEnd();

	//width line29
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-9.7);
	glVertex2f(10.1,-9.5);
	glVertex2f(11,-9.5);
	glVertex2f(11,-9.7);

	glEnd();

	//width line30
	glBegin(GL_POLYGON);
    glColor3ub(223, 183, 50);

	glVertex2f(10.1,-10);
	glVertex2f(10.1,-9.8);
	glVertex2f(11,-9.8);
	glVertex2f(11,-10);

	glEnd();

		//long line1
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(10.2,-10);
	glVertex2f(10.2,-1);
	glVertex2f(10.3,-1);
	glVertex2f(10.3,-10);

	glEnd();

	//long line2
	glBegin(GL_POLYGON);
    glColor3ub(142, 147, 142);

	glVertex2f(10.8,-10);
	glVertex2f(10.8,-1);
	glVertex2f(10.9,-1);
	glVertex2f(10.9,-10);

	glEnd();

    //glClear(GL_COLOR_BUFFER_BIT);
    glColor3d(0, 0, 1);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0.0f,train2, 0.0f);

	//trainback
	glBegin(GL_POLYGON);
    glColor3ub(211, 160, 51);

	glVertex2f(10,-4);
	glVertex2f(10,-2.2);
	glVertex2f(11.1,-2.2);
	glVertex2f(11.1,-4);

	glEnd();

	//tank2

	//wheel_left
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.1,-3.4);
	glVertex2f(10.1,-2.5);
	glVertex2f(10.2,-2.4);
	glVertex2f(10.2,-3.5);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.2,-3.4);
	glVertex2f(10.1,-3.3);

	glVertex2f(10.2,-3.3);
	glVertex2f(10.1,-3.2);

	glVertex2f(10.2,-3.2);
	glVertex2f(10.1,-3.1);

	glVertex2f(10.2,-3.1);
	glVertex2f(10.1,-3.0);

	glVertex2f(10.2,-3.0);
	glVertex2f(10.1,-2.9);

	glVertex2f(10.2,-2.9);
	glVertex2f(10.1,-2.8);

	glVertex2f(10.2,-2.8);
	glVertex2f(10.1,-2.7);

	glVertex2f(10.2,-2.7);
	glVertex2f(10.1,-2.6);

	glVertex2f(10.2,-2.6);
	glVertex2f(10.1,-2.5);

	glEnd();

	//wheel_right
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.8,-3.5);
	glVertex2f(10.8,-2.4);
	glVertex2f(10.9,-2.5);
	glVertex2f(10.9,-3.4);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.8,-3.4);
	glVertex2f(10.9,-3.3);

	glVertex2f(10.8,-3.3);
	glVertex2f(10.9,-3.2);

	glVertex2f(10.8,-3.2);
	glVertex2f(10.9,-3.1);

	glVertex2f(10.8,-3.1);
	glVertex2f(10.9,-3.0);

	glVertex2f(10.8,-3.0);
	glVertex2f(10.9,-2.9);

	glVertex2f(10.8,-2.9);
	glVertex2f(10.9,-2.8);

	glVertex2f(10.8,-2.8);
	glVertex2f(10.9,-2.7);

	glVertex2f(10.8,-2.7);
	glVertex2f(10.9,-2.6);

	glVertex2f(10.8,-2.6);
	glVertex2f(10.9,-2.5);

	glEnd();

	//border
	glBegin(GL_POLYGON);
    glColor3ub(100, 178, 100);

	glVertex2f(10.2,-3.4);
	glVertex2f(10.2,-2.5);
	glVertex2f(10.8,-2.5);
	glVertex2f(10.8,-3.4);

	glEnd();

	//front
	glBegin(GL_POLYGON);
    glColor3ub(108, 188, 108);

	glVertex2f(10.3,-2.6);
	glVertex2f(10.2,-2.5);
	glVertex2f(10.8,-2.5);
	glVertex2f(10.7,-2.6);

	glEnd();

	//back1
	glBegin(GL_POLYGON);
    glColor3ub(118, 186, 118);

	glVertex2f(10.2,-3.4);
	glVertex2f(10.3,-3.3);
	glVertex2f(10.7,-3.3);
	glVertex2f(10.8,-3.4);

	glEnd();

	//back1_box1
	glBegin(GL_POLYGON);
    glColor3ub(192, 223, 192);

	glVertex2f(10.3,-3.4);
	glVertex2f(10.3,-3.3);
	glVertex2f(10.4,-3.3);
	glVertex2f(10.4,-3.4);

	glEnd();

	//back1_box2
	glBegin(GL_POLYGON);
    glColor3ub(192, 223, 192);

	glVertex2f(10.6,-3.4);
	glVertex2f(10.6,-3.3);
	glVertex2f(10.7,-3.3);
	glVertex2f(10.7,-3.4);

	glEnd();

	//back2
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.3,-3.3);
	glVertex2f(10.3,-3.2);
	glVertex2f(10.7,-3.2);
	glVertex2f(10.7,-3.3);

	glEnd();

	//square1
	glBegin(GL_POLYGON);
    glColor3ub(102, 207, 102);

	glVertex2f(10.3,-3.2);
	glVertex2f(10.3,-2.9);
	glVertex2f(10.7,-2.9);
	glVertex2f(10.7,-3.2);

	glEnd();

	//square1_box1
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(10.36,-3.1);
	glVertex2f(10.36,-3);
	glVertex2f(10.44,-3);
	glVertex2f(10.44,-3.1);

	glEnd();

	//square1_box2
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(10.56,-3.1);
	glVertex2f(10.56,-3);
	glVertex2f(10.64,-3);
	glVertex2f(10.64,-3.1);

	glEnd();

	//square2
	glBegin(GL_POLYGON);
    glColor3ub( 77, 203, 77 );

	glVertex2f(10.3,-2.9);
	glVertex2f(10.3,-2.6);
	glVertex2f(10.7,-2.6);
	glVertex2f(10.7,-2.9);

	glEnd();

	//square2_box
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(10.46,-2.8);
	glVertex2f(10.46,-2.7);
	glVertex2f(10.54,-2.7);
	glVertex2f(10.54,-2.8);

	glEnd();

	//square2_bullet_left
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(10.36,-2.9);
	glVertex2f(10.36,-2.3);
	glVertex2f(10.4,-2.3);
	glVertex2f(10.4,-2.9);

	glEnd();

	//square2_bullet_right
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(10.6,-2.9);
	glVertex2f(10.6,-2.32);
	glVertex2f(10.64,-2.32);
	glVertex2f(10.64,-2.9);

	glEnd();

	//trainmiddle
	glBegin(GL_POLYGON);
    glColor3ub(211, 160, 51);

	glVertex2f(10,-6);
	glVertex2f(10,-4.2);
	glVertex2f(11.1,-4.2);
	glVertex2f(11.1,-6);

	glEnd();

    //trainfront
	glBegin(GL_POLYGON);
    glColor3ub(211, 160, 51);

	glVertex2f(10,-8.2);
	glVertex2f(10,-6.2);
	glVertex2f(11.1,-6.2);
	glVertex2f(11.1,-8.2);

	glEnd();

	//misaiel1

    //wheel_left_up
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.14,-4.92);
	glVertex2f(10.14,-4.72);
	glVertex2f(10.19,-4.72);
	glVertex2f(10.19,-4.92);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.14,-4.72);
	glVertex2f(10.19,-4.77);

	glVertex2f(10.14,-4.77);
	glVertex2f(10.19,-4.82);

	glVertex2f(10.14,-4.82);
	glVertex2f(10.19,-4.87);

	glVertex2f(10.14,-4.87);
	glVertex2f(10.19,-4.92);

	glEnd();

	//wheel_left_middle
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.14,-5.16);
	glVertex2f(10.14,-4.96);
	glVertex2f(10.19,-4.96);
	glVertex2f(10.19,-5.16);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.14,-4.96);
	glVertex2f(10.19,-5);

	glVertex2f(10.14,-5);
	glVertex2f(10.19,-5.05);

	glVertex2f(10.14,-5.05);
	glVertex2f(10.19,-5.11);

	glVertex2f(10.14,-5.11);
	glVertex2f(10.19,-5.15);

	glEnd();

	//wheel_left_down
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.14,-5.4);
	glVertex2f(10.14,-5.2);
	glVertex2f(10.19,-5.2);
	glVertex2f(10.19,-5.4);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.14,-5.2);
	glVertex2f(10.19,-5.25);

	glVertex2f(10.14,-5.25);
	glVertex2f(10.19,-5.3);

	glVertex2f(10.14,-5.3);
	glVertex2f(10.19,-5.35);

	glVertex2f(10.14,-5.35);
	glVertex2f(10.19,-5.4);

	glEnd();

	//wheel_right_up
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.8,-4.92);
	glVertex2f(10.8,-4.72);
	glVertex2f(10.85,-4.72);
	glVertex2f(10.85,-4.92);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.8,-4.72);
	glVertex2f(10.85,-4.77);

	glVertex2f(10.8,-4.77);
	glVertex2f(10.85,-4.82);

	glVertex2f(10.8,-4.82);
	glVertex2f(10.85,-4.87);

	glVertex2f(10.8,-4.87);
	glVertex2f(10.85,-4.92);

	glEnd();

	//wheel_left_middle
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.8,-5.16);
	glVertex2f(10.8,-4.96);
	glVertex2f(10.85,-4.96);
	glVertex2f(10.85,-5.16);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.8,-4.96);
	glVertex2f(10.85,-5);

	glVertex2f(10.8,-5);
	glVertex2f(10.85,-5.05);

	glVertex2f(10.8,-5.05);
	glVertex2f(10.85,-5.11);

	glVertex2f(10.8,-5.11);
	glVertex2f(10.85,-5.15);

	glEnd();

	//wheel_left_down
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(10.8,-5.4);
	glVertex2f(10.8,-5.2);
	glVertex2f(10.85,-5.2);
	glVertex2f(10.85,-5.4);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(10.8,-5.2);
	glVertex2f(10.85,-5.25);

	glVertex2f(10.8,-5.25);
	glVertex2f(10.85,-5.3);

	glVertex2f(10.8,-5.3);
	glVertex2f(10.85,-5.35);

	glVertex2f(10.8,-5.35);
	glVertex2f(10.85,-5.4);

	glEnd();


	//border_out
	glBegin(GL_POLYGON);
    glColor3ub(100, 178, 100);

	glVertex2f(10.3,-5.7);
	glVertex2f(10.2,-5.5);
	glVertex2f(10.2,-4.7);
	glVertex2f(10.3,-4.5);
	glVertex2f(10.7,-4.5);
	glVertex2f(10.8,-4.7);
	glVertex2f(10.8,-5.5);
	glVertex2f(10.7,-5.7);

	glEnd();

	//border_in
	glBegin(GL_POLYGON);
    glColor3ub(79, 173, 79);

	glVertex2f(10.4,-5.6);
	glVertex2f(10.3,-5.5);
	glVertex2f(10.3,-4.7);
	glVertex2f(10.4,-4.6);
	glVertex2f(10.6,-4.6);
	glVertex2f(10.7,-4.7);
	glVertex2f(10.7,-5.5);
	glVertex2f(10.6,-5.6);

	glEnd();

	//front
	glBegin(GL_POLYGON);
    glColor3ub(108, 188, 108);

	glVertex2f(10.4,-4.6);
	glVertex2f(10.4,-4.5);
	glVertex2f(10.6,-4.5);
	glVertex2f(10.6,-4.6);

	glEnd();

	//back_box_left
	glBegin(GL_POLYGON);
    glColor3ub(15, 108, 15);

	glVertex2f(10.4,-5.7);
	glVertex2f(10.4,-5.6);
	glVertex2f(10.45,-5.6);
	glVertex2f(10.45,-5.7);

	glEnd();

	//back_box_right
	glBegin(GL_POLYGON);
    glColor3ub(15, 108, 15);

	glVertex2f(10.55,-5.7);
	glVertex2f(10.55,-5.6);
	glVertex2f(10.6,-5.6);
	glVertex2f(10.6,-5.7);

	glEnd();

	//body_box_left_up
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.35,-5.1);
	glVertex2f(10.35,-5);
	glVertex2f(10.45,-5);
	glVertex2f(10.45,-5.1);

	glEnd();

	//body_box_left_middle
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.35,-5.25);
	glVertex2f(10.35,-5.15);
	glVertex2f(10.45,-5.15);
	glVertex2f(10.45,-5.25);

	glEnd();

	//body_box_left_down
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.35,-5.4);
	glVertex2f(10.35,-5.3);
	glVertex2f(10.45,-5.3);
	glVertex2f(10.45,-5.4);

	glEnd();

	//body_box_right_up
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.55,-5.1);
	glVertex2f(10.55,-5);
	glVertex2f(10.65,-5);
	glVertex2f(10.65,-5.1);

	glEnd();

	//body_box_right_middle
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.55,-5.25);
	glVertex2f(10.55,-5.15);
	glVertex2f(10.65,-5.15);
	glVertex2f(10.65,-5.25);

	glEnd();

	//body_box_right_down
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(10.55,-5.4);
	glVertex2f(10.55,-5.3);
	glVertex2f(10.65,-5.3);
	glVertex2f(10.65,-5.4);

	glEnd();

	//body_box_up_corner_left
	glBegin(GL_POLYGON);
    glColor3ub(67, 132, 67);

	glVertex2f(10.3,-4.97);
	glVertex2f(10.3,-4.92);
	glVertex2f(10.38,-4.92);
	glVertex2f(10.38,-4.97);

	glEnd();

	//body_box_down_corner_right
	glBegin(GL_POLYGON);
    glColor3ub(67, 132, 67);

	glVertex2f(10.6,-5.5);
	glVertex2f(10.6,-5.45);
	glVertex2f(10.65,-5.45);
	glVertex2f(10.65,-5.5);

	glEnd();

	//sixton_out
	glBegin(GL_POLYGON);
    glColor3ub(63, 156, 63);

	glVertex2f(10.4,-4.95);
	glVertex2f(10.36,-4.80);
	glVertex2f(10.4,-4.65);
	glVertex2f(10.6,-4.65);
	glVertex2f(10.64,-4.80);
	glVertex2f(10.6,-4.95);

	glEnd();

	//sixton_in
	glBegin(GL_POLYGON);
    glColor3ub(75, 175, 75 );

	glVertex2f(10.45,-4.9);
	glVertex2f(10.42,-4.80);
	glVertex2f(10.45,-4.7);
	glVertex2f(10.55,-4.7);
	glVertex2f(10.58,-4.80);
	glVertex2f(10.55,-4.9);

	glEnd();

	//sixton_box_up
	glBegin(GL_POLYGON);
    glColor3ub(9, 135, 9);

	glVertex2f(10.5,-4.8);
	glVertex2f(10.5,-4.7);
	glVertex2f(10.55,-4.7);
	glVertex2f(10.55,-4.8);

	glEnd();

	//sixton_box_down
	glBegin(GL_POLYGON);
    glColor3ub(9, 135, 9);

	glVertex2f(10.45,-4.9);
	glVertex2f(10.45,-4.8);
	glVertex2f(10.5,-4.8);
	glVertex2f(10.5,-4.9);

	glEnd();


	//bounder_left_box1
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.23,-4.9);
	glVertex2f(10.23,-4.8);
	glVertex2f(10.27,-4.8);
	glVertex2f(10.27,-4.9);

	glEnd();

	//bounder_left_box2
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.23,-4.92);
	glVertex2f(10.23,-5.02);
	glVertex2f(10.27,-5.02);
	glVertex2f(10.27,-4.92);

	glEnd();

	//bounder_left_box3
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.23,-5.17);
	glVertex2f(10.23,-5.07);
	glVertex2f(10.27,-5.07);
	glVertex2f(10.27,-5.17);


	glEnd();

	//bounder_left_box4
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.23,-5.3);
	glVertex2f(10.23,-5.2);
	glVertex2f(10.27,-5.2);
	glVertex2f(10.27,-5.3);

	glEnd();

	//bounder_right_box1
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.73,-4.9);
	glVertex2f(10.73,-4.8);
	glVertex2f(10.77,-4.8);
	glVertex2f(10.77,-4.9);

	glEnd();

	//bounder_right_box2
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.73,-4.92);
	glVertex2f(10.73,-5.02);
	glVertex2f(10.77,-5.02);
	glVertex2f(10.77,-4.92);

	glEnd();

	//bounder_right_box3
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.73,-5.17);
	glVertex2f(10.73,-5.07);
	glVertex2f(10.77,-5.07);
	glVertex2f(10.77,-5.17);


	glEnd();

	//bounder_right_box4
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(10.73,-5.3);
	glVertex2f(10.73,-5.2);
	glVertex2f(10.77,-5.2);
	glVertex2f(10.77,-5.3);

	glEnd();

	//bullet_left
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(10.45,-4.7);
	glVertex2f(10.45,-4.4);
	glVertex2f(10.47,-4.4);
	glVertex2f(10.47,-4.7);

	glEnd();

	//bullet_right
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(10.53,-4.7);
	glVertex2f(10.53,-4.3);
	glVertex2f(10.55,-4.3);
	glVertex2f(10.55,-4.7);

	glEnd();

	//circle_broader
	glBegin(GL_POLYGON);
    glColor3ub(162, 129, 78);

	glVertex2f(10.2,-7.7);
	glVertex2f(10.2,-6.4);
	glVertex2f(10.8,-6.4);
	glVertex2f(10.8,-7.7);


	glEnd();

	//circle_up
	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
    {
        glColor3ub(87, 47, 7 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+10.5,y-6.7);
    }
    glEnd();

    //circle_down
	glBegin(GL_POLYGON);

	for(int i=0;i<200;i++)
    {
        glColor3ub(87, 47, 7 );
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+10.5,y-7.4);
    }
    glEnd();


    glPopMatrix();

}

void train_platform2_s()
{
    //out
    if (day)
         glColor3ub(212, 204, 188);
    else
        glColor3ub(58, 55, 45  );
    glBegin(GL_POLYGON);
    //glColor3ub(212, 204, 188);

	glVertex2f(13.2,-8);
	glVertex2f(13.2,-3.2);
	glVertex2f(16,-3.2);
	glVertex2f(16,-8);

	glEnd();

	//middle
	if (day)
         glColor3ub(153, 147, 135);
    else
        glColor3ub(108, 105, 93 );
    glBegin(GL_POLYGON);
    //glColor3ub(153, 147, 135);

	glVertex2f(13.4,-7);
	glVertex2f(13.4,-4);
	glVertex2f(13.7,-4);
	glVertex2f(13.7,-7);

	glEnd();


    //in
    if (day)
         glColor3ub(194, 182, 156);
    else
        glColor3ub(108, 105, 93 );
    glBegin(GL_POLYGON);
    //glColor3ub(194, 182, 156);

	glVertex2f(14,-7.6);
	glVertex2f(14,-3.6);
	glVertex2f(15.6,-3.6);
	glVertex2f(15.6,-7.6);

	glEnd();

    //3
    glBegin(GL_POLYGON);
    glColor3ub(216, 202, 173);

	glVertex2f(14.4,-7.2);
	glVertex2f(14.4,-6.4);
	glVertex2f(15.2,-6.4);
	glVertex2f(15.2,-7.2);

	glEnd();

    //2
    glBegin(GL_POLYGON);
    glColor3ub(216, 202, 173);

	glVertex2f(14.4,-6);
	glVertex2f(14.4,-5.2);
	glVertex2f(15.2,-5.2);
	glVertex2f(15.2,-6);

	glEnd();

    //1
    glBegin(GL_POLYGON);
    glColor3ub(216, 202, 173);

	glVertex2f(14.4,-4.8);
	glVertex2f(14.4,-4);
	glVertex2f(15.2,-4);
	glVertex2f(15.2,-4.8);

	glEnd();
}

void road_s()
{
    //broader1
    if (day)
        glColor3ub(155, 167, 155);
    else
        glColor3ub(93, 90, 82);
    glBegin(GL_POLYGON);

    //glColor3ub(155, 167, 155);

	glVertex2f(18,-10);
	glVertex2f(18,-4);
    glVertex2f(20,-4);
    glVertex2f(20,-10);

	glEnd();

	//border 2
	if (day)
        glColor3ub(155, 167, 155);
    else
        glColor3ub(93, 90, 82);
    glBegin(GL_POLYGON);
    //glColor3ub(155, 167, 155);

	glVertex2f(16,-6);
	glVertex2f(16,-4);
    glVertex2f(18,-4);
    glVertex2f(18,-6);

	glEnd();

	//middle white line
	glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);

	glVertex2f(18.96,-10);
	glVertex2f(18.96,-6);
	glVertex2f(19.05,-6);
	glVertex2f(19.05,-10);

	glEnd();
}

void tank3_s()
{
    //wheel_left
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(14.32,-2.7);
	glVertex2f(14.32,-1.7);
	glVertex2f(14.4,-1.6);
	glVertex2f(14.4,-2.8);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(14.32,-2.6);
	glVertex2f(14.4,-2.6);

	glVertex2f(14.32,-2.4);
	glVertex2f(14.4,-2.4);

	glVertex2f(14.32,-2.2);
	glVertex2f(14.4,-2.2);

	glVertex2f(14.32,-2.0);
	glVertex2f(14.4,-2.0);

	glVertex2f(14.32,-1.8);
	glVertex2f(14.4,-1.8);

	glEnd();

	//wheel_right
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(15.68,-2.7);
	glVertex2f(15.68,-1.7);
	glVertex2f(15.6,-1.6);
	glVertex2f(15.6,-2.8);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(15.68,-2.6);
	glVertex2f(15.6,-2.6);

	glVertex2f(15.68,-2.4);
	glVertex2f(15.6,-2.4);

	glVertex2f(15.68,-2.2);
	glVertex2f(15.6,-2.2);

	glVertex2f(15.68,-2.0);
	glVertex2f(15.6,-2.0);

	glVertex2f(15.68,-1.8);
	glVertex2f(15.6,-1.8);

	glEnd();

	//wheel_left1
	glBegin(GL_POLYGON);
    glColor3ub(55, 122, 55);

	glVertex2f(14.4,-2.8);
	glVertex2f(14.4,-1.6);
	glVertex2f(14.6,-1.6);
	glVertex2f(14.6,-2.8);

	glEnd();

	//wheel_right1
	glBegin(GL_POLYGON);
    glColor3ub(55, 122, 55);

	glVertex2f(15.4,-2.8);
	glVertex2f(15.4,-1.6);
	glVertex2f(15.6,-1.6);
	glVertex2f(15.6,-2.8);

	glEnd();

	//border
	glBegin(GL_POLYGON);
    glColor3ub(100, 178, 100);

	glVertex2f(14.52,-2.7);
	glVertex2f(14.52,-1.7);
	glVertex2f(15.5,-1.7);
	glVertex2f(15.5,-2.7);

	glEnd();

	//front
	glBegin(GL_POLYGON);
    glColor3ub(108, 188, 108);

	glVertex2f(14.64,-1.8);
	glVertex2f(14.59,-1.7);
	glVertex2f(15.39,-1.7);
	glVertex2f(15.36,-1.8);

	glEnd();

	//back1
	glBegin(GL_POLYGON);
    glColor3ub(118, 186, 118);

	glVertex2f(14.59,-2.7);
	glVertex2f(14.64,-2.6);
	glVertex2f(15.36,-2.6);
	glVertex2f(15.40,-2.7);

	glEnd();

	//middle_up
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(14.64,-2.6);
	glVertex2f(14.64,-1.8);
	glVertex2f(15.36,-1.8);
	glVertex2f(15.36,-2.6);

	glEnd();

	//sixton_out
	glBegin(GL_POLYGON);
    glColor3ub(63, 156, 63);

	glVertex2f(14.88,-2.3);
	glVertex2f(14.59,-2.1);
	glVertex2f(14.87,-1.9);
	glVertex2f(15.12,-1.9);
	glVertex2f(15.40,-2.1);
	glVertex2f(15.13,-2.3);

	glEnd();

	//sixton_in
	glBegin(GL_POLYGON);
    glColor3ub(75, 175, 75 );

	glVertex2f(14.88,-2.2);
	glVertex2f(14.72,-2.1);
	glVertex2f(14.88,-1.96);
	glVertex2f(15.12,-1.96);
	glVertex2f(15.28,-2.1);
	glVertex2f(15.12,-2.2);

	glEnd();

	//sixton_box
	glBegin(GL_POLYGON);
    glColor3ub(9, 135, 9);

	glVertex2f(15,-2.2);
	glVertex2f(15,-2.08);
	glVertex2f(15.12,-2.08);
	glVertex2f(15.12,-2.2);

	glEnd();

	glLineWidth(1);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(15,-2.16);
	glVertex2f(15.12,-2.16);

	glVertex2f(15,-2.12);
	glVertex2f(15.12,-2.12);

	glEnd();

	//middleup_box_left_out
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(14.68,-2.6);
	glVertex2f(14.68,-2.4);
	glVertex2f(14.88,-2.4);
	glVertex2f(14.88,-2.6);

	glEnd();

	//middleup_box_left_in
	glBegin(GL_POLYGON);
    glColor3ub(129, 176, 129);

	glVertex2f(14.72,-2.56);
	glVertex2f(14.72,-2.44);
	glVertex2f(14.84,-2.44);
	glVertex2f(14.84,-2.56);

	glEnd();

	//middleup_box_right_out
	glBegin(GL_POLYGON);
    glColor3ub(36, 122, 36);

	glVertex2f(15.12,-2.6);
	glVertex2f(15.12,-2.4);
	glVertex2f(15.32,-2.4);
	glVertex2f(15.32,-2.6);

	glEnd();

	//middleup_box_right_in
	glBegin(GL_POLYGON);
    glColor3ub(129, 176, 129);

	glVertex2f(15.16,-2.56);
	glVertex2f(15.16,-2.44);
	glVertex2f(15.28,-2.44);
	glVertex2f(15.28,-2.56);

	glEnd();

	//front_bullet
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(14.96,-1.76);
	glVertex2f(14.96,-1.24);
	glVertex2f(15.04,-1.24);
	glVertex2f(15.04,-1.76);

	glEnd();

	//broader_left_cylinder
	glBegin(GL_POLYGON);
    glColor3ub(159, 186, 159);

	glVertex2f(14.48,-2.64);
	glVertex2f(14.48,-2.44);
	glVertex2f(14.6,-2.44);
	glVertex2f(14.6,-2.64);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(117, 147, 117);

	glVertex2f(14.48,-2.6);
	glVertex2f(14.6,-2.6);

	glVertex2f(14.48,-2.56);
	glVertex2f(14.6,-2.56);

	glVertex2f(14.48,-2.52);
	glVertex2f(14.6,-2.52);

	glVertex2f(14.48,-2.48);
	glVertex2f(14.6,-2.48);

	glEnd();

	//broader_right_cylinder_up
	glBegin(GL_POLYGON);
    glColor3ub(159, 186, 159);

	glVertex2f(15.4,-2.36);
	glVertex2f(15.4,-2.16);
	glVertex2f(15.51,-2.16);
	glVertex2f(15.51,-2.36);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(117, 147, 117);

	glVertex2f(15.4,-2.32);
	glVertex2f(15.51,-2.32);

	glVertex2f(15.4,-2.28);
	glVertex2f(15.51,-2.28);

	glVertex2f(15.4,-2.24);
	glVertex2f(15.51,-2.24);

	glVertex2f(15.4,-2.2);
	glVertex2f(15.51,-2.2);

	glEnd();

	//broader_right_cylinder_down
	glBegin(GL_POLYGON);
    glColor3ub(159, 186, 159);

	glVertex2f(15.4,-2.64);
	glVertex2f(15.4,-2.44);
	glVertex2f(15.51,-2.44);
	glVertex2f(15.51,-2.64);

	glEnd();

	glLineWidth(2);
	glBegin(GL_LINES);
    glColor3ub(117, 147, 117);

	glVertex2f(15.4,-2.6);
	glVertex2f(15.51,-2.6);

	glVertex2f(15.4,-2.56);
	glVertex2f(15.51,-2.56);

	glVertex2f(15.4,-2.52);
	glVertex2f(15.51,-2.52);

	glVertex2f(15.4,-2.48);
	glVertex2f(15.51,-2.48);

	glEnd();
}

void misael2_s()
{
    glColor3d(0, 0, 1);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(4,0,0);
    glTranslatef(_move1, 0.0f, 0.0f);

    //wheel_up_left
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(17.6,-1.51);
	glVertex2f(17.6,-1.44);
	glVertex2f(18,-1.44);
	glVertex2f(18,-1.51);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(17.6,-1.51);
	glVertex2f(17.7,-1.46);

	glVertex2f(17.7,-1.51);
	glVertex2f(17.8,-1.46);

	glVertex2f(17.8,-1.51);
	glVertex2f(17.9,-1.46);

	glVertex2f(17.9,-1.51);
	glVertex2f(18,-1.46);

	glEnd();

	//wheel_up_middle
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(18.1,-1.51);
	glVertex2f(18.1,-1.44);
	glVertex2f(18.5,-1.44);
	glVertex2f(18.5,-1.51);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(18.1,-1.51);
	glVertex2f(18.2,-1.46);

	glVertex2f(18.2,-1.51);
	glVertex2f(18.3,-1.46);

	glVertex2f(18.3,-1.51);
	glVertex2f(18.4,-1.46);

	glVertex2f(18.4,-1.51);
	glVertex2f(18.5,-1.46);

	glEnd();

	//wheel_up_right
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(18.6,-1.51);
	glVertex2f(18.6,-1.44);
	glVertex2f(19,-1.44);
	glVertex2f(19,-1.51);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(18.6,-1.51);
	glVertex2f(18.7,-1.46);

	glVertex2f(18.7,-1.51);
	glVertex2f(18.8,-1.46);

	glVertex2f(18.8,-1.51);
	glVertex2f(18.9,-1.46);

	glVertex2f(18.9,-1.51);
	glVertex2f(19,-1.46);

	glEnd();

	//wheel_down_left
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(17.6,-2.56);
	glVertex2f(17.6,-2.48);
	glVertex2f(18,-2.48);
	glVertex2f(18,-2.56);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(17.6,-2.56);
	glVertex2f(17.7,-2.48);

	glVertex2f(17.7,-2.56);
	glVertex2f(17.8,-2.48);

	glVertex2f(17.8,-2.56);
	glVertex2f(17.9,-2.48);

	glVertex2f(17.9,-2.56);
	glVertex2f(18,-2.48);

	glEnd();

	//wheel_down_middle
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(18.1,-2.56);
	glVertex2f(18.1,-2.48);
	glVertex2f(18.5,-2.48);
	glVertex2f(18.5,-2.56);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(18.1,-2.56);
	glVertex2f(18.2,-2.48);

	glVertex2f(18.2,-2.56);
	glVertex2f(18.3,-2.48);

	glVertex2f(18.3,-2.56);
	glVertex2f(18.4,-2.48);

	glVertex2f(18.4,-2.56);
	glVertex2f(18.5,-2.48);

	glEnd();

	//wheel_down_right
	glBegin(GL_POLYGON);
    glColor3ub(69, 88, 69);

	glVertex2f(18.6,-2.56);
	glVertex2f(18.6,-2.48);
	glVertex2f(19,-2.48);
	glVertex2f(19,-2.56);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(173, 194, 173);

	glVertex2f(18.6,-2.56);
	glVertex2f(18.7,-2.48);

	glVertex2f(18.7,-2.56);
	glVertex2f(18.8,-2.48);

	glVertex2f(18.8,-2.56);
	glVertex2f(18.9,-2.48);

	glVertex2f(18.9,-2.56);
	glVertex2f(19,-2.48);

	glEnd();

	//border_out
	glBegin(GL_POLYGON);
    glColor3ub(100, 178, 100);

	glVertex2f(17.56,-2.5);
	glVertex2f(17,-2.2);
	glVertex2f(17,-1.8);
	glVertex2f(17.6,-1.5);
	glVertex2f(19,-1.51);
	glVertex2f(19.3,-1.7);
	glVertex2f(19.3,-2.3);
	glVertex2f(19,-2.5);

	glEnd();

	//border_in
	glBegin(GL_POLYGON);
    glColor3ub(79, 173, 79);

	glVertex2f(17.6,-2.4);
	glVertex2f(17.3,-2.2);
	glVertex2f(17.3,-1.8);
	glVertex2f(17.6,-1.6);
	glVertex2f(18.9,-1.6);
	glVertex2f(19.1,-1.8);
	glVertex2f(19.1,-2.2);
	glVertex2f(18.9,-2.4);

	glEnd();

	//front
	glBegin(GL_POLYGON);
    glColor3ub(108, 188, 108);

	glVertex2f(17,-2.2);
	glVertex2f(17,-1.8);
	glVertex2f(17.3,-1.8);
	glVertex2f(17.3,-2.2);

	glEnd();

	//back_box_up
	glBegin(GL_POLYGON);
    glColor3ub(15, 108, 15);

	glVertex2f(19.1,-1.9);
	glVertex2f(19.1,-1.8);
	glVertex2f(19.3,-1.8);
	glVertex2f(19.3,-1.9);

	glEnd();

	//back_box_down
	glBegin(GL_POLYGON);
    glColor3ub(15, 108, 15);

	glVertex2f(19.1,-2.2);
	glVertex2f(19.1,-2.1);
	glVertex2f(19.3,-2.1);
	glVertex2f(19.3,-2.2);

	glEnd();

	//body_box_up_left
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(18.1,-1.9);
	glVertex2f(18.1,-1.7);
	glVertex2f(18.3,-1.7);
	glVertex2f(18.3,-1.9);

	glEnd();

	//body_box_up_middle
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(18.4,-1.9);
	glVertex2f(18.4,-1.7);
	glVertex2f(18.6,-1.7);
	glVertex2f(18.6,-1.9);

	glEnd();

	//body_box_up_right
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(18.7,-1.9);
	glVertex2f(18.7,-1.7);
	glVertex2f(18.9,-1.7);
	glVertex2f(18.9,-1.9);

	glEnd();

	//body_box_down_left
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(18.1,-2.3);
	glVertex2f(18.1,-2.1);
	glVertex2f(18.3,-2.1);
	glVertex2f(18.3,-2.3);

	glEnd();

	//body_box_down_middle
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(18.4,-2.3);
	glVertex2f(18.4,-2.1);
	glVertex2f(18.6,-2.1);
	glVertex2f(18.6,-2.3);

	glEnd();

	//body_box_up_right
	glBegin(GL_POLYGON);
    glColor3ub(126, 203, 126);

	glVertex2f(18.7,-2.3);
	glVertex2f(18.7,-2.1);
	glVertex2f(18.9,-2.1);
	glVertex2f(18.9,-2.3);

	glEnd();

	//body_box_up_corner_right
	glBegin(GL_POLYGON);
    glColor3ub(67, 132, 67);

	glVertex2f(18.95,-1.9);
	glVertex2f(18.95,-1.8);
	glVertex2f(19.05,-1.8);
	glVertex2f(19.05,-1.9);

	glEnd();

	//body_box_down_corner_left
	glBegin(GL_POLYGON);
    glColor3ub(67, 132, 67);

	glVertex2f(17.9,-2.3);
	glVertex2f(17.9,-2.2);
	glVertex2f(18,-2.2);
	glVertex2f(18,-2.3);

	glEnd();

	//sixton_out
	glBegin(GL_POLYGON);
    glColor3ub(63, 156, 63);

	glVertex2f(17.7,-2.3);
	glVertex2f(17.4,-2.1);
	glVertex2f(17.4,-1.9);
	glVertex2f(17.7,-1.7);
	glVertex2f(18.05,-1.9);
	glVertex2f(18.05,-2.1);

	glEnd();

	//sixton_in
	glBegin(GL_POLYGON);
    glColor3ub(75, 175, 75 );

	glVertex2f(17.7,-2.2);
	glVertex2f(17.5,-2.1);
	glVertex2f(17.5,-1.9);
	glVertex2f(17.7,-1.8);
	glVertex2f(17.96,-1.9);
	glVertex2f(17.96,-2.1);

	glEnd();

	//sixton_box_up
	glBegin(GL_POLYGON);
    glColor3ub(9, 135, 9);

	glVertex2f(17.7,-1.95);
	glVertex2f(17.7,-1.85);
	glVertex2f(17.75,-1.85);
	glVertex2f(17.75,-1.95);

	glEnd();

	//sixton_box_down
	glBegin(GL_POLYGON);
    glColor3ub(9, 135, 9);

	glVertex2f(17.55,-2.1);
	glVertex2f(17.55,-2);
	glVertex2f(17.6,-2);
	glVertex2f(17.6,-2.1);

	glEnd();


	//bounder_up_box1
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(17.75,-1.6);
	glVertex2f(17.75,-1.55);
	glVertex2f(17.9,-1.55);
	glVertex2f(17.9,-1.6);

	glEnd();

	//bounder_up_box2
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(18.05,-1.6);
	glVertex2f(18.05,-1.55);
	glVertex2f(18.2,-1.55);
	glVertex2f(18.2,-1.6);

	glEnd();

	//bounder_up_box3
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(18.35,-1.6);
	glVertex2f(18.35,-1.55);
	glVertex2f(18.5,-1.55);
	glVertex2f(18.5,-1.6);

	glEnd();

	//bounder_up_box4
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(18.65,-1.6);
	glVertex2f(18.65,-1.55);
	glVertex2f(18.8,-1.55);
	glVertex2f(18.8,-1.6);

	glEnd();

	//bounder_down_box1
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(17.75,-2.45);
	glVertex2f(17.75,-2.4);
	glVertex2f(17.9,-2.4);
	glVertex2f(17.9,-2.45);

	glEnd();

	//bounder_down_box2
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(18.05,-2.45);
	glVertex2f(18.05,-2.4);
	glVertex2f(18.2,-2.4);
	glVertex2f(18.2,-2.45);

	glEnd();

	//bounder_down_box3
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(18.35,-2.45);
	glVertex2f(18.35,-2.4);
	glVertex2f(18.5,-2.4);
	glVertex2f(18.5,-2.45);

	glEnd();

	//bounder_down_box4
	glBegin(GL_POLYGON);
    glColor3ub(13, 86, 13);

	glVertex2f(18.65,-2.45);
	glVertex2f(18.65,-2.4);
	glVertex2f(18.8,-2.4);
	glVertex2f(18.8,-2.45);

	glEnd();

	//bullet_up
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(16.7,-1.98);
	glVertex2f(16.7,-1.92);
	glVertex2f(17.5,-1.92);
	glVertex2f(17.5,-1.98);

	glEnd();

	//bullet_down
	glBegin(GL_POLYGON);
    glColor3ub(79, 104, 79);

	glVertex2f(17.1,-2.1);
	glVertex2f(17.1,-2.02);
	glVertex2f(17.5,-2.02);
	glVertex2f(17.5,-2.1);

	glEnd();

	glPopMatrix();
}

void rocketcar_s()
{
    //glClear(GL_COLOR_BUFFER_BIT);
    glColor3d(0, 0, 1);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0,-4,0);
    glTranslatef(0.0f,_move2, 0.0f);

    //glRotatef(_angle1, 0.0f,-5.0f,1.0f);


    //front
	glBegin(GL_POLYGON);
    glColor3ub(36, 67, 36);

	glVertex2f(18.60,-6.4);
	glVertex2f(18.64,-6.3);
	glVertex2f(19.44,-6.3);
	glVertex2f(19.48,-6.4);

	glEnd();

	//front_light
	glBegin(GL_POLYGON);
    glColor3ub(77, 142, 77);

	glVertex2f(18.5,-6.6);
	glVertex2f(18.5,-6.4);
	glVertex2f(19.6,-6.4);
	glVertex2f(19.6,-6.6);

	glEnd();

	//front_light_left
	glBegin(GL_POLYGON);
    glColor3ub(189, 212, 189);

	glVertex2f(18.52,-6.56);
	glVertex2f(18.56,-6.44);
	glVertex2f(18.72,-6.44);
	glVertex2f(18.68,-6.56);

	glEnd();

	//front_box_left
	glBegin(GL_POLYGON);
    glColor3ub( 10, 48, 10);

	glVertex2f(18.83,-6.5);
	glVertex2f(18.8,-6.45);
	glVertex2f(19,-6.45);
	glVertex2f(19,-6.5);

	glEnd();

	//front_light_right
	glBegin(GL_POLYGON);
    glColor3ub(189, 212, 189);

	glVertex2f(19.4,-6.56);
	glVertex2f(19.36,-6.44);
	glVertex2f(19.52,-6.44);
	glVertex2f(19.56,-6.56);

	glEnd();

	//front_box_right
	glBegin(GL_POLYGON);
    glColor3ub( 10, 48, 10);

	glVertex2f(19.1,-6.5);
	glVertex2f(19.1,-6.45);
	glVertex2f(19.3,-6.45);
	glVertex2f(19.27,-6.5);

	glEnd();

	//front_wheel_left
	glBegin(GL_POLYGON);
    glColor3ub(50, 48, 48);

	glVertex2f(18.48,-7.4);
	glVertex2f(18.48,-6.81);
	glVertex2f(18.52,-6.81);
	glVertex2f(18.52,-7.4);

	glEnd();

	//front_wheel_right
	glBegin(GL_POLYGON);
    glColor3ub(50, 48, 48);

	glVertex2f(19.56,-7.4);
	glVertex2f(19.56,-6.84);
	glVertex2f(19.6,-6.84);
	glVertex2f(19.6,-7.4);

	glEnd();

	//front_body
	glBegin(GL_POLYGON);
    glColor3ub(54, 158, 54);

	glVertex2f(18.52,-7.6);
	glVertex2f(18.52,-6.68);
	glVertex2f(19.56,-6.71);
	glVertex2f(19.56,-7.6);

	glEnd();

	//front_body_box
	glBegin(GL_POLYGON);
    glColor3ub(38, 113, 38);

	glVertex2f(18.8,-7.4);
	glVertex2f(18.8,-7.2);
	glVertex2f(19.3,-7.2);
	glVertex2f(19.3,-7.4);

	glEnd();

	//front_body_rocket_left_head
	glBegin(GL_TRIANGLES);
    glColor3ub(240, 57, 82);

	glVertex2f(18.6,-7.4);
	glVertex2f(18.7,-7.04);
	glVertex2f(18.8,-7.4);

	glEnd();

	//front_body_rocket_right_head
	glBegin(GL_TRIANGLES);
    glColor3ub(194, 59, 205);

	glVertex2f(19.3,-7.4);
	glVertex2f(19.4,-7.04);
	glVertex2f(19.5,-7.4);

	glEnd();

	//front_glass
	glBegin(GL_POLYGON);
    glColor3ub( 103, 128, 103);

	glVertex2f(18.6,-7);
	glVertex2f(18.5,-6.6);
	glVertex2f(19.6,-6.6);
	glVertex2f(19.5,-7);

	glEnd();

	//left_glass_up
	glBegin(GL_POLYGON);
    glColor3ub( 98, 132, 98 );

	glVertex2f(18.52,-7.2);
	glVertex2f(18.52,-6.68);
	glVertex2f(18.58,-6.92);
	glVertex2f(18.58,-7.2);

	glEnd();

	//right_glass_up
	glBegin(GL_POLYGON);
    glColor3ub( 98, 132, 98 );

	glVertex2f(19.5,-7.2);
	glVertex2f(19.49,-6.87);
	glVertex2f(19.56,-6.71);
	glVertex2f(19.56,-7.2);

	glEnd();

	//left_glass_down
	glBegin(GL_POLYGON);
    glColor3ub( 98, 132, 98 );

	glVertex2f(18.52,-7.5);
	glVertex2f(18.52,-7.3);
	glVertex2f(18.58,-7.3);
	glVertex2f(18.58,-7.5);

	glEnd();

	//right_glass_down
	glBegin(GL_POLYGON);
    glColor3ub( 98, 132, 98 );

	glVertex2f(19.5,-7.5);
	glVertex2f(19.5,-7.3);
	glVertex2f(19.56,-7.3);
	glVertex2f(19.56,-7.5);

	glEnd();

	//small_glass_left
	glBegin(GL_POLYGON);
    glColor3ub(86, 161, 86 );

	glVertex2f(18.4,-6.8);
	glVertex2f(18.4,-6.7);
	glVertex2f(18.52,-6.68);
	glVertex2f(18.52,-6.78);

	glEnd();

	//small_glass_right
	glBegin(GL_POLYGON);
    glColor3ub(86, 161, 86 );

	glVertex2f(19.56,-6.78);
	glVertex2f(19.57,-6.68);
	glVertex2f(19.68,-6.74);
	glVertex2f(19.68,-6.8);

	glEnd();

	//middle_body
	glBegin(GL_POLYGON);
    glColor3ub(54, 158, 54);

	glVertex2f(18.46,-8.5);
	glVertex2f(18.46,-7.7);
	glVertex2f(19.6,-7.7);
	glVertex2f(19.6,-8.5);

	glEnd();

	//middle_body_box_up_out
	glBegin(GL_POLYGON);
    glColor3ub(36, 117, 56);

	glVertex2f(18.9,-8);
	glVertex2f(18.9,-7.8);
	glVertex2f(19.2,-7.8);
	glVertex2f(19.2,-8);

	glEnd();

	//middle_body_box_up_in
	glBegin(GL_POLYGON);
    glColor3ub(48, 151, 73);

	glVertex2f(18.94,-7.96);
	glVertex2f(18.94,-7.84);
	glVertex2f(19.16,-7.84);
	glVertex2f(19.16,-7.96);

	glEnd();

	//middle_body_box_down_out
	glBegin(GL_POLYGON);
    glColor3ub(36, 117, 56);

	glVertex2f(18.9,-8.4);
	glVertex2f(18.9,-8.2);
	glVertex2f(19.2,-8.2);
	glVertex2f(19.2,-8.4);

	glEnd();

	//middle_body_box_down_in
	glBegin(GL_POLYGON);
    glColor3ub(48, 151, 73);

	glVertex2f(18.94,-8.36);
	glVertex2f(18.94,-8.24);
	glVertex2f(19.16,-8.24);
	glVertex2f(19.16,-8.36);

	glEnd();

	//back_body_front
	glBegin(GL_POLYGON);
    glColor3ub(54, 158, 54);

	glVertex2f(18.8,-8.8);
	glVertex2f(18.8,-8.5);
	glVertex2f(19.3,-8.5);
	glVertex2f(19.3,-8.8);

	glEnd();

	//back_body_Black
	glBegin(GL_POLYGON);
    glColor3ub(26, 29, 27);

	glVertex2f(18.8,-9);
	glVertex2f(18.8,-8.8);
	glVertex2f(19.3,-8.8);
	glVertex2f(19.3,-9);

	glEnd();

	//back_wheel_left
	glBegin(GL_POLYGON);
    glColor3ub(50, 48, 48);

	glVertex2f(18.5,-9.1);
	glVertex2f(18.5,-8.6);
	glVertex2f(18.6,-8.6);
	glVertex2f(18.6,-9.1);

	glEnd();

	//back_wheel_right
	glBegin(GL_POLYGON);
    glColor3ub(50, 48, 48);

	glVertex2f(19.5,-9.1);
	glVertex2f(19.5,-8.6);
	glVertex2f(19.6,-8.6);
	glVertex2f(19.6,-9.1);

	glEnd();

	//back_body_tri_back
	glBegin(GL_POLYGON);
    glColor3ub(54, 158, 54);

	glVertex2f(19,-9.48);
	glVertex2f(19,-9.2);
	glVertex2f(18.8,-9);
	glVertex2f(19.28,-9);
	glVertex2f(19.08,-9.2);
	glVertex2f(19.08,-9.48);

	glEnd();

	//back_body_tri_Black
	glBegin(GL_POLYGON);
    glColor3ub(26, 29, 27);

	glVertex2f(19,-9.52);
	glVertex2f(19,-9.48);
	glVertex2f(19.1,-9.48);
	glVertex2f(19.1,-9.52);

	glEnd();

	//rocket_left_back
	glBegin(GL_POLYGON);
    glColor3ub(35, 118, 55 );


	glVertex2f(18.4,-9.6);
	glVertex2f(18.4,-9.2);
	glVertex2f(18.6,-9);
	glVertex2f(18.8,-9);
	glVertex2f(19,-9.2);
	glVertex2f(19,-9.6);
	glVertex2f(18.8,-9.4);
	glVertex2f(18.6,-9.4);

	glEnd();

	//rocket_left_body
	glBegin(GL_POLYGON);
    glColor3ub(35, 118, 55 );

	glVertex2f(18.6,-9);
	glVertex2f(18.6,-7.4);
	glVertex2f(18.8,-7.4);
	glVertex2f(18.8,-9);


	glEnd();

	//rocket_left_Black
	glBegin(GL_POLYGON);
    glColor3ub(26, 29, 27);

	glVertex2f(18.48,-9.52);
	glVertex2f(18.52,-9.48);
	glVertex2f(18.88,-9.48);
	glVertex2f(18.92,-9.52);

	glEnd();

	//rocket_right_back
	glBegin(GL_POLYGON);
    glColor3ub(35, 118, 55 );

	glVertex2f(19.08,-9.6);
	glVertex2f(19.08,-9.2);
	glVertex2f(19.28,-9);
	glVertex2f(19.5,-9);
	glVertex2f(19.68,-9.2);
	glVertex2f(19.68,-9.6);
	glVertex2f(19.5,-9.4);
	glVertex2f(19.28,-9.4);

	glEnd();

	//rocket_right_body
	glBegin(GL_POLYGON);
    glColor3ub(35, 118, 55 );

	glVertex2f(19.28,-9);
	glVertex2f(19.28,-7.4);
	glVertex2f(19.5,-7.4);
	glVertex2f(19.5,-9);


	glEnd();

	//rocket_right_Black
	glBegin(GL_POLYGON);
    glColor3ub(26, 29, 27);

	glVertex2f(19.16,-9.52);
	glVertex2f(19.2,-9.48);
	glVertex2f(19.56,-9.48);
	glVertex2f(19.6,-9.52);

	glEnd();

	//rocket_left_box_up
	glBegin(GL_POLYGON);
    glColor3ub(209, 227, 213);

	glVertex2f(18.6,-7.9);
	glVertex2f(18.6,-7.8);
	glVertex2f(18.8,-7.8);
	glVertex2f(18.8,-7.9);

	glEnd();

	//rocket_left_box_down
	glBegin(GL_POLYGON);
    glColor3ub(209, 227, 213);

	glVertex2f(18.6,-8.1);
	glVertex2f(18.6,-8);
	glVertex2f(18.8,-8);
	glVertex2f(18.8,-8.1);

	glEnd();

	//rocket_right_box_up
	glBegin(GL_POLYGON);
    glColor3ub(209, 227, 213);

	glVertex2f(19.28,-7.9);
	glVertex2f(19.28,-7.8);
	glVertex2f(19.48,-7.8);
	glVertex2f(19.48,-7.9);

	glEnd();

	//rocket_right_box_down
	glBegin(GL_POLYGON);
    glColor3ub(209, 227, 213);

	glVertex2f(19.28,-8.1);
	glVertex2f(19.28,-8);
	glVertex2f(19.48,-8);
	glVertex2f(19.48,-8.1);

	glEnd();

	//middle_body_front
	glBegin(GL_POLYGON);
    glColor3ub(60, 178, 88 );

	glVertex2f(18.8,-7.75);
	glVertex2f(18.8,-7.6);
	glVertex2f(19.28,-7.6);
	glVertex2f(19.28,-7.75);

	glEnd();


	glPopMatrix();
}

void tent_s()
{
    //left
    glBegin(GL_POLYGON);
    glColor3ub(83, 142, 24 );

	glVertex2f(11.5,-8.5);
	glVertex2f(12,-8);
	glVertex2f(13,-9);
	glVertex2f(12.5,-9.5);

	glEnd();

	glLineWidth(1.7);
	glBegin(GL_LINES);
    glColor3ub(76, 95, 58);

	glVertex2f(11.2,-8.5);
	glVertex2f(12,-8.5);
	glVertex2f(12,-8.5);
	glVertex2f(12,-7.7);
	glVertex2f(12,-8.5);
	glVertex2f(12.5,-9);
	glVertex2f(12.5,-9);
	glVertex2f(12.5,-9.8);
	glVertex2f(12.5,-9);
	glVertex2f(13.3,-9);

	glEnd();

	//right
    glBegin(GL_POLYGON);
    glColor3ub(113, 179, 48);

	glVertex2f(15.5,-9);
	glVertex2f(16.5,-8);
	glVertex2f(17,-8.5);
	glVertex2f(16,-9.5);

	glEnd();

	glLineWidth(1.5);
	glBegin(GL_LINES);
    glColor3ub(118, 137, 100 );

	glVertex2f(15.2,-9);
	glVertex2f(16,-9);
	glVertex2f(16,-9);
	glVertex2f(16.5,-8.5);
	glVertex2f(16.5,-8.5);
	glVertex2f(16.5,-7.7);
	glVertex2f(16.5,-8.5);
	glVertex2f(17.3,-8.5);
	glVertex2f(16,-9);
	glVertex2f(16,-9.8);

	glEnd();

}

void rstkeyboard_s(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 'D' :
        case 'd' :
            day=true;
            break;
        case 'N' :
        case 'n' :
            day=false;
            break;
            case 'R' :
        case 'r' :
            rainy=true;
            break;
            case 'S' :
        case 's' :
            rainy=false;
            break;


    }
    glutPostRedisplay();
}


void drawScene_s()
{
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	broader_s();
    train_platform1_s();
    rail_line1_s();
    rail_line2_s();
    rail_line3_s();
    tree_s();
    rail_line4_s();
    train_platform2_s();
    road_s();
    tank3_s();
    misael2_s();
    rocketcar_s();
    tent_s();
    glLineWidth(2);
	rain_s(10);
    glFlush();
    glutSwapBuffers();

}

void update_s(int value)
{
    train1 += 0.02;
    if (train1 >8)
    {
        train1 = -8;
    }
    glutPostRedisplay();
    glutTimerFunc(35, update_s, 0);
}


void update1_s(int value)
{
    train2 -= 0.02;
    if (train2 <-8)
    {
        train2 = 6;
    }

    glutPostRedisplay();
    glutTimerFunc(57, update1_s, 0);
}

void update2_s(int value)
{
    _move2 += rocket;
    if (_move2 >6.5)
    {
        misaelstatus=1;
        rocket = 0;
    }
    glutPostRedisplay();
    glutTimerFunc(75, update2_s, 0);
}

void update3_s(int value)
{
    if(misaelstatus==1)
    {
    _move1 -= misael;
    if (_move1 <-4)
    {

        misael = 0;
    }

    }
    glutPostRedisplay();
    glutTimerFunc(37, update3_s, 0);
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutCreateWindow("OpenGL Scenery");
	glutInitWindowSize(800,600);
	glutDisplayFunc(drawScene_s);
	glutTimerFunc(10,rain_s,0);
	gluOrtho2D(1,20,-10,-1);
	glutKeyboardFunc(rstkeyboard_s);
	glutTimerFunc(20, update_s, 0); // Add a timer
	glutTimerFunc(15, update1_s, 0); // Add a timer
	glutTimerFunc(10, update2_s, 0); //Add a timer
	glutTimerFunc(5, update3_s, 0); //Add a timer
	glutMainLoop();
	return 0;
}
