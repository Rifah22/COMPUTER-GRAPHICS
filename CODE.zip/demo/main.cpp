#include<iostream>
#include<GL/gl.h>
#include<GL/glut.h>
#include<math.h>

using namespace std;

float _move = 0.0f;
float _move1 = 0.0f;

void sky()
{
    glColor3ub(67, 223, 241);
    glBegin(GL_POLYGON);

    glVertex2f(-4,0.38);
    glVertex2f(-4,2);
    glVertex2f(4,2);
    glVertex2f(4,0.38);

    glEnd();

    glColor3ub(59, 216, 234);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-1.2);
    glVertex2f(-4,0.38);
    glVertex2f(4,0.38);
    glVertex2f(4,-1.42);

    glEnd();
}

void river()
{

    glColor3ub(37, 180, 197);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-3);
    glVertex2f(-4,-1.2);
    glVertex2f(4,-1.42);
    glVertex2f(4,-3);

    glEnd();
}

void grass()
{

    glColor3ub(35, 168, 64);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-3);
    glVertex2f(-3.6,-2.5);
    glVertex2f(-2.8,-2.6);
    glVertex2f(-2,-3);

    glEnd();

    glColor3ub(28, 178, 60);
    glBegin(GL_POLYGON);

    glVertex2f(-2,-3);
    glVertex2f(-1,-2.6);
    glVertex2f(-0.3,-2.5);
    glVertex2f(-0.1,-2.8);
    glVertex2f(0.4,-2.6);
    glVertex2f(1.3,-2.6);
    glVertex2f(1.5,-3);

    glEnd();

    glColor3ub(53, 175, 78);
    glBegin(GL_POLYGON);

    glVertex2f(2,-3);
    glVertex2f(2.6,-2.7);
    glVertex2f(3.4,-2.6);
    glVertex2f(4,-3);

    glEnd();
}

void hill()
{
    //left
    glColor3ub(142, 136, 136);
    glBegin(GL_POLYGON);

    glVertex2f(-4,-1.2);
    glVertex2f(-4,0.38);
    glVertex2f(-3.4,0);
    glVertex2f(-2.7,-0.3);
    glVertex2f(-2.1,-0.7);
    glVertex2f(-2.7,-1.3);

    glEnd();

    //right

    glColor3ub(153, 143, 143);
    glBegin(GL_POLYGON);

    glVertex2f(4,-1.42);
    glVertex2f(2.7,-1.24);
    glVertex2f(1.8,-1.1);
    glVertex2f(1,-0.4);
    glVertex2f(1.9,-0.2);
    glVertex2f(2.5,-0.6);
    glVertex2f(3,-1);

    glEnd();

    //middle end
    glColor3ub( 112, 107, 107);
    glBegin(GL_POLYGON);

    glVertex2f(-3.02,-1.4);
    glVertex2f(-2.7,-1.2);
    glVertex2f(2.8,-1.2);
    glVertex2f(4,-1.42);
    glVertex2f(2.02,-1.4);
    glVertex2f(0.98,-1.34);
    glVertex2f(-0.1,-1.4);
    glVertex2f(-0.69,-1.35);
    glVertex2f(-1.33,-1.4);
    glVertex2f(-1.99,-1.36);

    glEnd();

    //middle first

    glColor3ub(151, 147, 147);
    glBegin(GL_POLYGON);

    glVertex2f(-1.2,0);
    glVertex2f(-0.6,0.5);
    glVertex2f(0.4,0.15);
    glVertex2f(0.568,0);

    glEnd();

    //middle

    glColor3ub(153, 150, 150);
    glBegin(GL_POLYGON);

    glVertex2f(-2.7,-1.2);
    glVertex2f(-1.2,0);
    glVertex2f(0.568,0);
    glVertex2f(1,-0.4);
    glVertex2f(1.8,-1.1);
    glVertex2f(2.8,-1.2);

    glEnd();
}

void volcano()
{

    //middle left

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glColor3ub(222, 69, 16);
    glBegin(GL_POLYGON);

    glVertex2f(-2.7377083545206, -1.392485265419);
    glVertex2f(-0.6, 0.5);
    glVertex2f(-0.5326387585336, 0.3894963601749);
    glVertex2f(-1.715261562394, -1.3811474540941);

    glEnd();
    glPopMatrix();

    //middle middle
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0.0f, _move1, 0.0f);
    glColor3ub(255, 69, 0);
    glBegin(GL_POLYGON);

    glVertex2f(-1.2, -1.4);
    glVertex2f(-0.4752453676327, 0.3446584003881);
    glVertex2f(-0.284844,0.2838419);
    glVertex2f(-0.3584414678922, -1.3864231672943);

    glEnd();
    glPopMatrix();

    //middle right

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glColor3ub(222, 69, 16);
    glBegin(GL_POLYGON);

    glVertex2f(0, -1.4);
    glVertex2f(-0.164915,0.29960888);
    glVertex2f(0.06517765,0.22404770740);
    glVertex2f(0.8352171673536, -1.3496299175289);

    glEnd();
    glPopMatrix();
}

void gas()
{
    //1
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
      glColor3ub(181, 175, 175 );

      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.4;
      float x = r * cos(A);
      float y = r * sin(A);

      glVertex2f(x-0.3,y+0.6 );
    }
    glEnd();

    //2
    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
      glColor3ub(181, 175, 175 );

      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.4;
      float x = r * cos(A);
      float y = r * sin(A);

      glVertex2f(x+0.3,y+0.5 );
    }
    glEnd();

    //3
    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
      glColor3ub(185, 174, 174);

      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.4;
      float x = r * cos(A);
      float y = r * sin(A);

      glVertex2f(x,y+1.2 );
    }
    glEnd();

    //4

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0,-_move1,0);

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
      glColor3ub(191, 184, 184);

      float pi=3.1416;
      float A=(i*2*pi)/200;
      float r=0.3;
      float x = r * cos(A);
      float y = r * sin(A);

      glVertex2f(x,y+1.8 );
    }
    glEnd();
    glPopMatrix();
}

void update(int value)
{
    _move +=0.2;
    if(_move > 2)
    {
        _move1 -= 0.02;
        if(_move1<-2)
        {
            _move1=0.5;
        }
    }
    glutPostRedisplay();
    glutTimerFunc(200, update, 0);
}

void display()
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	sky();
	river();
	gas();
	hill();
    volcano();
    grass();

    glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Setup Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	gluOrtho2D(-4,4,-3,2);
    glutTimerFunc(20, update, 0);
	glutMainLoop();

	return 0;
}


