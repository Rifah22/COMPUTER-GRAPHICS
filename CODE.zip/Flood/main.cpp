#include <windows.h>
#include <GL/glut.h>
#include <math.h>

bool rainday = true;
float _rain = 0.0f;
float waterLevel = -2.00f;

void rain(int value);

void riverwater()
{
    glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

    glVertex2f(-10, waterLevel);
    glVertex2f(-10,-5);
	glVertex2f(10,-5);
    glVertex2f(10, waterLevel);
    glEnd();
}

void sky()
{
    //sky
    glBegin(GL_POLYGON);
    glColor3ub(90, 225, 254);

	glVertex2f(-10,1);
	glVertex2f(-10,5);
	glVertex2f(10,5);
	glVertex2f(10,1);

	glEnd();
}

void farvillage()
{
	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-9,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2.4-1.4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-8.1,y+1.4);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-6.7,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2.7-1.7;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-5,y+1.7);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.8-2.2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-3,y+2.2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.9-3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1,y+3);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1,y+2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.4-2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+2.6,y+2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.7-2;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+6.5,y+2);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3-1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+4.9,y+1);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.1-1.6;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+8.9,y+1.6);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=2-1.1;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+6.9,y+1.1);
    }
    glEnd();

     glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(93, 175, 20);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.1-1.7;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-0.5,y+2);
    }
    glEnd();
}

void fronthome()
{
    //fronthome
	glBegin(GL_POLYGON);
    glColor3ub(232, 191, 104);

	glVertex2f(-10,-3);
	glVertex2f(-10,1);
	glVertex2f(10,1);
	glVertex2f(10,-3);

	glEnd();

    //tree
	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.4,1);
	glVertex2f(-0.4,2);
	glVertex2f(0,2);
	glVertex2f(0,0.5);

	glEnd();

	//home2

    glBegin(GL_POLYGON);
    glColor3ub(191, 134, 67);

	glVertex2f(1.2,0);
	glVertex2f(1.2,1);
	glVertex2f(3.2,1);
	glVertex2f(3.2,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(151, 130, 57);

	glVertex2f(1,1);
	glVertex2f(1.4,2);
	glVertex2f(3,2);
	glVertex2f(3.4,1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(128, 79, 19);

	glVertex2f(1.8,0);
	glVertex2f(1.8,0.8);
	glVertex2f(2.6,0.8);
	glVertex2f(2.6,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(104, 59, 5);

	glVertex2f(1.3,-0.2);
	glVertex2f(1.3,0);
	glVertex2f(3.2,0);
	glVertex2f(3.2,-0.2);

	glEnd();

	//paddy
	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(232, 174, 19);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1-0;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0.4,y+0);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(232, 174, 19);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1-0.4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0.9,y-0.4);
    }
    glEnd();

     glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(34, 118, 12);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.2-3.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-0.3,y+3.3);
    }
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.2,-1);
	glVertex2f(-0.2,-0.8);
	glVertex2f(1.5,-0.8);
	glVertex2f(1.5,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(0.3,1);
	glVertex2f(0.4,1.4);
	glVertex2f(0.5,1);

	glEnd();

    //home1
    glBegin(GL_POLYGON);
    glColor3ub(148, 131, 101);

	glVertex2f(-5,0.9);
	glVertex2f(-4,2);
	glVertex2f(-3.7,1.7);
	glVertex2f(-4.5,0.9);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(218, 138, 15);

	glVertex2f(-4.5,-0.2);
	glVertex2f(-4.5,0.9);
	glVertex2f(-3.7,1.7);
	glVertex2f(-3,0.7);
	glVertex2f(-3,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(228, 150, 30);

	glVertex2f(-3,-1);
	glVertex2f(-3,0.7);
	glVertex2f(-0.2,0.7);
	glVertex2f(-0.2,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(145, 130, 104 );

	glVertex2f(-2.9,0.5);
	glVertex2f(-4,2);
	glVertex2f(-1,2);
	glVertex2f(0,0.5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(236, 200, 17);

	glVertex2f(-4,0.2);
	glVertex2f(-4,0.7);
	glVertex2f(-3.5,0.5);
	glVertex2f(-3.5,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(180, 130, 8);

	glVertex2f(-2,-1);
	glVertex2f(-2,0);
	glVertex2f(-1.2,0);
	glVertex2f(-1.2,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(188, 120, 16);

	glVertex2f(-4.7,-0.3);
	glVertex2f(-4.5,-0.2);
	glVertex2f(-3,-1);
	glVertex2f(-3,-1.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(188, 120, 16);

	glVertex2f(-3,-1.2);
	glVertex2f(-3,-1);
	glVertex2f(-0.2,-1);
	glVertex2f(-0,-1.2);

	glEnd();

	//tree

	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.4,2);
	glVertex2f(-0.7,2.5);
	glVertex2f(-0.5,2.5);
	glVertex2f(-0.2,2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(138, 87, 8 );

	glVertex2f(-0.2,2);
	glVertex2f(0.2,2.9);
	glVertex2f(0.5,2.9);
	glVertex2f(0,2);

	glEnd();
}
void tree()
{
    //tree
    glBegin(GL_POLYGON);
    for(int i=0;i<200;i++)
    {
        glColor3ub(25, 146, 8);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.2-3.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-0.3,y+3.3);
    }
    glEnd();

	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(25, 146, 8);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.3-3.5;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-2.3,y+3.5);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(25, 146, 8);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5.3-4.3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0,y+4.3);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(28, 156, 10);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5-4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1.4,y+4);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(28, 156, 10);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=5-4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1.5,y+4);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 143, 14);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=4.5-3.5;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+1,y+3.5);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(29, 143, 14);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=3.8-3;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x-1,y+3);
    }
    glEnd();

}

void Rain(int value) {
    if (rainday)
        {
        _rain += 0.01f;

        float x = (rand() % 1500 - 900) / 60.0f;
        float y = (rand() % 1900 - 710) / 100.0f;

        glColor3f(1,1,1);
        glBegin(GL_LINES);
        glVertex2f(x, y);
        glVertex2f(x+0.5, y +0.5);
        glEnd();

        glutPostRedisplay();
        glutTimerFunc(20, Rain, 0);
        glFlush();

    }
}

void flood(int value) {
    if (waterLevel < 0.0f)
    {
        waterLevel += 0.01f; // Increase water level faster
        glutPostRedisplay();
        glutTimerFunc(20, flood, 0);
    }
}
void display()
{
    glClearColor(1, 1, 1, 1); // Set background color to black and opaque
    glClear(GL_COLOR_BUFFER_BIT);
    sky();
    farvillage();
    fronthome();
    riverwater();
    tree();

    if (waterLevel > 0.0f)
    {
        glBegin(GL_POLYGON);
        glColor3ub(0, 128, 255); // Water color

        glVertex2f(-10,-3);
	    glVertex2f(-10,1);
	    glVertex2f(10,1);
	    glVertex2f(10,-3);

	    glEnd();

	    //home2

    glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(1.2,0);
	glVertex2f(1.2,1);
	glVertex2f(3.2,1);
	glVertex2f(3.2,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(1,1);
	glVertex2f(1.4,2);
	glVertex2f(3,2);
	glVertex2f(3.4,1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(1.8,0);
	glVertex2f(1.8,0.8);
	glVertex2f(2.6,0.8);
	glVertex2f(2.6,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(1.3,-0.2);
	glVertex2f(1.3,0);
	glVertex2f(3.2,0);
	glVertex2f(3.2,-0.2);

	glEnd();

	//paddy
	glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(0, 128, 255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1-0;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0.4,y+0);
    }
    glEnd();

    glBegin(GL_POLYGON);

    for(int i=0;i<200;i++)
    {
        glColor3ub(0, 128, 255);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=1-0.4;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x+0.9,y-0.4);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255 );

	glVertex2f(-0.2,-1);
	glVertex2f(-0.2,-0.8);
	glVertex2f(1.5,-0.8);
	glVertex2f(1.5,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255 );

	glVertex2f(0.3,1);
	glVertex2f(0.4,1.4);
	glVertex2f(0.5,1);

	glEnd();

    //home1
    glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-5,0.9);
	glVertex2f(-4,2);
	glVertex2f(-3.7,1.7);
	glVertex2f(-4.5,0.9);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-4.5,-0.2);
	glVertex2f(-4.5,0.9);
	glVertex2f(-3.7,1.7);
	glVertex2f(-3,0.7);
	glVertex2f(-3,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-3,-1);
	glVertex2f(-3,0.7);
	glVertex2f(-0.2,0.7);
	glVertex2f(-0.2,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255 );

	glVertex2f(-2.9,0.5);
	glVertex2f(-4,2);
	glVertex2f(-1,2);
	glVertex2f(0,0.5);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-4,0.2);
	glVertex2f(-4,0.7);
	glVertex2f(-3.5,0.5);
	glVertex2f(-3.5,0);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-2,-1);
	glVertex2f(-2,0);
	glVertex2f(-1.2,0);
	glVertex2f(-1.2,-1);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-4.7,-0.3);
	glVertex2f(-4.5,-0.2);
	glVertex2f(-3,-1);
	glVertex2f(-3,-1.2);

	glEnd();

	glBegin(GL_POLYGON);
    glColor3ub(0, 128, 255);

	glVertex2f(-3,-1.2);
	glVertex2f(-3,-1);
	glVertex2f(-0.2,-1);
	glVertex2f(-0,-1.2);

	glEnd();

    }
    else
    {
        tree();
    }



    glLineWidth(1);
    Rain(5);
    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutCreateWindow("Rainy Flood");
    glutInitWindowSize(320, 320);
    glutDisplayFunc(display);
    glutTimerFunc(20, Rain, 0);
    glutTimerFunc(2000, flood, 0);
    gluOrtho2D(-10, 10, -5, 5);
    glutMainLoop();
    return 0;
}
