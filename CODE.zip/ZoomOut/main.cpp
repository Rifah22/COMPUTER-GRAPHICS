#include <windows.h>
#include <GL/glut.h>
#include <math.h>

float _move=1;
int zoom=2;
void StreetLamp()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(_move,_move,0);
    //3
    glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(164,45.9);
	glVertex2f(164,43.9);
    glVertex2f(177.8,43.9);
	glVertex2f(177.8,45.9);

	glEnd();

    glBegin(GL_POLYGON);
	glColor3f(1,1,0);

	glVertex2f(166,32);
	glVertex2f(164,43.9);
    glVertex2f(177.8,43.9);
	glVertex2f(176,32);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(166,30);
	glVertex2f(166,32);
	glVertex2f(176,32);
	glVertex2f(176,30);

	glEnd();


	//1
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(121.9,45.9);
	glVertex2f(121.9,43.9);
    glVertex2f(136.4,43.9);
	glVertex2f(136.4,45.9);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1,1,0);

	glVertex2f(124,32);
	glVertex2f(121.9,43.9);
    glVertex2f(136.4,43.9);
	glVertex2f(134,32);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(124,30);
	glVertex2f(124,32);
	glVertex2f(134,32);
	glVertex2f(134,30);

	glEnd();


	//2
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(142.2,54.2);
	glVertex2f(142.2,56.2);
    glVertex2f(157.8,56.2);
	glVertex2f(157.8,54.2);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1,1,0);

	glVertex2f(144.3,42.3);
	glVertex2f(142.2,54.2);
    glVertex2f(157.8,54.4);
	glVertex2f(155.9,42.2);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142);

	glVertex2f(144.3,40.2);
	glVertex2f(144.3,42.3);
    glVertex2f(155.9,42.3);
	glVertex2f(155.9,40.2);

	glEnd();

	//m
	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(148.4,-11.8);
	glVertex2f(148.5,40.2);
	glVertex2f(151.4,40.2);
	glVertex2f(151.3,-11.8);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(145,-15);
	glVertex2f(144.9,-11.9);
	glVertex2f(154.9,-11.9);
	glVertex2f(155,-15);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(142.8,-18.8);
	glVertex2f(142.8,-15);
	glVertex2f(157.1,-15);
	glVertex2f(157.1,-18.8);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(170,26);
	glVertex2f(170,30);
	glVertex2f(172,30);
	glVertex2f(172,23.01);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,23.01);
	glVertex2f(130,26);
	glVertex2f(170,26);
	glVertex2f(172,23.01);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(124,30);
	glVertex2f(134,32);
	glVertex2f(134,32);
	glVertex2f(124,30);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,23.01);
	glVertex2f(128,30);
	glVertex2f(130,30);
	glVertex2f(130,26);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(170,45);
	glVertex2f(170,48);
	glVertex2f(172,48);
	glVertex2f(172,45);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(128,45);
	glVertex2f(128,48);
	glVertex2f(130,48);
	glVertex2f(130,45);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(144, 143, 142 );

	glVertex2f(149,56);
	glVertex2f(149,59);
	glVertex2f(151,59);
	glVertex2f(151,56);

	glEnd();
    glPopMatrix();
}

void update(int value)
{
    if(zoom==1)
    {
        _move += .002;
        if(_move > 2)
        {
            _move=1.5;
        }
    }
    if(zoom==0)
    {
        _move -= .002;
        if(_move < 1)
        {
            _move=0.5;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(20, update, 0);
}

void keyboard(unsigned char key, int x, int y)
{
	 if (key == 'Z' || key == 'z'){		//zoom in
		zoom = 1;
	}
	if (key == 'O' || key == 'o'){		//zoom out
		zoom = 0;
	}

}

void display()
{
	glClearColor(0,0,0,0);
	glClear(GL_COLOR_BUFFER_BIT);
	StreetLamp();
    glFlush();
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutCreateWindow("ZoomOut");
	glutInitWindowSize(320,320);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	gluOrtho2D(10,400,-100,200);
	glutTimerFunc(20, update, 0);
	glutMainLoop();
	return 0;
}
