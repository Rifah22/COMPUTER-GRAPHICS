#include <iostream>
#include<GL/gl.h>
#include <GL/glut.h>
#include <math.h>
using namespace std;
float _move = 0.0f;
float _angle1=0.0f;

void bridge_land()
{

   // glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    //glTranslatef(_move, 0.0f, 0.0f);
    //rail line
    glColor3ub(120, 129, 122);
    glBegin(GL_POLYGON);
    glVertex2f(25.7,3.35);
    glVertex2f(25.7,3);
    glVertex2f(15.6,3.0);
    glVertex2f(15.6,3.2);
    glEnd();

    glColor3ub(169, 162, 157);
    glBegin(GL_POLYGON);
    glVertex2f(26.0,2.1);
    glVertex2f(25.7,3);
    glVertex2f(15.6,3.0);
    glVertex2f(14.8,2.1);
    glEnd();

    glColor3ub(146, 94, 58);
    glLineWidth(3);
    glBegin(GL_LINES);
    glVertex2f(25.7,3);
    glVertex2f(25.6,3.35);

    glVertex2f(25.2,3);
    glVertex2f(25.1,3.35);

    glVertex2f(24.7,3);
    glVertex2f(24.6,3.32);

    glVertex2f(24.2,3);
    glVertex2f(24.1,3.31);

    glVertex2f(23.6,3.3);
    glVertex2f(23.7,3);

     glVertex2f(23.2,3);
    glVertex2f(23.1,3.31);

    glVertex2f(22.6,3.3);
    glVertex2f(22.7,3);

     glVertex2f(22.2,3);
    glVertex2f(22.1,3.31);

    glVertex2f(21.6,3.3);
    glVertex2f(21.7,3);

     glVertex2f(21.2,3);
    glVertex2f(21.1,3.29);

    glVertex2f(20.6,3.28);
    glVertex2f(20.7,3);

     glVertex2f(20.2,3);
    glVertex2f(20.1,3.28);

    glVertex2f(19.6,3.28);
    glVertex2f(19.7,3);

     glVertex2f(19.2,3);
    glVertex2f(19.1,3.27);

    glVertex2f(18.6,3.26);
    glVertex2f(18.7,3);

     glVertex2f(18.2,3);
    glVertex2f(18.1,3.25);

    glVertex2f(17.6,3.24);
    glVertex2f(17.7,3);

     glVertex2f(17.2,3);
    glVertex2f(17.1,3.235);

    glVertex2f(16.6,3.23);
    glVertex2f(16.7,3);

     glVertex2f(16.2,3);
    glVertex2f(16.1,3.235);

    glVertex2f(15.6,3.22);
    glVertex2f(15.7,3);
    glEnd();


    glColor3ub(46, 22, 6);
    glLineWidth(3);
    glBegin(GL_LINES);
    glVertex2f(25.7,3.30);
    glVertex2f(15.6,3.145);

    glVertex2f(25.7,3.07);
    glVertex2f(15.6,3.06);
    glEnd();


    glPopMatrix();
}

void river()
{
    //river bank
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glColor3ub(120, 129, 122);
    glBegin(GL_POLYGON);
    glVertex2f(10,10);
    glVertex2f(10.6,10);
    glVertex2f(11.6,7.9);
    glVertex2f(11,7.9);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(11.6,7.9);
    glVertex2f(11,7.9);
    glVertex2f(10.7,7.3);
    glVertex2f(11.3,7.3);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(10.7,7.3);
    glVertex2f(11.3,7.3);
    glVertex2f(12.3,5.2);
    glVertex2f(11.6,5.1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(12.3,5.2);
    glVertex2f(11.6,5.1);
    glVertex2f(11.5,4.3);
    glVertex2f(12.2,4.3);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(11.5,4.3);
    glVertex2f(12.2,4.3);
    glVertex2f(13.4,0);
    glVertex2f(12.5,0);
    glEnd();

    glColor3ub(81, 193, 189);
    glBegin(GL_POLYGON);
    glVertex2f(10.7,7.3);
    glVertex2f(11,7.9);
    glVertex2f(10,10);
    glVertex2f(-70,10);
    glVertex2f(-70,0);
    glVertex2f(12.5,0);
    glVertex2f(11.5,4.3);
    glVertex2f(11.6,5.1);
    glEnd();

    glPopMatrix();
}
void land()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glColor3ub(108, 111, 30);
    glBegin(GL_POLYGON);
    glVertex2f(12.3,5.2);
    glVertex2f(11.3,7.3);
    glVertex2f(11.6,7.9);
    glVertex2f(10.6,10);
    glVertex2f(25.7,10);
    glVertex2f(25.7,0);
    glVertex2f(13.4,0);
    glVertex2f(12.2,4.3);
    glEnd();

    glPopMatrix();
}

void bridge_span1()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glColor3ub(141, 60, 34);
    /*glBegin(GL_POLYGON);
    glVertex2f(15.6,3.0);
    glVertex2f(15.6,3.2);
    glVertex2f(-20,3.2);
    glVertex2f(-20,3);
    glEnd();

    glColor3ub(46, 22, 6);
    glLineWidth(2);
    glBegin(GL_LINES); //bridge railline
    glVertex2f(15.6,3.05);
    glVertex2f(-20,3.05);

    glVertex2f(15.6,3.15);//bridge body
    glVertex2f(-20,3.15);
    glEnd();*/

    glBegin(GL_POLYGON);
    glVertex2f(15.6,3.0);
    glVertex2f(15.6,3.2);
    glVertex2f(8,3.2);
    glVertex2f(8,3);
    glEnd();

    glColor3ub(46, 22, 6);
    glLineWidth(2);
    glBegin(GL_LINES); //bridge railline
    glVertex2f(15.6,3.05);
    glVertex2f(8,3.05);

    glVertex2f(15.6,3.15);//bridge body
    glVertex2f(8,3.15);
    glEnd();

    //no.1 span
    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(8.85,3.65);
    glVertex2f(8.92,3.56);
    glVertex2f(8.56,3.2);
    glVertex2f(8.36,3.2);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(13.02,3.55);
    glVertex2f(13.27,3.2);
    glVertex2f(13.47,3.2);
    glVertex2f(13.14,3.65);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(13.02,3.55);
    glVertex2f(13.14,3.65);
    glVertex2f(11.95,3.89);
    glVertex2f(11.95,3.77);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(11.95,3.89);
    glVertex2f(11.95,3.77);
    glVertex2f(9.79,3.76);
    glVertex2f(9.78,3.88);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(9.79,3.76);
    glVertex2f(9.78,3.88);
    glVertex2f(8.85,3.65);
    glVertex2f(8.92,3.56);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f(8.91,3.57);
    glVertex2f(8.92,3.20);

    glVertex2f(9.28,3.20);
    glVertex2f(9.01,3.58);

    glVertex2f(9.28,3.20);
    glVertex2f(9.31,3.66);

    glVertex2f(9.63,3.20);
    glVertex2f(9.31,3.66);

    glVertex2f(9.73,3.20);
    glVertex2f(9.79,3.77);

    glVertex2f(9.79,3.77);
    glVertex2f(10.12,3.20);

    glVertex2f(10.12,3.20);
    glVertex2f(10.13,3.76);

    glVertex2f(10.13,3.76);
    glVertex2f(10.54,3.20);

    glVertex2f(10.54,3.20);
    glVertex2f(10.55,3.76);

    glVertex2f(10.55,3.76);
    glVertex2f(11.02,3.22);

    glVertex2f(11.02,3.76);
    glVertex2f(11.02,3.20);

    glVertex2f(11.02,3.76);
    glVertex2f(11.5,3.20);

    glVertex2f(11.5,3.20);
    glVertex2f(11.51,3.76);

    glVertex2f(11.94,3.20);
    glVertex2f(11.51,3.76);

    glVertex2f(11.94,3.20);
    glVertex2f(11.95,3.77);

    glVertex2f(11.95,3.77);
    glVertex2f(12.37,3.20);

    glVertex2f(12.37,3.20);
    glVertex2f(12.57,3.64);

    glVertex2f(12.57,3.64);
    glVertex2f(12.73,3.20);

    glVertex2f(12.73,3.20);
    glVertex2f(13.02,3.56);

    glVertex2f(13.02,3.56);
    glVertex2f(13.06,3.20);
    glEnd();
    glPopMatrix();




}
void bridge_span2(float x)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,0,0);
    glBegin(GL_POLYGON);
    glVertex2f(14,3.0);
    glVertex2f(14,3.2);
    glVertex2f(8,3.2);
    glVertex2f(8,3);
    glEnd();

    glColor3ub(46, 22, 6);
    glLineWidth(2);
    glBegin(GL_LINES); //bridge railline
    glVertex2f(14,3.05);
    glVertex2f(8,3.05);

    glVertex2f(14,3.15);//bridge body
    glVertex2f(8,3.15);
    glEnd();
    //no.2 span
    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(8.85,3.65);
    glVertex2f(8.92,3.56);
    glVertex2f(8.56,3.2);
    glVertex2f(8.36,3.2);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(13.02,3.55);
    glVertex2f(13.27,3.2);
    glVertex2f(13.47,3.2);
    glVertex2f(13.14,3.65);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(13.02,3.55);
    glVertex2f(13.14,3.65);
    glVertex2f(11.95,3.89);
    glVertex2f(11.95,3.77);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(11.95,3.89);
    glVertex2f(11.95,3.77);
    glVertex2f(9.79,3.76);
    glVertex2f(9.78,3.88);
    glEnd();

    glColor3ub(141, 60, 34);
    glBegin(GL_POLYGON);
    glVertex2f(9.79,3.76);
    glVertex2f(9.78,3.88);
    glVertex2f(8.85,3.65);
    glVertex2f(8.92,3.56);
    glEnd();

    glBegin(GL_LINES);
    glVertex2f(8.91,3.57);
    glVertex2f(8.92,3.20);

    glVertex2f(9.28,3.20);
    glVertex2f(9.01,3.58);

    glVertex2f(9.28,3.20);
    glVertex2f(9.31,3.66);

    glVertex2f(9.63,3.20);
    glVertex2f(9.31,3.66);

    glVertex2f(9.73,3.20);
    glVertex2f(9.79,3.77);

    glVertex2f(9.79,3.77);
    glVertex2f(10.12,3.20);

    glVertex2f(10.12,3.20);
    glVertex2f(10.13,3.76);

    glVertex2f(10.13,3.76);
    glVertex2f(10.54,3.20);

    glVertex2f(10.54,3.20);
    glVertex2f(10.55,3.76);

    glVertex2f(10.55,3.76);
    glVertex2f(11.02,3.22);

    glVertex2f(11.02,3.76);
    glVertex2f(11.02,3.20);

    glVertex2f(11.02,3.76);
    glVertex2f(11.5,3.20);

    glVertex2f(11.5,3.20);
    glVertex2f(11.51,3.76);

    glVertex2f(11.94,3.20);
    glVertex2f(11.51,3.76);

    glVertex2f(11.94,3.20);
    glVertex2f(11.95,3.77);

    glVertex2f(11.95,3.77);
    glVertex2f(12.37,3.20);

    glVertex2f(12.37,3.20);
    glVertex2f(12.57,3.64);

    glVertex2f(12.57,3.64);
    glVertex2f(12.73,3.20);

    glVertex2f(12.73,3.20);
    glVertex2f(13.02,3.56);

    glVertex2f(13.02,3.56);
    glVertex2f(13.06,3.20);
    glEnd();
    glPopMatrix();
}

void piller(float x)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(-0.4,0,0);
    glColor3ub(46, 22, 6);
    glBegin(GL_POLYGON);
    glVertex2f(14.2,2.6);
    glVertex2f(14.2,2.12);
    glVertex2f(13.14,2.12);
    glVertex2f(13.14,2.6);
    glEnd();
    glColor3ub(46, 22, 6);
    glBegin(GL_POLYGON);
    glVertex2f(13.48,3.04);
    glVertex2f(13.81,3.04);
    glVertex2f(13.81,2.6);
    glVertex2f(13.48,2.6);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(x,0,0);
    glColor3ub(46, 22, 6);
    glBegin(GL_POLYGON);
    glVertex2f(14.2,2.6);
    glVertex2f(14.2,2.12);
    glVertex2f(13.14,2.12);
    glVertex2f(13.14,2.6);
    glEnd();
    glColor3ub(46, 22, 6);
    glBegin(GL_POLYGON);
    glVertex2f(13.48,3.04);
    glVertex2f(13.81,3.04);
    glVertex2f(13.81,2.6);
    glVertex2f(13.48,2.6);
    glEnd();
    glPopMatrix();


}
void car()
{
    glColor3ub(156, 25, 250);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(0.07, 0.24);
    glVertex2f(0.08, 0.25);
    glVertex2f(0.12, 0.25);
    glVertex2f(0.17, 0.27);
    glVertex2f(0.33,0.31);
    glVertex2f(0.38,0.32);
    glVertex2f(0.45,0.33);
    glVertex2f(0.54,0.32);
    glVertex2f(0.7,0.25);
    glVertex2f(0.86,0.24);
    glVertex2f(0.91,0.23);
    glVertex2f(0.96,0.19);
    glVertex2f(0.99,0.15);
    glVertex2f(0.98,0.12);
    glVertex2f(0.96,0.09);
    glVertex2f(0.19,0.09);
    glVertex2f(0.17,0.09);
    glVertex2f(0.05,0.11);
    glVertex2f(0.05,0.19);
    glEnd();
    glPopMatrix();


    glColor3ub(120, 129, 122);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glBegin(GL_POLYGON);

    glVertex2f(0.45,0.31);
    glVertex2f(0.38,0.3);
    glVertex2f(0.33,0.29);
    glVertex2f(0.33,0.31);
    glVertex2f(0.38,0.32);
    glVertex2f(0.45,0.33);
    glVertex2f(0.54,0.32);
    glVertex2f(0.53,0.3);
    glEnd();
    glPopMatrix();

    glColor3ub(231, 238, 233);
   // glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glBegin(GL_POLYGON);

    glVertex2f(0.45,0.31);
    glVertex2f(0.38,0.3);
    glVertex2f(0.33,0.29);
    glVertex2f(0.27,0.28);
    glVertex2f(0.29,0.26);
    glVertex2f(0.39,0.25);
    glVertex2f(0.64,0.25);
    glVertex2f(0.53,0.3);
    glEnd();
    glPopMatrix();

    glColor3ub(176, 190, 179);
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glBegin(GL_POLYGON);

    glVertex2f(0.54,0.32);
    glVertex2f(0.7,0.25);
    glVertex2f(0.64,0.25);
    glVertex2f(0.53,0.3);
    glEnd();
    glPopMatrix();
    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glTranslatef(0.82,0.12,0);
    glRotatef(_angle1, 0.0f, 0.0f,1.0f);
    glBegin(GL_LINES);// Draw a Red 1x1 Square centered at origin
    for(int i=0;i<200;i++)
    {
        glColor3ub(20, 231, 244);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.065;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x,y );
    }
    glEnd();
    glPopMatrix();


    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glTranslatef(0.82,0.12,0);
    glRotatef(_angle1, 0.0f, 0.0f,1.0f);
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
    for(int i=0;i<200;i++)
    {
        glColor3ub(64, 59, 68);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.065;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x,y );
    }
    glEnd();
    glPopMatrix();



    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glTranslatef(0.25,0.12,0);
    glRotatef(_angle1, 0.0f, 0.0f,1.0f);
    glLineWidth(5);
    glBegin(GL_LINES);// Draw a Red 1x1 Square centered at origin
    glLineWidth(5);
    for(int i=0;i<200;i++)
    {
        glColor3ub(20, 231, 244);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.065;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x,y );
    }
    glEnd();
    glPopMatrix();

    //glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(15.6, 3.0f, 0.0f);
    glTranslatef(_move, 0.0f, 0.0f);
    glTranslatef(0.25,0.12,0);
    glRotatef(_angle1, 0.0f, 0.0f,1.0f);
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
    for(int i=0;i<200;i++)
    {
        glColor3ub(64, 59, 68);
        float pi=3.1416;
        float A=(i*2*pi)/200;
        float r=0.065;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x,y );
    }
    glEnd();
    glPopMatrix();
}

void road()
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    //Road
    glColor3ub(220, 222, 161);
    glBegin(GL_POLYGON);
    glVertex2f(16.3,1.2);
    glVertex2f(15,1.3);
    glVertex2f(13.9,1.7);
    glVertex2f(14.3,0.8);
    glVertex2f(15.3,0.6);
    glVertex2f(16.7,0.5);
    glVertex2f(19,0.3);
    glVertex2f(20.4,0);
    glVertex2f(24,0);
    glVertex2f(22.1,0.4);
    glVertex2f(19.6,1);
    glEnd();

    glBegin(GL_POLYGON);
     glVertex2f(12.9,1.5);
     glVertex2f(13.2,2.4);
     glVertex2f(13.9,2.6);
     glVertex2f(15.6,2.8);
     glVertex2f(15.6,2.4);
     glVertex2f(14.5,2.2);
     glVertex2f(14.7,1.6);
     glVertex2f(15,1.3);
     glVertex2f(14.3,0.8);
     glEnd();
    glPopMatrix();

}
void drawScene()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(1,1,1,1);
    land();
    road();
    bridge_land();

    river();
    car();
    bridge_span1();

    bridge_span2(-5.5);

    bridge_span2(-11);

    bridge_span2(-16.5);

    bridge_span2(-22);

    bridge_span2(-27.5);

    bridge_span2(-33);

    bridge_span2(-38.5);

    bridge_span2(-44);

    bridge_span2(-49.5);

    bridge_span2(-55);

    bridge_span2(-60.5);

    bridge_span2(-66);

    bridge_span2(-71.5);

    bridge_span2(-77);
    piller(-5.5);
    piller(-11);
    piller(-16.5);
    piller(-22);
    piller(-27.5);
    piller(-33);
    piller(-38.5);
    piller(-44);
    piller(-49.5);
    piller(-55);
    piller(-60.5);
    piller(-66);
    piller(-71.5);
    piller(-77);
    piller(-82.5);


    glutSwapBuffers();
}

void update(int value)
{
    _move += 0.2;
    if(_move > 10)
    {
        _move = -25.0;
    }
    glutPostRedisplay();
    glutTimerFunc(20, update, 0);
}


void update1(int value)
 {
    _angle1+=2.0f;
    if(_angle1 > 360.0)
    {
        _angle1-=360;
    }
    glutPostRedisplay(); //Notify GLUT that the display has changed
    glutTimerFunc(20, update1, 0); //Notify GLUT to call update again in 25 milliseconds
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 800);
    glutCreateWindow("Car");
    glutDisplayFunc(drawScene);
    gluOrtho2D(-70,25.7,0,10);
    glutTimerFunc(20, update, 0); //Add a timer
    glutTimerFunc(20, update1, 0); //Add a timer
    glutMainLoop();
    return 0;
}
